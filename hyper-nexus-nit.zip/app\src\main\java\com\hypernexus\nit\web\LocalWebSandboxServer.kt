package com.hypernexus.nit.web

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket

/**
 * MÁY CHỦ WEB SANDBOX CỤC BỘ NHÚNG SIÊU NHẸ (EMBEDDED LOCAL WEB SANDBOX SERVER)
 * Phục vụ mã nguồn HTML5/CSS3/JS đa file trực tiếp từ RAM tới WebView hoặc trình duyệt ngoài
 * tại cổng 8088 (http://127.0.0.1:8088/).
 * Dung lượng RAM < 1.5MB, hoàn toàn không phụ thuộc thư viện bên ngoài.
 */
object LocalWebSandboxServer {

    private const val TAG = "LocalWebSandboxServer"
    private const val DEFAULT_PORT = 8088

    private var serverSocket: ServerSocket? = null
    private var serverJob: Job? = null
    private var currentProject: WebDevelopmentEngine.WebProject? = null
    private var activePort = DEFAULT_PORT

    @Volatile
    private var isRunning = false

    fun isServerRunning(): Boolean = isRunning
    fun getActivePort(): Int = activePort
    fun getServerUrl(): String = "http://127.0.0.1:$activePort/"

    /**
     * KHỞI ĐỘNG MÁY CHỦ WEB VỚI DỰ ÁN ĐƯỢC CHỌN
     */
    @Synchronized
    fun startServer(project: WebDevelopmentEngine.WebProject, requestedPort: Int = DEFAULT_PORT): Boolean {
        if (isRunning && currentProject?.projectId == project.projectId) {
            currentProject = project
            Log.d(TAG, "Cập nhật dự án mới cho máy chủ đang chạy tại cổng $activePort")
            return true
        }

        stopServer()
        currentProject = project

        var portToTry = requestedPort
        var bound = false
        while (portToTry < requestedPort + 10 && !bound) {
            try {
                serverSocket = ServerSocket(portToTry)
                activePort = portToTry
                bound = true
            } catch (e: Exception) {
                portToTry++
            }
        }

        if (!bound || serverSocket == null) {
            Log.e(TAG, "Không thể mở cổng ServerSocket từ $requestedPort đến ${requestedPort + 10}")
            return false
        }

        isRunning = true
        Log.i(TAG, "Máy chủ Web Sandbox đã kích hoạt tại http://127.0.0.1:$activePort/")

        val scope = CoroutineScope(Dispatchers.IO)
        serverJob = scope.launch {
            while (isActive && isRunning) {
                try {
                    val clientSocket = serverSocket?.accept() ?: break
                    launch {
                        handleClient(clientSocket)
                    }
                } catch (e: Exception) {
                    if (!isRunning) break
                    Log.w(TAG, "Client socket accept interrupted: ${e.message}")
                }
            }
        }

        return true
    }

    /**
     * DỪNG MÁY CHỦ VÀ GIẢI PHÓNG TOÀN BỘ BỘ NHỚ
     */
    @Synchronized
    fun stopServer() {
        isRunning = false
        try {
            serverSocket?.close()
        } catch (e: Exception) {
            Log.w(TAG, "Error closing serverSocket: ${e.message}")
        }
        serverSocket = null
        serverJob?.cancel()
        serverJob = null
        currentProject = null
        Log.i(TAG, "Đã đóng máy chủ Web Sandbox và giải phóng RAM về 0MB.")
    }

    /**
     * XỬ LÝ YÊU CẦU HTTP GET TỪ WEBVIEW HOẶC TRÌNH DUYỆT
     */
    private fun handleClient(socket: Socket) {
        socket.use { s ->
            try {
                val reader = BufferedReader(InputStreamReader(s.getInputStream()))
                val out: OutputStream = s.getOutputStream()

                val firstLine = reader.readLine() ?: return
                val parts = firstLine.split(" ")
                if (parts.size < 2) return

                val method = parts[0]
                var path = parts[1]

                // Chỉ phục vụ GET method
                if (method != "GET") {
                    sendHttpResponse(out, 405, "text/plain", "Method Not Allowed".toByteArray())
                    return
                }

                // Chuẩn hóa đường dẫn
                if (path == "/" || path.isEmpty()) {
                    path = "index.html"
                } else if (path.startsWith("/")) {
                    path = path.substring(1)
                }

                // Loại bỏ query params nếu có
                if (path.contains("?")) {
                    path = path.substringBefore("?")
                }

                val project = currentProject
                if (project == null) {
                    sendHttpResponse(out, 404, "text/plain", "No active project loaded.".toByteArray())
                    return
                }

                val targetFile = project.files[path]
                if (targetFile != null) {
                    val bytes = targetFile.content.toByteArray(Charsets.UTF_8)
                    sendHttpResponse(out, 200, targetFile.mimeType, bytes)
                } else {
                    sendHttpResponse(out, 404, "text/html", "<h1>404 Not Found: $path</h1>".toByteArray())
                }
            } catch (e: Exception) {
                Log.e(TAG, "Lỗi phục vụ request HTTP: ${e.message}")
            }
        }
    }

    private fun sendHttpResponse(out: OutputStream, statusCode: Int, mimeType: String, contentBytes: ByteArray) {
        val statusText = when (statusCode) {
            200 -> "OK"
            404 -> "Not Found"
            405 -> "Method Not Allowed"
            else -> "Internal Server Error"
        }

        val headerBuilder = StringBuilder()
        headerBuilder.append("HTTP/1.1 $statusCode $statusText\r\n")
        headerBuilder.append("Content-Type: $mimeType\r\n")
        headerBuilder.append("Content-Length: ${contentBytes.size}\r\n")
        headerBuilder.append("Access-Control-Allow-Origin: *\r\n")
        headerBuilder.append("Cache-Control: no-cache, no-store, must-revalidate\r\n")
        headerBuilder.append("Connection: close\r\n\r\n")

        out.write(headerBuilder.toString().toByteArray(Charsets.UTF_8))
        out.write(contentBytes)
        out.flush()
    }
}
