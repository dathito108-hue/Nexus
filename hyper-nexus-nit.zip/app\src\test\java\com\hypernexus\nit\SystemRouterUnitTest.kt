package com.hypernexus.nit

import com.hypernexus.nit.engine.LoraHotSwapManager
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class SystemRouterUnitTest {

    @Test
    fun testTokenExtraction() {
        val testCommand1 = "phân tích token jup"
        val words = testCommand1.split(" ")
        var extracted = "SOL"
        for (i in words.indices) {
            if (words[i] in listOf("token", "đồng", "coin") && i + 1 < words.size) {
                extracted = words[i + 1].uppercase()
            }
        }
        assertEquals("JUP", extracted)
    }

    @Test
    fun testGoldDetection() {
        val testCommand = "cho tôi xem giá vàng thế giới hôm nay"
        val isGold = testCommand.contains("vàng") || testCommand.contains("gold")
        assertTrue(isGold)
    }

    @Test
    fun testCapCutCommandDetection() {
        val testCommand = "mở capcut tạo dự án mới"
        val isCapcut = testCommand.contains("capcut")
        val isNewProject = testCommand.contains("dự án mới")
        assertTrue(isCapcut)
        assertTrue(isNewProject)
    }

    @Test
    fun testLoraHotSwapManager() {
        // Kiểm tra cơ chế nạp/xả LoRA và ngân sách RAM
        val swapped = LoraHotSwapManager.hotSwapLora(LoraHotSwapManager.LoraType.FINANCE_EXPERT)
        assertTrue(swapped)
        assertEquals(LoraHotSwapManager.LoraType.FINANCE_EXPERT, LoraHotSwapManager.getActiveLora())
        assertEquals(20, LoraHotSwapManager.getActiveRamOverheadMb())

        // Thử nghiệm xả toàn bộ về 0MB khi ngủ sâu
        LoraHotSwapManager.unloadAll()
        assertEquals(LoraHotSwapManager.LoraType.NONE, LoraHotSwapManager.getActiveLora())
        assertEquals(0, LoraHotSwapManager.getActiveRamOverheadMb())
    }

    @Test
    fun testBankTransferOcrParsing() {
        val ocrSample = "Chuyển tiền Techcombank STK 19036789012345 số tiền 500.000 VND"
        val parsed = com.hypernexus.nit.vision.ScreenVisionCoPilot.parseBankTransferFromText(ocrSample)
        org.junit.Assert.assertNotNull(parsed)
        assertEquals("TECHCOMBANK", parsed?.bankName)
        assertEquals("19036789012345", parsed?.accountNumber)
        assertEquals(500000.0, parsed?.amount)
    }

    @Test
    fun testSmartHomeCommandDetection() {
        val testCommand = "nít ơi bật đèn phòng khách"
        val isSmartHome = testCommand.contains("đèn") || testCommand.contains("điều hòa")
        assertTrue(isSmartHome)
    }

    @Test
    fun testWebSearchAndUrlDetection() {
        val urlCommand = "tóm tắt trang web https://vnexpress.net/so-hoa/ai"
        val hasUrl = urlCommand.contains("http://") || urlCommand.contains("https://")
        assertTrue(hasUrl)

        val searchCommand = "tìm kiếm tin tức giá bitcoin hôm nay"
        val isSearch = searchCommand.startsWith("tìm kiếm ") || searchCommand.contains("tin tức")
        assertTrue(isSearch)
    }

    @Test
    fun testRealChartPixelAnalysis() {
        // Tạo một Bitmap thật 10x10 để kiểm thử quét màu nến không dùng mock
        val bitmap = android.graphics.Bitmap.createBitmap(10, 10, android.graphics.Bitmap.Config.ARGB_8888)
        for (x in 0 until 10) {
            for (y in 0 until 10) {
                // Tô màu xanh lá cây tượng trưng cho nến tăng
                bitmap.setPixel(x, y, android.graphics.Color.rgb(20, 200, 20))
            }
        }
        val analysis = com.hypernexus.nit.vision.ScreenVisionCoPilot.analyzeTradingViewChart(bitmap)
        org.junit.Assert.assertNotNull(analysis)
        assertTrue(analysis.bullishRatio > 0.8f)
    }

    @Test
    fun testSolanaBase58Encoding() {
        val testBytes = byteArrayOf(0, 0, 1, 2, 3)
        val encoded = com.hypernexus.nit.security.SolanaKeypairManager.encodeBase58(testBytes)
        org.junit.Assert.assertNotNull(encoded)
        assertTrue(encoded.startsWith("11"))

        val dummySeed = ByteArray(32) { 1 }
        val dummyMsg = "swap_sol_jup".toByteArray()
        val sig = com.hypernexus.nit.security.SolanaKeypairManager.signTransactionBytes(dummyMsg, dummySeed)
        assertEquals(64, sig.size)
    }

    @Test
    fun testRugCheckRoutingDetection() {
        val cmd1 = "quét token jup xem an toàn không"
        val isAudit = cmd1.contains("quét token") || cmd1.contains("kiểm toán") || cmd1.contains("rugcheck") || cmd1.contains("an toàn không")
        assertTrue(isAudit)
    }

    @Test
    fun testJupiterSwapRoutingDetection() {
        val cmd = "swap 0.5 sol sang usdc"
        val isSwap = cmd.contains("swap") || cmd.contains("hoán đổi")
        assertTrue(isSwap)
    }

    @Test
    fun testAirGestureRoutingDetection() {
        val cmd = "bật cử chỉ không chạm"
        val isGesture = cmd.contains("cử chỉ") || cmd.contains("vẫy tay") || cmd.contains("không chạm")
        assertTrue(isGesture)
    }

    @Test
    fun testGameBotRoutingDetection() {
        val cmd = "bật bot game hỗ trợ liên quân tự động combo"
        val isGameBot = cmd.contains("bot game") || cmd.contains("hỗ trợ game") || cmd.contains("liên quân") || cmd.contains("tự động combo")
        assertTrue(isGameBot)
    }

    @Test
    fun testSolanaAmountExtraction() {
        val pattern = java.util.regex.Pattern.compile("([0-9]+([.,][0-9]+)?)\\s*(sol|đồng|đ)?")
        val matcher = pattern.matcher("hoán đổi 0.25 sol sang ray")
        assertTrue(matcher.find())
        val amount = matcher.group(1)?.replace(",", ".")?.toDoubleOrNull()
        assertEquals(0.25, amount ?: 0.0, 0.001)
    }

    @Test
    fun testRewindRoutingDetection() {
        val cmd1 = "hôm qua tôi có xem bài viết gì về shopee"
        val isRewind1 = cmd1.contains("ký ức") || cmd1.contains("hồi tưởng") || cmd1.contains("rewind") || cmd1.contains("đã xem gì") || cmd1.contains("đã đọc gì") || cmd1.startsWith("tìm lại ") || (cmd1.contains("hôm qua") && (cmd1.contains("xem") || cmd1.contains("đọc")))
        assertTrue(isRewind1)

        val cmd2 = "tìm lại bài đăng facebook xe máy"
        val isRewind2 = cmd2.contains("ký ức") || cmd2.contains("hồi tưởng") || cmd2.contains("rewind") || cmd2.contains("đã xem gì") || cmd2.contains("đã đọc gì") || cmd2.startsWith("tìm lại ")
        assertTrue(isRewind2)

        val keyword = cmd2.replace("tìm lại", "").trim()
        assertEquals("bài đăng facebook xe máy", keyword)
    }

    @Test
    fun testProcedural3DModelsGeneration() {
        val types = com.hypernexus.nit.engine.Procedural3DGenerator.MeshType.values()
        for (type in types) {
            val mesh = com.hypernexus.nit.engine.Procedural3DGenerator.buildMeshData(type)
            assertTrue("Vertices không được rỗng cho $type", mesh.vertices.isNotEmpty())
            assertTrue("Normals không được rỗng cho $type", mesh.normals.isNotEmpty())
            assertTrue("Indices không được rỗng cho $type", mesh.indices.isNotEmpty())
            assertEquals("Vertices phải là bộ 3 tọa độ (x, y, z)", 0, mesh.vertices.size % 3)
            assertEquals("Normals phải là bộ 3 tọa độ (nx, ny, nz)", 0, mesh.normals.size % 3)
            assertEquals("Indices phải chia hết cho 3 (mỗi tam giác 3 đỉnh)", 0, mesh.indices.size % 3)
            assertEquals("Số tam giác phải khớp indices / 3", mesh.indices.size / 3, mesh.triangleCount)
            assertTrue("Số tam giác phải lớn hơn 0", mesh.triangleCount > 0)
        }
    }

    @Test
    fun testStlFormatExport() {
        val mesh = com.hypernexus.nit.engine.Procedural3DGenerator.buildMeshData(
            com.hypernexus.nit.engine.Procedural3DGenerator.MeshType.MECHA_SWORD
        )
        // Tạo file STL tạm trong thư mục java.io.tmpdir
        val tempDir = java.io.File(System.getProperty("java.io.tmpdir"))
        val tempFile = java.io.File(tempDir, "test_mecha_sword.stl")

        val writer = java.io.FileWriter(tempFile)
        writer.write("solid ${mesh.type.name}\n")
        val v = mesh.vertices
        val n = mesh.normals
        val idx = mesh.indices

        for (i in idx.indices step 3) {
            val i1 = idx[i].toInt()
            val i2 = idx[i + 1].toInt()
            val i3 = idx[i + 2].toInt()
            val nx = n[i1 * 3]
            val ny = n[i1 * 3 + 1]
            val nz = n[i1 * 3 + 2]
            writer.write("  facet normal $nx $ny $nz\n")
            writer.write("    outer loop\n")
            writer.write("      vertex ${v[i1 * 3]} ${v[i1 * 3 + 1]} ${v[i1 * 3 + 2]}\n")
            writer.write("      vertex ${v[i2 * 3]} ${v[i2 * 3 + 1]} ${v[i2 * 3 + 2]}\n")
            writer.write("      vertex ${v[i3 * 3]} ${v[i3 * 3 + 1]} ${v[i3 * 3 + 2]}\n")
            writer.write("    endloop\n")
            writer.write("  endfacet\n")
        }
        writer.write("endsolid ${mesh.type.name}\n")
        writer.flush()
        writer.close()

        assertTrue(tempFile.exists())
        assertTrue(tempFile.length() > 0)
        val content = tempFile.readText()
        assertTrue(content.startsWith("solid MECHA_SWORD"))
        assertTrue(content.contains("facet normal"))
        assertTrue(content.contains("outer loop"))
        assertTrue(content.contains("vertex"))
        assertTrue(content.endsWith("endsolid MECHA_SWORD\n"))
        tempFile.delete()
    }

    @Test
    fun test3DVoiceRoutingDetection() {
        val cmd1 = "dựng cho anh mô hình 3d vệ tinh lượng tử"
        val is3D1 = cmd1.contains("3d") || cmd1.contains("mô hình") || cmd1.contains("máy in 3d")
        assertTrue(is3D1)

        val cmd2 = "xuất file máy in 3d kiếm mecha"
        val isPrint = cmd2.contains("máy in 3d") || cmd2.contains("in 3d") || cmd2.contains("stl")
        assertTrue(isPrint)
    }

    @Test
    fun testSlicerAnalysisCalculation() {
        // Kiểm tra phân tích thông số in 3D cho Bánh răng cơ khí (Spur Gear)
        val gearMesh = com.hypernexus.nit.engine.Procedural3DGenerator.buildMeshData(
            com.hypernexus.nit.engine.Procedural3DGenerator.MeshType.SPUR_GEAR
        )
        val analysis = com.hypernexus.nit.engine.Procedural3DGenerator.analyzeMeshFor3DPrinting(gearMesh)

        assertTrue("Thể tích in phải lớn hơn 0", analysis.volumeCm3 > 0f)
        assertTrue("Khối lượng nhựa PLA phải lớn hơn 0", analysis.weightGramsPla > 0f)
        assertTrue("Khối lượng nhựa PETG phải lớn hơn 0", analysis.weightGramsPetg > 0f)
        assertTrue("Khối lượng nhựa ABS phải lớn hơn 0", analysis.weightGramsAbs > 0f)
        assertTrue("Thời gian in ước tính phải lớn hơn 0 phút", analysis.estimatedPrintTimeMinutes > 0)
        assertTrue("Chiều rộng bounding box > 0", analysis.boundingBoxMm.widthMm > 0f)
        assertTrue("Chiều cao bounding box > 0", analysis.boundingBoxMm.heightMm > 0f)
        assertTrue("Độ dày bounding box > 0", analysis.boundingBoxMm.depthMm > 0f)
        assertEquals("Số tam giác phân tích phải khớp với mesh", gearMesh.triangleCount, analysis.triangleCount)

        // Kiểm tra phân tích Giá đỡ điện thoại (Phone Stand)
        val phoneStandMesh = com.hypernexus.nit.engine.Procedural3DGenerator.buildMeshData(
            com.hypernexus.nit.engine.Procedural3DGenerator.MeshType.PHONE_STAND
        )
        val standAnalysis = com.hypernexus.nit.engine.Procedural3DGenerator.analyzeMeshFor3DPrinting(phoneStandMesh)
        assertTrue("Giá đỡ điện thoại phải có thể tích lớn hơn 0", standAnalysis.volumeCm3 > 0f)
        assertTrue("Thời gian in phải trên 15 phút", standAnalysis.estimatedPrintTimeMinutes >= 15)
    }

    @Test
    fun testBinaryStlStructureVerification() {
        val mesh = com.hypernexus.nit.engine.Procedural3DGenerator.buildMeshData(
            com.hypernexus.nit.engine.Procedural3DGenerator.MeshType.HEATSINK
        )
        val triCount = mesh.triangleCount
        val expectedFileSize = 80 + 4 + (50 * triCount)

        // Tạo buffer nhị phân giả lập xuất file Binary STL
        val header = ByteArray(80)
        val countBuffer = java.nio.ByteBuffer.allocate(4).order(java.nio.ByteOrder.LITTLE_ENDIAN).putInt(triCount)
        val triBuffer = java.nio.ByteBuffer.allocate(50 * triCount).order(java.nio.ByteOrder.LITTLE_ENDIAN)

        val v = mesh.vertices
        val n = mesh.normals
        val idx = mesh.indices

        for (i in idx.indices step 3) {
            val i1 = idx[i].toInt()
            val i2 = idx[i + 1].toInt()
            val i3 = idx[i + 2].toInt()

            triBuffer.putFloat(n[i1 * 3]); triBuffer.putFloat(n[i1 * 3 + 1]); triBuffer.putFloat(n[i1 * 3 + 2])
            triBuffer.putFloat(v[i1 * 3]); triBuffer.putFloat(v[i1 * 3 + 1]); triBuffer.putFloat(v[i1 * 3 + 2])
            triBuffer.putFloat(v[i2 * 3]); triBuffer.putFloat(v[i2 * 3 + 1]); triBuffer.putFloat(v[i2 * 3 + 2])
            triBuffer.putFloat(v[i3 * 3]); triBuffer.putFloat(v[i3 * 3 + 1]); triBuffer.putFloat(v[i3 * 3 + 2])
            triBuffer.putShort(0)
        }

        val totalBytes = header.size + countBuffer.capacity() + triBuffer.capacity()
        assertEquals("Dung lượng tệp Binary STL phải chuẩn xác 84 + 50 * N", expectedFileSize, totalBytes)
    }

    @Test
    fun testProfessionalCADVoiceRouting() {
        val cmd1 = "phân tích thông số in 3d mô hình này tốn bao nhiêu gram nhựa"
        val isSlicerQuery = cmd1.contains("phân tích") || cmd1.contains("gram nhựa") || cmd1.contains("in 3d")
        assertTrue(isSlicerQuery)

        val cmd2 = "chuyển sang shader bản đồ pháp tuyền kiểm tra góc vát"
        val isShaderQuery = cmd2.contains("shader") || cmd2.contains("pháp tuyến") || cmd2.contains("lưới")
        assertTrue(isShaderQuery)

        val cmd3 = "xuất file binary stl cho máy in bambu lab"
        val isBinaryStl = cmd3.contains("binary") || cmd3.contains("stl") || cmd3.contains("máy in")
        assertTrue(isBinaryStl)
    }

    @Test
    fun testCognitiveTaskReasoner3DGoal() {
        val goal = "dựng mô hình 3d bánh răng cơ khí rồi phân tích khối lượng và xuất file binary stl"
        val plan = com.hypernexus.nit.planner.CognitiveTaskReasoner.reasonAndCreatePlan(goal)

        org.junit.Assert.assertNotNull(plan)
        assertTrue("Kế hoạch phải có ít nhất 3 bước", plan.steps.size >= 3)
        assertEquals(com.hypernexus.nit.planner.TriggerType.IMMEDIATE, plan.triggerType)
        assertEquals(com.hypernexus.nit.planner.ActionType.GENERATE_3D_MODEL, plan.steps[0].actionType)
        assertEquals("SPUR_GEAR", plan.steps[0].params["MODEL_TYPE"])
        assertEquals(com.hypernexus.nit.planner.ActionType.SLICER_ANALYZE, plan.steps[1].actionType)
        assertEquals(com.hypernexus.nit.planner.ActionType.EXPORT_3D_PRINT, plan.steps[2].actionType)
        assertEquals("BINARY_STL", plan.steps[2].params["FORMAT"])
    }

    @Test
    fun testCognitiveTaskReasonerSolanaSchedule() {
        val goal = "sáng mai 7h quét giá sol nếu rsi < 35 thì báo cáo"
        val plan = com.hypernexus.nit.planner.CognitiveTaskReasoner.reasonAndCreatePlan(goal)

        org.junit.Assert.assertNotNull(plan)
        assertEquals(com.hypernexus.nit.planner.TriggerType.EXACT_TIME, plan.triggerType)
        assertTrue("Thời điểm kích hoạt phải trong tương lai", plan.triggerTimeMs > System.currentTimeMillis())
        assertTrue("Kế hoạch phải có ít nhất 2 bước", plan.steps.size >= 2)
        assertEquals(com.hypernexus.nit.planner.ActionType.SOLANA_QUANT_ANALYZE, plan.steps[0].actionType)
        assertEquals("SOL", plan.steps[0].params["TOKEN"])
    }

    @Test
    fun testCognitiveTaskReasonerWebSearchSchedule() {
        val goal = "sau 20 phút tìm kiếm tin tức công nghệ ai"
        val plan = com.hypernexus.nit.planner.CognitiveTaskReasoner.reasonAndCreatePlan(goal)

        org.junit.Assert.assertNotNull(plan)
        assertEquals(com.hypernexus.nit.planner.TriggerType.EXACT_TIME, plan.triggerType)
        assertTrue(plan.triggerTimeMs > System.currentTimeMillis())
        assertEquals(com.hypernexus.nit.planner.ActionType.WEB_SEARCH, plan.steps[0].actionType)
    }

    @Test
    fun testPlannerVoiceRoutingDetection() {
        val cmd1 = "nít ơi lên lịch 8h tối kiểm tra giá vàng"
        val isPlanner1 = cmd1.contains("lên lịch") || cmd1.contains("kế hoạch") || cmd1.contains("hẹn giờ") || cmd1.contains("nhắc tôi")
        assertTrue(isPlanner1)

        val cmd2 = "lập kế hoạch tự động in 3d giá đỡ điện thoại"
        val isPlanner2 = cmd2.contains("lập kế hoạch") || cmd2.contains("kế hoạch")
        assertTrue(isPlanner2)
    }

    @Test
    fun testExpanded3DParametricModelsDetection() {
        val cmdGear = "dựng mô hình 3d bánh răng cơ khí"
        val isGear = cmdGear.contains("bánh răng") || cmdGear.contains("gear")
        assertTrue(isGear)

        val cmdStand = "thiết kế giá đỡ điện thoại samsung"
        val isStand = cmdStand.contains("giá đỡ") || cmdStand.contains("chân đế")
        assertTrue(isStand)

        val cmdWrench = "tạo cờ lê cơ khí mở ốc"
        val isWrench = cmdWrench.contains("cờ lê") || cmdWrench.contains("mỏ lết")
        assertTrue(isWrench)

        val cmdHeatsink = "dựng tản nhiệt nhôm heatsink"
        val isHeatsink = cmdHeatsink.contains("tản nhiệt") || cmdHeatsink.contains("heatsink")
        assertTrue(isHeatsink)
    }

    @Test
    fun test3DSlicerAndBinaryStlCommandDetection() {
        val cmdSlicer = "phân tích slicer xem tốn bao nhiêu nhựa và in mất bao lâu"
        val isSlicer = cmdSlicer.contains("phân tích") || cmdSlicer.contains("slicer") || cmdSlicer.contains("thể tích") || cmdSlicer.contains("tốn bao nhiêu")
        assertTrue(isSlicer)

        val cmdExport = "xuất file binary stl nạp máy in 3d bambu"
        val isExport = cmdExport.contains("xuất") || cmdExport.contains("stl") || cmdExport.contains("tải file")
        assertTrue(isExport)
    }

    @Test
    fun testInstitutionalMarketVoiceRoutingDetection() {
        val cmd1 = "nít ơi lập báo cáo tổ chức cho bitcoin"
        val isInst1 = cmd1.contains("phân tích chuyên sâu") || cmd1.contains("báo cáo tổ chức") || cmd1.contains("tổ chức")
        assertTrue(isInst1)

        val cmd2 = "phân tích smart money concepts và order block solana"
        val isInst2 = cmd2.contains("smart money") || cmd2.contains("smc") || cmd2.contains("order block")
        assertTrue(isInst2)

        val cmd3 = "đo lường định lượng rủi ro var 95 và tỷ lệ kelly"
        val isInst3 = cmd3.contains("định lượng rủi ro") || cmd3.contains("var 95") || cmd3.contains("kelly")
        assertTrue(isInst3)
    }

    @Test
    fun testSmcAndQuantRiskDossierGeneration() {
        kotlinx.coroutines.runBlocking {
            val dossier = com.hypernexus.nit.finance.InstitutionalMarketAnalyzer.analyzeInstitutionalMarket("BTC")
            org.junit.Assert.assertNotNull(dossier)
            assertTrue("Điểm số thiên kiến phải nằm trong khoảng 5-95", dossier.compositeScore in 5..95)
            assertEquals(3, dossier.scenarios.size)
            assertTrue("Phải có giá trị VaR 95% hợp lệ", dossier.quantRisk.var95Pct > 0.0)
            assertTrue("Tỷ lệ Kelly an toàn phải từ 2% đến 25%", dossier.quantRisk.optimalKellyFractionPct in 2.0..25.0)
            assertTrue("Bản memo điều hành phải có nội dung đầy đủ", dossier.formatExecutiveMemo().contains("EXECUTIVE SUMMARY"))
            assertTrue("Bản tóm tắt âm thanh phải có nội dung", dossier.formatVoiceBriefing().contains("Báo cáo thị trường tổ chức"))
        }
    }

    @Test
    fun testCapCutProPresetsMatching() {
        val p1 = com.hypernexus.nit.video.CapCutProAutomationEngine.matchPresetFromCommand("tạo phụ đề tự động tiếng việt trên capcut")
        assertEquals(com.hypernexus.nit.video.CapCutProAutomationEngine.EditingPreset.AUTO_SUBTITLES, p1)

        val p2 = com.hypernexus.nit.video.CapCutProAutomationEngine.matchPresetFromCommand("chuyển khung hình sang 9:16 làm tiktok shorts")
        assertEquals(com.hypernexus.nit.video.CapCutProAutomationEngine.EditingPreset.VIRAL_REELS_916, p2)

        val p3 = com.hypernexus.nit.video.CapCutProAutomationEngine.matchPresetFromCommand("xuất video chuẩn 4k 60fps chất lượng cao nhất")
        assertEquals(com.hypernexus.nit.video.CapCutProAutomationEngine.EditingPreset.EXPORT_4K_60FPS, p3)

        val p4 = com.hypernexus.nit.video.CapCutProAutomationEngine.matchPresetFromCommand("cắt nhịp beat nhạc giật giật theo tiếng trống")
        assertEquals(com.hypernexus.nit.video.CapCutProAutomationEngine.EditingPreset.BEAT_SYNC_CUTS, p4)

        val p5 = com.hypernexus.nit.video.CapCutProAutomationEngine.matchPresetFromCommand("khử nhiễu lọc tạp âm môi trường cho âm thanh")
        assertEquals(com.hypernexus.nit.video.CapCutProAutomationEngine.EditingPreset.SMART_AUDIO_ENHANCE, p5)
    }

    @Test
    fun testCapCutProTaskPlanDecomposition() {
        val goal = "lập kế hoạch tối nay tự động vào capcut tạo phụ đề video"
        val plan = com.hypernexus.nit.planner.CognitiveTaskReasoner.reasonAndCreatePlan(goal)

        org.junit.Assert.assertNotNull(plan)
        assertTrue("Kế hoạch phải có ít nhất 2 bước", plan.steps.size >= 2)
        assertEquals(com.hypernexus.nit.planner.ActionType.CAPCUT_MACRO, plan.steps[0].actionType)
        assertEquals("AUTO_SUBTITLES", plan.steps[0].params["PRESET"])
    }

    @Test
    fun testCapCutThemeMatching() {
        val t1 = com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.matchThemeFromCommand("biên tập video phong cách cyberpunk tương lai neon")
        assertEquals(com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.VideoTheme.CYBERPUNK_FUTURISTIC, t1)

        val t2 = com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.matchThemeFromCommand("làm clip hoài niệm vintage film 90s retro ấm áp")
        assertEquals(com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.VideoTheme.VINTAGE_NOSTALGIA, t2)

        val t3 = com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.matchThemeFromCommand("video du lịch travel vlog phong cảnh teal orange")
        assertEquals(com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.VideoTheme.CINEMATIC_TRAVEL, t3)

        val t4 = com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.matchThemeFromCommand("highlight game chiến đấu esports bắn súng kịch tính")
        assertEquals(com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.VideoTheme.GAMING_ESPORTS, t4)

        val t5 = com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.matchThemeFromCommand("phong cách tối giản sang trọng luxury đen trắng")
        assertEquals(com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.VideoTheme.LUXURY_MINIMALIST, t5)

        // Kiểm tra tạo config tự động
        val config = com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.buildDefaultConfigForTheme(t1)
        assertEquals(com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.VisualEffectType.GLITCH_TECH, config.visualEffect)
        assertTrue("Audio Ducking phải được bật mặc định", config.audioConfig.enableAudioDucking)
        assertEquals(25, config.audioConfig.bgmVolumePercent)
    }

    @Test
    fun testCapCutThemeTaskPlanDecomposition() {
        val goal = "lập kế hoạch sáng mai dựng video chủ đề cyberpunk có nhạc synthwave"
        val plan = com.hypernexus.nit.planner.CognitiveTaskReasoner.reasonAndCreatePlan(goal)

        org.junit.Assert.assertNotNull(plan)
        assertTrue("Kế hoạch phải có ít nhất 2 bước", plan.steps.size >= 2)
        assertEquals(com.hypernexus.nit.planner.ActionType.CAPCUT_MACRO, plan.steps[0].actionType)
        assertEquals("CYBERPUNK", plan.steps[0].params["THEME"])
    }

    @Test
    fun testWebProjectTemplateMatching() {
        val t1 = com.hypernexus.nit.web.WebDevelopmentEngine.matchTemplateFromCommand("lập trình web bán hàng trực tuyến có giỏ hàng")
        assertEquals(com.hypernexus.nit.web.WebDevelopmentEngine.WebProjectTemplate.E_COMMERCE_STORE, t1)

        val t2 = com.hypernexus.nit.web.WebDevelopmentEngine.matchTemplateFromCommand("tạo web dashboard phân tích chỉ số crypto")
        assertEquals(com.hypernexus.nit.web.WebDevelopmentEngine.WebProjectTemplate.ANALYTICS_DASHBOARD, t2)

        val t3 = com.hypernexus.nit.web.WebDevelopmentEngine.matchTemplateFromCommand("thiết kế trang web portfolio cá nhân cv kỹ sư ai")
        assertEquals(com.hypernexus.nit.web.WebDevelopmentEngine.WebProjectTemplate.PORTFOLIO_CREATIVE, t3)

        val t4 = com.hypernexus.nit.web.WebDevelopmentEngine.matchTemplateFromCommand("dựng trang web 3d webgl canvas tương tác")
        assertEquals(com.hypernexus.nit.web.WebDevelopmentEngine.WebProjectTemplate.WEBGL_3D_EXPERIENCE, t4)

        val t5 = com.hypernexus.nit.web.WebDevelopmentEngine.matchTemplateFromCommand("lập trình game web runner trên canvas")
        assertEquals(com.hypernexus.nit.web.WebDevelopmentEngine.WebProjectTemplate.RETRO_WEB_GAME, t5)

        val t6 = com.hypernexus.nit.web.WebDevelopmentEngine.matchTemplateFromCommand("code web landing page saas chuyển đổi cao")
        assertEquals(com.hypernexus.nit.web.WebDevelopmentEngine.WebProjectTemplate.LANDING_PAGE_SAAS, t6)
    }

    @Test
    fun testWebProjectGenerationAndFiles() {
        com.hypernexus.nit.web.WebDevelopmentEngine.WebProjectTemplate.values().forEach { template ->
            val project = com.hypernexus.nit.web.WebDevelopmentEngine.generateProject(template, "Dự Án Test ${template.name}")
            org.junit.Assert.assertNotNull(project)
            assertTrue("Dự án phải có ít nhất 4 file (html, css, js, manifest)", project.files.size >= 4)
            assertTrue("Phải có index.html", project.files.containsKey("index.html"))
            assertTrue("Phải có style.css", project.files.containsKey("style.css"))
            assertTrue("Phải có app.js", project.files.containsKey("app.js"))
            assertTrue("Phải có manifest.json", project.files.containsKey("manifest.json"))

            val htmlContent = project.files["index.html"]!!.content
            assertTrue("index.html phải có doctype", htmlContent.contains("<!DOCTYPE html>", ignoreCase = true))
            assertTrue("index.html phải có thẻ viewport", htmlContent.contains("name=\"viewport\"", ignoreCase = true))

            val cssContent = project.files["style.css"]!!.content
            assertTrue("style.css không được rỗng", cssContent.isNotBlank())

            val jsContent = project.files["app.js"]!!.content
            assertTrue("app.js không được rỗng", jsContent.isNotBlank())
        }
    }

    @Test
    fun testWebCodeValidationCompliance() {
        val project = com.hypernexus.nit.web.WebDevelopmentEngine.generateProject(
            com.hypernexus.nit.web.WebDevelopmentEngine.WebProjectTemplate.LANDING_PAGE_SAAS,
            "Hyper Nexus Landing"
        )
        val validation = com.hypernexus.nit.web.WebDevelopmentEngine.validateWebCode(project)

        assertTrue("Mã nguồn phải hợp lệ không có lỗi nghiêm trọng", validation.isValid)
        assertTrue("Tổng số dòng mã phải > 50", validation.totalLines > 50)
        assertTrue("Tổng kích thước byte phải > 1000", validation.totalBytes > 1000)
        assertTrue("Điểm chuẩn W3C phải >= 90/100", validation.qualityScore >= 90)
    }

    @Test
    fun testWebDevelopmentTaskPlanDecomposition() {
        val goal = "lập kế hoạch tạo web dashboard theo dõi crypto lúc 8 giờ tối"
        val plan = com.hypernexus.nit.planner.CognitiveTaskReasoner.reasonAndCreatePlan(goal)

        org.junit.Assert.assertNotNull(plan)
        assertTrue("Kế hoạch phải có ít nhất 3 bước", plan.steps.size >= 3)
        assertEquals(com.hypernexus.nit.planner.ActionType.WEB_DEVELOP, plan.steps[0].actionType)
        assertEquals("ANALYTICS_DASHBOARD", plan.steps[0].params["TEMPLATE"])
        assertEquals(com.hypernexus.nit.planner.ActionType.WEB_HOST_LOCAL, plan.steps[1].actionType)
        assertEquals(com.hypernexus.nit.planner.ActionType.VOICE_NOTIFY, plan.steps[2].actionType)
    }

    @Test
    fun testLocalWebSandboxServerLifecycle() {
        val project = com.hypernexus.nit.web.WebDevelopmentEngine.generateProject(
            com.hypernexus.nit.web.WebDevelopmentEngine.WebProjectTemplate.ANALYTICS_DASHBOARD
        )
        // Kiểm tra start và stop server
        val started = com.hypernexus.nit.web.LocalWebSandboxServer.startServer(project, 8090)
        assertTrue("Máy chủ web phải khởi động thành công", started)
        assertTrue("isServerRunning phải là true", com.hypernexus.nit.web.LocalWebSandboxServer.isServerRunning())
        assertTrue("URL phải chứa cổng máy chủ", com.hypernexus.nit.web.LocalWebSandboxServer.getServerUrl().contains("809"))

        // Dừng máy chủ
        com.hypernexus.nit.web.LocalWebSandboxServer.stopServer()
        org.junit.Assert.assertFalse("Máy chủ phải dừng hoàn toàn", com.hypernexus.nit.web.LocalWebSandboxServer.isServerRunning())
    }

    @Test
    fun testWebRouterIntentRecognition() {
        val cmd1 = "nít ơi lập trình cho tôi một trang web bán hàng công nghệ"
        val isWeb1 = cmd1.contains("lập trình web") || cmd1.contains("thiết kế web") || cmd1.contains("code web") || cmd1.contains("tạo trang web") || cmd1.contains("tạo web") || cmd1.contains("máy chủ web") || (cmd1.contains("web") && (cmd1.contains("bán hàng") || cmd1.contains("dashboard") || cmd1.contains("portfolio") || cmd1.contains("landing") || cmd1.contains("sandbox")))
        assertTrue(isWeb1)

        val cmd2 = "code web dashboard thống kê"
        val isWeb2 = cmd2.contains("lập trình web") || cmd2.contains("thiết kế web") || cmd2.contains("code web") || cmd2.contains("tạo trang web") || cmd2.contains("tạo web") || cmd2.contains("máy chủ web") || (cmd2.contains("web") && (cmd2.contains("bán hàng") || cmd2.contains("dashboard") || cmd2.contains("portfolio") || cmd2.contains("landing") || cmd2.contains("sandbox")))
        assertTrue(isWeb2)
    }

    @Test
    fun testWebGameGenreMatching() {
        val g1 = com.hypernexus.nit.web.WebGameDevelopmentEngine.matchGameGenreFromCommand("lập trình game bắn phi thuyền không gian arcade 120 fps")
        assertEquals(com.hypernexus.nit.web.WebGameDevelopmentEngine.WebGameGenre.CYBER_SPACE_SHOOTER, g1)

        val g2 = com.hypernexus.nit.web.WebGameDevelopmentEngine.matchGameGenreFromCommand("code game nhảy đi ải ninja vật lý 2d")
        assertEquals(com.hypernexus.nit.web.WebGameDevelopmentEngine.WebGameGenre.NEON_PLATFORMER_PHYSICS, g2)

        val g3 = com.hypernexus.nit.web.WebGameDevelopmentEngine.matchGameGenreFromCommand("tạo game phá gạch neon arkanoid")
        assertEquals(com.hypernexus.nit.web.WebGameDevelopmentEngine.WebGameGenre.RETRO_BRICK_BREAKER, g3)

        val g4 = com.hypernexus.nit.web.WebGameDevelopmentEngine.matchGameGenreFromCommand("lập trình game rắn săn mồi không gian")
        assertEquals(com.hypernexus.nit.web.WebGameDevelopmentEngine.WebGameGenre.CYBER_SNAKE_QUANTUM, g4)

        val g5 = com.hypernexus.nit.web.WebGameDevelopmentEngine.matchGameGenreFromCommand("dựng game mê cung 3d góc nhìn thứ nhất raycasting")
        assertEquals(com.hypernexus.nit.web.WebGameDevelopmentEngine.WebGameGenre.WEBGL_3D_RAYCAST_MAZE, g5)

        val g6 = com.hypernexus.nit.web.WebGameDevelopmentEngine.matchGameGenreFromCommand("code game thủ trụ phòng thủ chiến thuật tower defense")
        assertEquals(com.hypernexus.nit.web.WebGameDevelopmentEngine.WebGameGenre.CYBER_TOWER_DEFENSE, g6)
    }

    @Test
    fun testWebGameCodeGenerationAndFiles() {
        com.hypernexus.nit.web.WebGameDevelopmentEngine.WebGameGenre.values().forEach { genre ->
            val project = com.hypernexus.nit.web.WebGameDevelopmentEngine.generateGameProject(genre, "Game Test ${genre.name}")
            org.junit.Assert.assertNotNull(project)
            assertTrue("Dự án game phải có ít nhất 4 file", project.files.size >= 4)
            assertTrue("Phải có index.html", project.files.containsKey("index.html"))
            assertTrue("Phải có style.css", project.files.containsKey("style.css"))
            assertTrue("Phải có app.js", project.files.containsKey("app.js"))
            assertTrue("Phải có manifest.json", project.files.containsKey("manifest.json"))

            val jsCode = project.files["app.js"]!!.content
            assertTrue("app.js phải chứa requestAnimationFrame", jsCode.contains("requestAnimationFrame"))

            val htmlCode = project.files["index.html"]!!.content
            assertTrue("index.html phải có canvas", htmlCode.contains("<canvas"))
        }
    }

    @Test
    fun testWebGameCodeValidation() {
        val project = com.hypernexus.nit.web.WebGameDevelopmentEngine.generateGameProject(
            com.hypernexus.nit.web.WebGameDevelopmentEngine.WebGameGenre.CYBER_SPACE_SHOOTER
        )
        val validation = com.hypernexus.nit.web.WebGameDevelopmentEngine.validateGameCode(project)

        assertTrue("Mã nguồn game phải hợp lệ", validation.isValid)
        assertTrue("Game phải hỗ trợ 120 FPS Delta-Time Game Loop", validation.hasGameLoopDeltaTime)
        assertTrue("Game phải hỗ trợ Web Audio API Synthesizer", validation.hasWebAudioSynth)
        assertTrue("Game phải có điều khiển Touch", validation.hasTouchControls)
        assertTrue("Điểm chất lượng phải >= 85", validation.qualityScore >= 85)
        assertTrue("Phải phát hiện ít nhất 3 tính năng game", validation.features.size >= 3)
    }

    @Test
    fun testWebGameTaskPlanDecomposition() {
        val goal = "lập kế hoạch tạo game bắn phi thuyền không gian lúc 9 giờ tối"
        val plan = com.hypernexus.nit.planner.CognitiveTaskReasoner.reasonAndCreatePlan(goal)

        org.junit.Assert.assertNotNull(plan)
        assertTrue("Kế hoạch game phải có ít nhất 3 bước", plan.steps.size >= 3)
        assertEquals(com.hypernexus.nit.planner.ActionType.WEB_DEVELOP, plan.steps[0].actionType)
        assertEquals("CYBER_SPACE_SHOOTER", plan.steps[0].params["GAME_GENRE"])
        assertEquals(com.hypernexus.nit.planner.ActionType.WEB_HOST_LOCAL, plan.steps[1].actionType)
        assertEquals("CYBER_SPACE_SHOOTER", plan.steps[1].params["GAME_GENRE"])
        assertEquals(com.hypernexus.nit.planner.ActionType.VOICE_NOTIFY, plan.steps[2].actionType)
    }

    @Test
    fun testWebGameRouterIntentRecognition() {
        val cmd1 = "nít ơi lập trình game bắn phi thuyền không gian"
        val isGame1 = cmd1.contains("game web") || cmd1.contains("game trên web") || cmd1.contains("trò chơi web") || (cmd1.contains("game") && (cmd1.contains("lập trình") || cmd1.contains("code") || cmd1.contains("tạo") || cmd1.contains("thiết kế"))) || cmd1.contains("bắn phi thuyền") || cmd1.contains("phá gạch") || cmd1.contains("rắn săn mồi") || cmd1.contains("mê cung 3d") || cmd1.contains("thủ trụ")
        assertTrue(isGame1)

        val cmd2 = "code game mê cung 3d raycasting"
        val isGame2 = cmd2.contains("game web") || cmd2.contains("game trên web") || cmd2.contains("trò chơi web") || (cmd2.contains("game") && (cmd2.contains("lập trình") || cmd2.contains("code") || cmd2.contains("tạo") || cmd2.contains("thiết kế"))) || cmd2.contains("bắn phi thuyền") || cmd2.contains("phá gạch") || cmd2.contains("rắn săn mồi") || cmd2.contains("mê cung 3d") || cmd2.contains("thủ trụ")
        assertTrue(isGame2)
    }

    @Test
    fun testDynamicGamePromptDetection() {
        // Nhận diện các mô tả game tự do không bị bó buộc theo mẫu cố định
        val promptFish = "lập trình game cá lớn nuốt cá bé đại dương neon"
        assertTrue(com.hypernexus.nit.web.DynamicGameSynthesisEngine.isCustomGamePrompt(promptFish))

        val promptCar = "làm game đua xe tránh xe tải nhặt bình xăng nitro màu đỏ"
        assertTrue(com.hypernexus.nit.web.DynamicGameSynthesisEngine.isCustomGamePrompt(promptCar))

        val promptSpaceDodge = "tạo game né thiên thạch thu thập ngọc có khiên năng lượng"
        assertTrue(com.hypernexus.nit.web.DynamicGameSynthesisEngine.isCustomGamePrompt(promptSpaceDodge))

        val promptArena = "lập trình trò chơi đấu trường sinh tồn 360 độ bắn zombie bao vây"
        assertTrue(com.hypernexus.nit.web.DynamicGameSynthesisEngine.isCustomGamePrompt(promptArena))

        val promptReflex = "game phản xạ mục tiêu bấm nhanh điểm cao"
        assertTrue(com.hypernexus.nit.web.DynamicGameSynthesisEngine.isCustomGamePrompt(promptReflex))

        val promptGeneralCustom = "lập trình game web theo mô tả của tôi độc bản"
        assertTrue(com.hypernexus.nit.web.DynamicGameSynthesisEngine.isCustomGamePrompt(promptGeneralCustom))
    }

    @Test
    fun testDynamicGameSpecSemanticParsing() {
        // 1. Game cá lớn nuốt cá bé
        val specFish = com.hypernexus.nit.web.DynamicGameSynthesisEngine.parseGameSpecFromPrompt("lập trình game cá lớn nuốt cá bé đại dương màu xanh lá")
        assertEquals(com.hypernexus.nit.web.DynamicGameSynthesisEngine.GameArchetype.EAT_AND_GROW_EVOLUTION, specFish.archetype)
        assertEquals("#14F195", specFish.playerColor)
        assertTrue(specFish.playerLabel.contains("Fish"))
        assertTrue(specFish.hazardLabel.contains("Kẻ Săn Mồi"))

        // 2. Game đua xe tránh chướng ngại vật có nitro
        val specCar = com.hypernexus.nit.web.DynamicGameSynthesisEngine.parseGameSpecFromPrompt("game đua xe tránh chướng ngại vật màu đỏ có tăng tốc nitro")
        assertEquals(com.hypernexus.nit.web.DynamicGameSynthesisEngine.GameArchetype.CAR_HIGHWAY_RUNNER, specCar.archetype)
        assertEquals("#FF0055", specCar.playerColor)
        assertTrue(specCar.hasNitroBoost)
        assertTrue(specCar.collectibleLabel.contains("Nhiên Liệu"))

        // 3. Game né thiên thạch có khiên bảo vệ
        val specSpace = com.hypernexus.nit.web.DynamicGameSynthesisEngine.parseGameSpecFromPrompt("game né thiên thạch thu thập vàng có khiên bảo vệ màu tím")
        assertEquals(com.hypernexus.nit.web.DynamicGameSynthesisEngine.GameArchetype.COSMIC_DODGE_AND_COLLECT, specSpace.archetype)
        assertEquals("#A855F7", specSpace.playerColor)
        assertTrue(specSpace.hasShieldPowerup)

        // 4. Game đấu trường bắn quái
        val specArena = com.hypernexus.nit.web.DynamicGameSynthesisEngine.parseGameSpecFromPrompt("game đấu trường sinh tồn bắn quái vật bao vây")
        assertEquals(com.hypernexus.nit.web.DynamicGameSynthesisEngine.GameArchetype.ARENA_TWIN_STICK_SURVIVAL, specArena.archetype)
        assertTrue(specArena.hasShootingMechanic)
    }

    @Test
    fun testDynamicGameCodeSynthesisAnd120FpsValidation() {
        val testPrompts = listOf(
            "lập trình game cá lớn nuốt cá bé đại dương neon",
            "game đua xe tránh chướng ngại vật nhặt bình xăng nitro",
            "game né thiên thạch thu thập ngọc có khiên năng lượng",
            "game đấu trường sinh tồn 360 độ bắn quái bao vây"
        )

        testPrompts.forEach { prompt ->
            val project = com.hypernexus.nit.web.DynamicGameSynthesisEngine.synthesizeGameFromPrompt(prompt)
            org.junit.Assert.assertNotNull(project)
            assertTrue("Dự án game độc bản phải có ít nhất 4 file", project.files.size >= 4)
            assertTrue("Phải có index.html", project.files.containsKey("index.html"))
            assertTrue("Phải có style.css", project.files.containsKey("style.css"))
            assertTrue("Phải có app.js", project.files.containsKey("app.js"))
            assertTrue("Phải có manifest.json", project.files.containsKey("manifest.json"))

            // Kiểm định chất lượng W3C và 120 FPS
            val validation = com.hypernexus.nit.web.WebGameDevelopmentEngine.validateGameCode(project)
            assertTrue("Mã nguồn game độc bản phải hợp lệ", validation.isValid)
            assertTrue("Game phải hỗ trợ 120 FPS Delta-Time Game Loop", validation.hasGameLoopDeltaTime)
            assertTrue("Game phải hỗ trợ Web Audio API Sound Synthesizer", validation.hasWebAudioSynth)
            assertTrue("Game phải có Touch Controls ảo", validation.hasTouchControls)
            assertTrue("Game phải có LocalStorage lưu điểm", validation.hasLocalStorageScore)
            assertEquals("Điểm chất lượng chuẩn mực phải đạt tối đa 100", 100, validation.qualityScore)

            val jsCode = project.files["app.js"]!!.content
            assertTrue("JS phải chứa requestAnimationFrame", jsCode.contains("requestAnimationFrame"))
            assertTrue("JS phải chứa AudioContext", jsCode.contains("AudioContext"))
            assertTrue("JS phải chứa performance.now()", jsCode.contains("performance.now()"))
        }
    }

    @Test
    fun testDynamicGameTaskPlanDecomposition() {
        val customGoal = "lập kế hoạch tạo game cá lớn nuốt cá bé đại dương lúc 8 giờ tối"
        val plan = com.hypernexus.nit.planner.CognitiveTaskReasoner.reasonAndCreatePlan(customGoal)

        org.junit.Assert.assertNotNull(plan)
        assertTrue("Kế hoạch game độc bản phải có ít nhất 3 bước", plan.steps.size >= 3)
        assertEquals(com.hypernexus.nit.planner.ActionType.WEB_DEVELOP, plan.steps[0].actionType)
        assertTrue("Params bước 1 phải chứa CUSTOM_GAME_PROMPT", plan.steps[0].params.containsKey("CUSTOM_GAME_PROMPT"))
        assertEquals(customGoal, plan.steps[0].params["CUSTOM_GAME_PROMPT"])

        assertEquals(com.hypernexus.nit.planner.ActionType.WEB_HOST_LOCAL, plan.steps[1].actionType)
        assertTrue("Params bước 2 phải chứa CUSTOM_GAME_PROMPT", plan.steps[1].params.containsKey("CUSTOM_GAME_PROMPT"))

        assertEquals(com.hypernexus.nit.planner.ActionType.VOICE_NOTIFY, plan.steps[2].actionType)
        assertTrue("Tiêu đề kế hoạch phải thể hiện tính độc bản", plan.title.contains("Độc Bản"))
    }

    @Test
    fun testDynamic3DPromptDetection() {
        val p1 = "dựng 3d chiếc cốc uống nước lòng rỗng thành dày"
        assertTrue(com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.isCustom3DPrompt(p1))

        val p2 = "thiết kế 3d vỏ hộp tai nghe bluetooth vát cạnh"
        assertTrue(com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.isCustom3DPrompt(p2))

        val p3 = "vẽ mô hình 3d bánh răng 18 răng có lỗ trục lục giác"
        assertTrue(com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.isCustom3DPrompt(p3))

        val p4 = "dựng 3d bình hoa xoắn ốc lượn sóng"
        assertTrue(com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.isCustom3DPrompt(p4))

        val p5 = "tạo mô hình 3d chân đế tam giác kẹp dây"
        assertTrue(com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.isCustom3DPrompt(p5))
    }

    @Test
    fun testDynamic3DSpecSemanticParsing() {
        // 1. Cốc uống nước
        val spec1 = com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.parse3DSpecFromPrompt("dựng 3d chiếc cốc uống nước lòng rỗng thành dày")
        assertEquals(com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.GeometricPrimitive.HOLLOW_CYLINDER_VESSEL, spec1.primitive)
        assertTrue(spec1.hasHollowCavity)
        assertTrue(spec1.wallThickness >= 0.35f)

        // 2. Vỏ hộp tai nghe
        val spec2 = com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.parse3DSpecFromPrompt("vỏ hộp tai nghe bluetooth vát cạnh")
        assertEquals(com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.GeometricPrimitive.CHAMFERED_BOX_ENCLOSURE, spec2.primitive)

        // 3. Bánh răng có lỗ trục
        val spec3 = com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.parse3DSpecFromPrompt("bánh răng 18 răng có lỗ trục lục giác")
        assertEquals(com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.GeometricPrimitive.PARAMETRIC_MECHANICAL_GEAR, spec3.primitive)
        assertTrue(spec3.hasCenterBoreHole)

        // 4. Bình hoa xoắn ốc
        val spec4 = com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.parse3DSpecFromPrompt("bình hoa xoắn ốc lượn sóng")
        assertEquals(com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.GeometricPrimitive.PARAMETRIC_TWISTED_HELIX, spec4.primitive)
        assertTrue(spec4.twistAngleRad > 0f)

        // 5. Chân đế tam giác
        val spec5 = com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.parse3DSpecFromPrompt("chân đế tam giác giá đỡ để bàn")
        assertEquals(com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.GeometricPrimitive.TRIANGULAR_MOUNT_STAND, spec5.primitive)
    }

    @Test
    fun testDynamic3DMeshSynthesisAndWatertightManifold() {
        val testPrompts = listOf(
            "dựng 3d chiếc cốc uống nước lòng rỗng thành dày",
            "thiết kế 3d vỏ hộp tai nghe bluetooth vát cạnh",
            "vẽ mô hình 3d bánh răng 18 răng có lỗ trục",
            "dựng 3d bình hoa xoắn ốc lượn sóng",
            "tạo mô hình 3d chân đế tam giác kẹp dây"
        )

        testPrompts.forEach { prompt ->
            val mesh = com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.synthesize3DMeshFromPrompt(prompt)
            org.junit.Assert.assertNotNull(mesh)
            assertTrue("Đỉnh không được rỗng", mesh.vertices.isNotEmpty())
            assertTrue("Normals không được rỗng", mesh.normals.isNotEmpty())
            assertTrue("Indices không được rỗng", mesh.indices.isNotEmpty())
            assertEquals("Vertices phải là bộ 3 tọa độ", 0, mesh.vertices.size % 3)
            assertEquals("Normals phải là bộ 3 tọa độ", 0, mesh.normals.size % 3)
            assertEquals("Indices phải chia hết cho 3", 0, mesh.indices.size % 3)
            assertEquals(mesh.indices.size / 3, mesh.triangleCount)
            assertTrue("Mô hình phải có ít nhất 100 tam giác", mesh.triangleCount >= 100)

            // Phân tích kỹ thuật máy in 3D Slicer
            val analysis = com.hypernexus.nit.engine.Procedural3DGenerator.analyzeMeshFor3DPrinting(mesh)
            assertTrue("Thể tích đùn nhựa phải > 0", analysis.volumeCm3 > 0f)
            assertTrue("Khối lượng nhựa PLA phải > 0", analysis.weightGramsPla > 0f)
            assertTrue("Thời gian in ước tính phải > 0", analysis.estimatedPrintTimeMinutes > 0)
            assertTrue("Mô hình phải đạt chuẩn 2-Manifold kín nước (Watertight)", analysis.isWatertight)
        }
    }

    @Test
    fun testDynamic3DTaskPlanDecomposition() {
        val goal = "lập kế hoạch dựng 3d chiếc cốc uống nước lòng rỗng lúc 8 giờ tối"
        val plan = com.hypernexus.nit.planner.CognitiveTaskReasoner.reasonAndCreatePlan(goal)

        org.junit.Assert.assertNotNull(plan)
        assertTrue("Kế hoạch 3D độc bản phải có ít nhất 3 bước", plan.steps.size >= 3)
        assertEquals(com.hypernexus.nit.planner.ActionType.GENERATE_3D_MODEL, plan.steps[0].actionType)
        assertTrue("Bước 1 phải chứa CUSTOM_3D_PROMPT", plan.steps[0].params.containsKey("CUSTOM_3D_PROMPT"))
        assertEquals(com.hypernexus.nit.planner.ActionType.SLICER_ANALYZE, plan.steps[1].actionType)
        assertTrue("Bước 2 phải chứa CUSTOM_3D_PROMPT", plan.steps[1].params.containsKey("CUSTOM_3D_PROMPT"))
        assertEquals(com.hypernexus.nit.planner.ActionType.EXPORT_3D_PRINT, plan.steps[2].actionType)
        assertTrue("Tiêu đề kế hoạch phải thể hiện tính độc bản", plan.title.contains("Độc Bản") || plan.title.contains("độc bản"))
    }

    @Test
    fun testDynamicCapCutPromptDetection() {
        val p1 = "edit video review quán ăn ấm cúng nhạc acoustic màu vintage"
        assertTrue(com.hypernexus.nit.video.DynamicCapCutSynthesisEngine.isCustomCapCutPrompt(p1))

        val p2 = "làm video gaming kịch tính chuyển cảnh giật nhanh nhạc trap rock"
        assertTrue(com.hypernexus.nit.video.DynamicCapCutSynthesisEngine.isCustomCapCutPrompt(p2))

        val p3 = "dựng clip du lịch biển tươi sáng màu teal & orange zoom chậm"
        assertTrue(com.hypernexus.nit.video.DynamicCapCutSynthesisEngine.isCustomCapCutPrompt(p3))

        val p4 = "edit video thời trang sang trọng noir đen trắng chuyển cảnh mờ dần"
        assertTrue(com.hypernexus.nit.video.DynamicCapCutSynthesisEngine.isCustomCapCutPrompt(p4))
    }

    @Test
    fun testDynamicCapCutSpecSemanticParsing() {
        // 1. Vlog quán ăn ấm cúng
        val spec1 = com.hypernexus.nit.video.DynamicCapCutSynthesisEngine.parseCapCutSpecFromPrompt("edit video review quán ăn ấm cúng nhạc acoustic màu vintage zoom chậm")
        assertEquals("9:16", spec1.targetAspectRatio)
        assertTrue(spec1.colorFilterName.contains("Vintage") || spec1.colorFilterName.contains("Ấm Áp"))
        assertTrue(spec1.visualEffectName.contains("Zoom"))
        assertTrue(spec1.bgmGenre.contains("Acoustic"))
        assertTrue(spec1.enableAudioDucking)

        // 2. Gaming kịch tính
        val spec2 = com.hypernexus.nit.video.DynamicCapCutSynthesisEngine.parseCapCutSpecFromPrompt("làm video gaming kịch tính giật nhanh nhạc trap rock 16:9")
        assertEquals("16:9", spec2.targetAspectRatio)
        assertEquals(1.5f, spec2.cutPacingIntervalSeconds, 0.01f)
        assertTrue(spec2.bgmGenre.contains("Trap Rock"))

        // 3. Thời trang Noir đen trắng
        val spec3 = com.hypernexus.nit.video.DynamicCapCutSynthesisEngine.parseCapCutSpecFromPrompt("dựng clip thời trang sang trọng đen trắng chuyển cảnh mờ dần")
        assertTrue(spec3.colorFilterName.contains("Noir") || spec3.colorFilterName.contains("Monochrome"))
        assertTrue(spec3.transitionStyle.contains("Mềm Mại") || spec3.transitionStyle.contains("Dissolve"))
    }

    @Test
    fun testDynamicCapCutTaskPlanDecomposition() {
        val goal = "lập kế hoạch edit video review đồ ăn ấm cúng nhạc acoustic lúc 7 giờ tối"
        val plan = com.hypernexus.nit.planner.CognitiveTaskReasoner.reasonAndCreatePlan(goal)

        org.junit.Assert.assertNotNull(plan)
        assertTrue("Kế hoạch CapCut độc bản phải có ít nhất 2 bước", plan.steps.size >= 2)
        assertEquals(com.hypernexus.nit.planner.ActionType.CAPCUT_MACRO, plan.steps[0].actionType)
        assertTrue("Bước 1 phải chứa CUSTOM_CAPCUT_PROMPT", plan.steps[0].params.containsKey("CUSTOM_CAPCUT_PROMPT"))
        assertEquals(com.hypernexus.nit.planner.ActionType.VOICE_NOTIFY, plan.steps[1].actionType)
        assertTrue("Tiêu đề kế hoạch phải thể hiện tính độc bản", plan.title.contains("Độc Bản"))
    }
}



