package com.hypernexus.nit.web

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

object WebArticleScraper {

    private const val TAG = "WebArticleScraper"
    private val client = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .build()

    // Giới hạn độ dài văn bản trích xuất: 2.500 ký tự (~600 tokens) để bảo đảm KV-cache không vượt 2.048 tokens
    private const val MAX_EXTRACT_CHARS = 2500

    /**
     * TẢI VÀ BÓC TÁCH NỘI DUNG VĂN BẢN TỪ BẤT KỲ ĐƯỜNG LINK TRANG WEB NÀO
     */
    suspend fun scrapeCleanTextFromUrl(url: String): String = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder()
                .url(url)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; SM-G990E) AppleWebKit/537.36")
                .build()

            val response = client.newCall(request).execute()
            val html = response.body?.string() ?: return@withContext "Không thể tải nội dung trang web."

            // 1. Loại bỏ các thẻ script, style, svg, header, footer, nav
            var cleanHtml = html
                .replace(Regex("(?i)<script.*?</script>", RegexOption.DOT_MATCHES_ALL), " ")
                .replace(Regex("(?i)<style.*?</style>", RegexOption.DOT_MATCHES_ALL), " ")
                .replace(Regex("(?i)<nav.*?</nav>", RegexOption.DOT_MATCHES_ALL), " ")
                .replace(Regex("(?i)<footer.*?</footer>", RegexOption.DOT_MATCHES_ALL), " ")
                .replace(Regex("(?i)<header.*?</header>", RegexOption.DOT_MATCHES_ALL), " ")

            // 2. Lấy toàn bộ các đoạn văn bản trong thẻ <p> và <h1..h6>
            val paragraphPattern = Pattern.compile("<(p|h1|h2|h3)[^>]*>(.*?)</\\1>", Pattern.CASE_INSENSITIVE or Pattern.DOTALL)
            val matcher = paragraphPattern.matcher(cleanHtml)
            val extractedText = StringBuilder()

            while (matcher.find()) {
                val rawText = matcher.group(2)?.replace(Regex("<.*?>"), "")?.trim() ?: ""
                if (rawText.length > 25) { // Bỏ qua các đoạn text ngắn rác hoặc nút bấm
                    extractedText.append(rawText).append("\n\n")
                    if (extractedText.length >= MAX_EXTRACT_CHARS) break
                }
            }

            val finalOutput = if (extractedText.isNotEmpty()) {
                extractedText.toString().take(MAX_EXTRACT_CHARS)
            } else {
                // Fallback nếu trang web không dùng thẻ chuẩn: xóa toàn bộ HTML tag
                cleanHtml.replace(Regex("<.*?>"), " ").replace(Regex("\\s+"), " ").trim().take(MAX_EXTRACT_CHARS)
            }

            Log.d(TAG, "Bóc tách thành công ${finalOutput.length} ký tự từ: $url")
            return@withContext finalOutput

        } catch (e: Exception) {
            Log.e(TAG, "Lỗi bóc tách trang web: ${e.message}")
            return@withContext "Lỗi khi đọc trang web: ${e.message}"
        }
    }
}
