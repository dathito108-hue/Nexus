package com.hypernexus.nit.planner

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * BỘ QUẢN LÝ LẬP KẾ HOẠCH & LỊCH TRÌNH TỰ HÀNH (TASK PLANNING MANAGER)
 * Quản lý hẹn giờ chính xác qua AlarmManager và giám sát điều kiện ngầm (Condition Monitor).
 */
object TaskPlanningManager {

    private const val TAG = "TaskPlanningManager"
    private var isConditionMonitorRunning = false

    /**
     * ĐĂNG KÝ VÀ LÊN LỊCH THỰC THI CHO KẾ HOẠCH
     */
    fun schedulePlan(context: Context, plan: TaskPlan) {
        val dbHelper = PlanDatabaseHelper(context)
        dbHelper.savePlan(plan)

        when (plan.triggerType) {
            TriggerType.IMMEDIATE -> {
                Log.d(TAG, "Kích hoạt kế hoạch ngay lập tức: ${plan.title}")
                CoroutineScope(Dispatchers.IO).launch {
                    AutonomousExecutionEngine.executePlan(context, plan)
                }
            }

            TriggerType.EXACT_TIME -> {
                scheduleExactAlarm(context, plan)
            }

            TriggerType.PERIODIC -> {
                scheduleExactAlarm(context, plan)
            }

            TriggerType.MARKET_CONDITION, TriggerType.DEVICE_CONDITION -> {
                Log.d(TAG, "Đã đưa kế hoạch vào giám sát điều kiện ngầm: ${plan.title}")
                startConditionMonitorIfNeeded(context)
            }
        }
    }

    private fun scheduleExactAlarm(context: Context, plan: TaskPlan) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager ?: return
        val intent = Intent(context, TaskSchedulerReceiver::class.java).apply {
            action = TaskSchedulerReceiver.ACTION_EXECUTE_PLAN
            putExtra(TaskSchedulerReceiver.EXTRA_PLAN_ID, plan.planId)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            plan.planId.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val triggerAt = if (plan.triggerTimeMs > System.currentTimeMillis()) {
            plan.triggerTimeMs
        } else {
            System.currentTimeMillis() + 10_000L // 10 giây sau nếu quá giờ
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        } else {
            alarmManager.setExact(AlarmManager.RTC_WAKEUP, triggerAt, pendingIntent)
        }

        Log.d(TAG, "Đã lên lịch AlarmManager cho kế hoạch [${plan.title}] lúc: $triggerAt")
    }

    fun cancelPlan(context: Context, planId: String) {
        val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager
        val intent = Intent(context, TaskSchedulerReceiver::class.java).apply {
            action = TaskSchedulerReceiver.ACTION_EXECUTE_PLAN
            putExtra(TaskSchedulerReceiver.EXTRA_PLAN_ID, planId)
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            planId.hashCode(),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null && alarmManager != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }

        val dbHelper = PlanDatabaseHelper(context)
        dbHelper.updatePlanStatus(planId, PlanStatus.CANCELLED)
        Log.d(TAG, "Đã hủy kế hoạch: $planId")
    }

    /**
     * BỘ GIÁM SÁT ĐIỀU KIỆN NGẦM (CONDITION MONITOR ENGINE)
     * Quét định kỳ 60 giây kiểm tra điều kiện thị trường hoặc thiết bị để tự động kích hoạt.
     */
    private fun startConditionMonitorIfNeeded(context: Context) {
        if (isConditionMonitorRunning) return
        isConditionMonitorRunning = true

        CoroutineScope(Dispatchers.IO).launch {
            Log.d(TAG, "Khởi động luồng giám sát điều kiện ngầm...")
            while (isActive) {
                try {
                    val dbHelper = PlanDatabaseHelper(context)
                    val activePlans = dbHelper.getAllActivePlans()
                    val conditionPlans = activePlans.filter {
                        it.triggerType == TriggerType.MARKET_CONDITION || it.triggerType == TriggerType.DEVICE_CONDITION
                    }

                    if (conditionPlans.isNotEmpty()) {
                        for (plan in conditionPlans) {
                            // Giả lập kiểm tra điều kiện (hoặc lấy từ API thật)
                            val conditionMet = checkCondition(context, plan)
                            if (conditionMet) {
                                Log.d(TAG, "Điều kiện thỏa mãn! Kích hoạt tự hành: ${plan.title}")
                                AutonomousExecutionEngine.executePlan(context, plan)
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Lỗi kiểm tra điều kiện: ${e.message}")
                }
                delay(60_000L) // Quét mỗi 60 giây
            }
        }
    }

    private suspend fun checkCondition(context: Context, plan: TaskPlan): Boolean {
        val cond = plan.triggerCondition?.lowercase() ?: return false
        if (cond.contains("charging") || cond.contains("cắm sạc")) {
            val bm = context.getSystemService(Context.BATTERY_SERVICE) as? android.os.BatteryManager
            val isCharging = bm?.isCharging == true
            return isCharging
        }
        // Các điều kiện thị trường có thể kiểm tra qua SolanaDexDataManager
        return false
    }

    fun getActivePlans(context: Context): List<TaskPlan> {
        val dbHelper = PlanDatabaseHelper(context)
        return dbHelper.getAllActivePlans()
    }
}
