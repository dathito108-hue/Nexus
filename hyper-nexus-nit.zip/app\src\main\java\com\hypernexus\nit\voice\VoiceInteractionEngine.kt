package com.hypernexus.nit.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import com.hypernexus.nit.overlay.MicroRobotOverlayService
import com.hypernexus.nit.router.SystemRouter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.util.Locale

class VoiceInteractionEngine(private val context: Context) : TextToSpeech.OnInitListener {

    companion object {
        private const val TAG = "VoiceInteractionEngine"
        private const val UTTERANCE_ID = "NIT_REPLY_VOICE"
    }

    private var textToSpeech: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private val systemRouter = SystemRouter(context)
    private val engineScope = CoroutineScope(Dispatchers.Main)
    private var isTtsReady = false

    init {
        textToSpeech = TextToSpeech(context, this)
        initSpeechRecognizer()
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val result = textToSpeech?.setLanguage(Locale("vi", "VN"))
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                textToSpeech?.setLanguage(Locale.US)
            }
            textToSpeech?.setPitch(1.1f)     // Giọng robot AI trẻ trung, nhanh nhẹn
            textToSpeech?.setSpeechRate(1.15f) // Tốc độ nói mượt mà
            isTtsReady = true

            textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    MicroRobotOverlayService.updateState(MicroRobotOverlayService.RobotState.ACTION)
                }
                override fun onDone(utteranceId: String?) {
                    // Sau khi nói xong, đưa robot về chế độ ngủ sâu
                    MicroRobotOverlayService.updateState(MicroRobotOverlayService.RobotState.SLEEP)
                }
                override fun onError(utteranceId: String?) {
                    MicroRobotOverlayService.updateState(MicroRobotOverlayService.RobotState.SLEEP)
                }
            })
        }
    }

    private fun initSpeechRecognizer() {
        if (SpeechRecognizer.isRecognitionAvailable(context)) {
            speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                setRecognitionListener(object : RecognitionListener {
                    override fun onReadyForSpeech(params: Bundle?) {
                        MicroRobotOverlayService.updateState(MicroRobotOverlayService.RobotState.LISTENING)
                    }
                    override fun onBeginningOfSpeech() {}
                    override fun onRmsChanged(rmsdB: Float) {}
                    override fun onBufferReceived(buffer: ByteArray?) {}
                    override fun onEndOfSpeech() {
                        MicroRobotOverlayService.updateState(MicroRobotOverlayService.RobotState.THINKING)
                    }
                    override fun onError(error: Int) {
                        Log.e(TAG, "Lỗi nhận dạng giọng nói: $error")
                        MicroRobotOverlayService.updateState(MicroRobotOverlayService.RobotState.SLEEP)
                    }
                    override fun onResults(results: Bundle?) {
                        val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        if (!matches.isNullOrEmpty()) {
                            val userText = matches[0]
                            Log.d(TAG, "Người dùng đã nói: $userText")
                            processUserVoiceCommand(userText)
                        } else {
                            MicroRobotOverlayService.updateState(MicroRobotOverlayService.RobotState.SLEEP)
                        }
                    }
                    override fun onPartialResults(partialResults: Bundle?) {}
                    override fun onEvent(eventType: Int, params: Bundle?) {}
                })
            }
        }
    }

    /**
     * Bắt đầu lắng nghe lệnh giọng nói sau khi nghe từ khóa "Nít"
     */
    fun startListeningToUser() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "vi-VN")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        speechRecognizer?.startListening(intent)
    }

    /**
     * Xử lý câu lệnh và phản hồi bằng giọng nói
     */
    private fun processUserVoiceCommand(command: String) {
        engineScope.launch {
            MicroRobotOverlayService.updateState(MicroRobotOverlayService.RobotState.THINKING)
            val replyText = systemRouter.routeCommandAsync(command)
            speak(replyText)
        }
    }

    /**
     * Phát âm thanh phản hồi ra loa với khả năng thích ứng cảm xúc & thời gian
     */
    fun speak(text: String, emotion: AdaptiveVoiceEngine.VoiceEmotion? = null) {
        if (isTtsReady) {
            AdaptiveVoiceEngine.applyAdaptiveVoiceSettings(context, textToSpeech, emotion)
            textToSpeech?.speak(text, TextToSpeech.QUEUE_FLUSH, null, UTTERANCE_ID)
        }
    }

    fun destroy() {
        speechRecognizer?.destroy()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
    }
}
