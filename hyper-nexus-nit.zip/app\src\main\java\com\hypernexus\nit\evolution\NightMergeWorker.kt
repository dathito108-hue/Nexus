package com.hypernexus.nit.evolution

import android.content.Context
import android.util.Log
import androidx.work.Constraints
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import com.hypernexus.nit.engine.LlamaEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.util.concurrent.TimeUnit

class NightMergeWorker(
    context: Context,
    workerParams: WorkerParameters
) : CoroutineWorker(context, workerParams) {

    companion object {
        private const val TAG = "NightMergeEvolution"
        private const val WORK_NAME = "hyper_nexus_night_evolution"

        /**
         * Lập lịch tự động tiến hóa trọng số mỗi đêm khi cắm sạc
         */
        fun scheduleNightEvolution(context: Context) {
            val constraints = Constraints.Builder()
                .setRequiresCharging(true)       // Bắt buộc: Đang cắm sạc
                .setRequiresDeviceIdle(true)       // Bắt buộc: Máy đang nghỉ (Màn hình tắt ban đêm)
                .build()

            val request = PeriodicWorkRequestBuilder<NightMergeWorker>(24, TimeUnit.HOURS)
                .setConstraints(constraints)
                .build()

            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME,
                ExistingPeriodicWorkPolicy.KEEP,
                request
            )
            Log.d(TAG, "Đã lên lịch tiến hóa Night-Merge thành công.")
        }
    }

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        Log.d(TAG, "Bắt đầu tiến trình tự học và tiến hóa Night-Merge trên Samsung S21 FE...")

        val filesDir = applicationContext.filesDir
        val baseGguf = File(filesDir, "qwen1_5b_base.gguf")
        val dailyDeltaLora = File(filesDir, "daily_learning.lora")

        if (!baseGguf.exists()) {
            Log.w(TAG, "Chưa tìm thấy file mô hình gốc để hợp nhất.")
            return@withContext Result.success()
        }

        // Thực hiện vi huấn luyện và hợp nhất trọng số vĩnh viễn (W_new = W_base + alpha * deltaW)
        val success = LlamaEngine.mergeLoRAWeights(
            baseGguf.absolutePath,
            dailyDeltaLora.absolutePath,
            0.15f
        )

        if (success) {
            Log.d(TAG, "Tiến hóa hoàn tất: Trọng số của Nít đã biến đổi vĩnh viễn theo chủ nhân!")
            Result.success()
        } else {
            Result.retry()
        }
    }
}
