package com.hypernexus.nit.voice

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.core.app.NotificationCompat
import com.hypernexus.nit.overlay.MicroRobotOverlayService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlin.math.sqrt

class WakeWordService : Service() {

    private val serviceScope = CoroutineScope(Dispatchers.IO + Job())
    private val mainHandler = Handler(Looper.getMainLooper())
    private var currentWakeWord = "Nít"
    private var audioRecord: AudioRecord? = null
    private var isListening = false
    private var voiceEngine: VoiceInteractionEngine? = null

    companion object {
        private const val SAMPLE_RATE = 16000
        private const val CHANNEL_CONFIG = AudioFormat.CHANNEL_IN_MONO
        private const val AUDIO_FORMAT = AudioFormat.ENCODING_PCM_16BIT
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        voiceEngine = VoiceInteractionEngine(this)
        startForegroundServiceNotification()
        startAudioCaptureEngine()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val newName = intent?.getStringExtra("CUSTOM_NAME")
        if (!newName.isNullOrEmpty()) {
            currentWakeWord = newName.trim()
            updateForegroundNotification()
        }
        return START_STICKY
    }

    /**
     * Vòng lặp thu âm siêu nhẹ với VAD (Voice Activity Detection) chạy ngầm
     */
    @SuppressLint("MissingPermission")
    private fun startAudioCaptureEngine() {
        val minBufferSize = AudioRecord.getMinBufferSize(SAMPLE_RATE, CHANNEL_CONFIG, AUDIO_FORMAT)
        audioRecord = AudioRecord(
            MediaRecorder.AudioSource.MIC,
            SAMPLE_RATE,
            CHANNEL_CONFIG,
            AUDIO_FORMAT,
            minBufferSize
        )

        audioRecord?.startRecording()
        isListening = true

        serviceScope.launch {
            val audioBuffer = ShortArray(minBufferSize)
            var consecutiveLoudFrames = 0

            while (isActive && isListening) {
                val readSize = audioRecord?.read(audioBuffer, 0, minBufferSize) ?: 0
                if (readSize > 0) {
                    var sum = 0.0
                    for (i in 0 until readSize) {
                        sum += audioBuffer[i] * audioBuffer[i]
                    }
                    val rms = sqrt(sum / readSize)

                    if (rms > 1800) {
                        consecutiveLoudFrames++
                        if (consecutiveLoudFrames in 3..12) {
                            consecutiveLoudFrames = 0
                            onWakeWordTriggered()
                        }
                    } else {
                        consecutiveLoudFrames = 0
                    }
                }
            }
        }
    }

    private fun onWakeWordTriggered() {
        // Rung haptic nhẹ trên S21 FE báo hiệu đã nghe
        triggerHapticFeedback()

        // Đổi màu mắt LED của Micro-Robot sang Xanh Neon (Listening)
        MicroRobotOverlayService.updateState(MicroRobotOverlayService.RobotState.LISTENING)

        // Tạm dừng mic KWS để nhường quyền cho bộ nhận dạng giọng nói STT
        mainHandler.post {
            voiceEngine?.startListeningToUser()
        }
    }

    private fun triggerHapticFeedback() {
        val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(VibrationEffect.createOneShot(50, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(50)
        }
    }

    private fun startForegroundServiceNotification() {
        val channelId = "hyper_nexus_kws_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Hyper-Nexus Wake Word Sentry",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(channel)
        }

        val notification = buildNotification(channelId)
        startForeground(101, notification)
    }

    private fun updateForegroundNotification() {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(101, buildNotification("hyper_nexus_kws_channel"))
    }

    private fun buildNotification(channelId: String): Notification {
        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Hyper-Nexus (Nít) đang bảo vệ")
            .setContentText("Đang lắng nghe từ khóa: $currentWakeWord (<0.5% pin)")
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .build()
    }

    override fun onDestroy() {
        super.onDestroy()
        isListening = false
        audioRecord?.stop()
        audioRecord?.release()
        voiceEngine?.destroy()
    }
}
