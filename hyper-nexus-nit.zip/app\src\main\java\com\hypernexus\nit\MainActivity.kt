package com.hypernexus.nit

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.hypernexus.nit.accessibility.NitAccessibilityService
import com.hypernexus.nit.engine.ModelManager
import com.hypernexus.nit.evolution.NightMergeWorker
import com.hypernexus.nit.finance.SolanaDexDataManager
import com.hypernexus.nit.mesh.WifiSwarmManager
import com.hypernexus.nit.overlay.MicroRobotOverlayService
import com.hypernexus.nit.voice.VoiceInteractionEngine
import com.hypernexus.nit.voice.WakeWordService
import com.hypernexus.nit.web.WebSearchEngine
import com.hypernexus.nit.view3d.Interactive3DView
import com.hypernexus.nit.engine.Procedural3DGenerator
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var etAiName: EditText
    private lateinit var btnSaveName: Button
    private lateinit var btnToggleOverlay: Button
    private lateinit var btnOpenAccessibility: Button
    private lateinit var tvSwarmStatus: TextView
    private lateinit var btnDownloadModel: Button
    private lateinit var pbDownloadModel: ProgressBar
    private lateinit var tvModelStatus: TextView
    private lateinit var tvGaugeRam: TextView

    // Interactive 3D Viewport 120 FPS & Professional CAD Workshop
    private lateinit var viewport3D: Interactive3DView
    private lateinit var tv3dFpsBadge: TextView
    private lateinit var tv3dMeshInfo: TextView
    private lateinit var btnChipRobot: Button
    private lateinit var btnChipSword: Button
    private lateinit var btnChipSatellite: Button
    private lateinit var btnChipHelmet: Button
    private lateinit var btnChipSpaceship: Button
    private lateinit var btnChipDrone: Button
    private lateinit var btnChipChair: Button
    private lateinit var btnChipGear: Button
    private lateinit var btnChipPhoneStand: Button
    private lateinit var btnChipWrench: Button
    private lateinit var btnChipVase: Button
    private lateinit var btnChipHeatsink: Button
    private lateinit var btn3dCycleShader: Button
    private lateinit var btn3dAnalyzeSlicer: Button
    private lateinit var btn3dToggleGrid: Button
    private lateinit var btn3dExportBinaryStl: Button
    private lateinit var btn3dExportStl: Button
    private lateinit var btn3dExportObj: Button

    private var currentMeshType = Procedural3DGenerator.MeshType.CYBER_ROBOT
    private var currentMeshData: Procedural3DGenerator.MeshData? = null

    // Autonomous Task Planner & Cognitive Scheduler
    private lateinit var etPlannerGoal: EditText
    private lateinit var btnPlanReason: Button
    private lateinit var btnPlanExecuteNow: Button
    private lateinit var btnPlanSchedule: Button
    private lateinit var tvPlanStepsPreview: TextView
    private var currentGeneratedPlan: com.hypernexus.nit.planner.TaskPlan? = null

    // Action Cards
    private lateinit var cardActionSolana: LinearLayout
    private lateinit var cardActionGold: LinearLayout
    private lateinit var cardActionCapcut: LinearLayout
    private lateinit var cardActionWeb: LinearLayout
    private lateinit var cardActionRugcheck: LinearLayout
    private lateinit var cardActionSwap: LinearLayout
    private lateinit var cardActionVision: LinearLayout
    private lateinit var cardActionGesture: LinearLayout
    private lateinit var cardActionRewind: LinearLayout
    private lateinit var cardActionGamebot: LinearLayout
    private lateinit var cardActionInstitutional: LinearLayout
    private lateinit var cardActionBtcMacro: LinearLayout
    private lateinit var cardActionWebStudio: LinearLayout
    private lateinit var cardActionWebServer: LinearLayout
    private lateinit var cardActionGameDev: LinearLayout
    private lateinit var cardActionGamePlay: LinearLayout
    private lateinit var tvTerminalOutput: TextView

    private var isOverlayRunning = false
    private var isGestureActive = false
    private var gestureDriver: com.hypernexus.nit.gesture.FrontCameraGestureDriver? = null
    private var wifiSwarmManager: WifiSwarmManager? = null
    private var voiceEngine: VoiceInteractionEngine? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        voiceEngine = VoiceInteractionEngine(this)
        initViews()
        setup3DViewport()
        setupPlannerCockpit()
        checkModelStatus()
        setupListeners()
        setupActionCards()

        // Khởi động lịch tiến hóa Night-Merge ban đêm
        NightMergeWorker.scheduleNightEvolution(this)

        // Khởi động mạng Wi-Fi Swarm P2P
        setupWifiSwarm()

        // Lắng nghe luồng trạng thái tác tử tự hành phản ứng (StateFlow 120 FPS)
        observeAgentExecutionState()
    }

    private fun initViews() {
        etAiName = findViewById(R.id.et_ai_name)
        btnSaveName = findViewById(R.id.btn_save_name)
        btnToggleOverlay = findViewById(R.id.btn_toggle_overlay)
        btnOpenAccessibility = findViewById(R.id.btn_open_accessibility)
        tvSwarmStatus = findViewById(R.id.tv_swarm_status)
        btnDownloadModel = findViewById(R.id.btn_download_model)
        pbDownloadModel = findViewById(R.id.pb_download_model)
        tvModelStatus = findViewById(R.id.tv_model_status)
        tvGaugeRam = findViewById(R.id.tv_gauge_ram)

        // 3D Viewport Views & Professional CAD
        viewport3D = findViewById(R.id.viewport_3d)
        tv3dFpsBadge = findViewById(R.id.tv_3d_fps_badge)
        tv3dMeshInfo = findViewById(R.id.tv_3d_mesh_info)
        btnChipRobot = findViewById(R.id.btn_chip_robot)
        btnChipSword = findViewById(R.id.btn_chip_sword)
        btnChipSatellite = findViewById(R.id.btn_chip_satellite)
        btnChipHelmet = findViewById(R.id.btn_chip_helmet)
        btnChipSpaceship = findViewById(R.id.btn_chip_spaceship)
        btnChipDrone = findViewById(R.id.btn_chip_drone)
        btnChipChair = findViewById(R.id.btn_chip_chair)
        btnChipGear = findViewById(R.id.btn_chip_gear)
        btnChipPhoneStand = findViewById(R.id.btn_chip_phonestand)
        btnChipWrench = findViewById(R.id.btn_chip_wrench)
        btnChipVase = findViewById(R.id.btn_chip_vase)
        btnChipHeatsink = findViewById(R.id.btn_chip_heatsink)
        btn3dCycleShader = findViewById(R.id.btn_3d_cycle_shader)
        btn3dAnalyzeSlicer = findViewById(R.id.btn_3d_analyze_slicer)
        btn3dToggleGrid = findViewById(R.id.btn_3d_toggle_grid)
        btn3dExportBinaryStl = findViewById(R.id.btn_3d_export_binary_stl)
        btn3dExportStl = findViewById(R.id.btn_3d_export_stl)
        btn3dExportObj = findViewById(R.id.btn_3d_export_obj)

        // Planner & Scheduler Views
        etPlannerGoal = findViewById(R.id.et_planner_goal)
        btnPlanReason = findViewById(R.id.btn_plan_reason)
        btnPlanExecuteNow = findViewById(R.id.btn_plan_execute_now)
        btnPlanSchedule = findViewById(R.id.btn_plan_schedule)
        tvPlanStepsPreview = findViewById(R.id.tv_plan_steps_preview)

        cardActionSolana = findViewById(R.id.card_action_solana)
        cardActionGold = findViewById(R.id.card_action_gold)
        cardActionCapcut = findViewById(R.id.card_action_capcut)
        cardActionWeb = findViewById(R.id.card_action_web)
        cardActionRugcheck = findViewById(R.id.card_action_rugcheck)
        cardActionSwap = findViewById(R.id.card_action_swap)
        cardActionVision = findViewById(R.id.card_action_vision)
        cardActionGesture = findViewById(R.id.card_action_gesture)
        cardActionRewind = findViewById(R.id.card_action_rewind)
        cardActionGamebot = findViewById(R.id.card_action_gamebot)
        cardActionInstitutional = findViewById(R.id.card_action_institutional)
        cardActionBtcMacro = findViewById(R.id.card_action_btc_macro)
        cardActionWebStudio = findViewById(R.id.card_action_web_studio)
        cardActionWebServer = findViewById(R.id.card_action_web_server)
        cardActionGameDev = findViewById(R.id.card_action_game_dev)
        cardActionGamePlay = findViewById(R.id.card_action_game_play)
        tvTerminalOutput = findViewById(R.id.tv_terminal_output)
    }

    private fun checkModelStatus() {
        if (ModelManager.isModelReady(this)) {
            tvModelStatus.text = "Trạng thái: Đã có sẵn mô hình Qwen 1.5B (GGUF Q4)!"
            tvModelStatus.setTextColor(android.graphics.Color.parseColor("#14F195"))
            btnDownloadModel.isEnabled = false
            btnDownloadModel.text = "LÕI QWEN 1.5B ĐÃ SẴN SÀNG"
            tvGaugeRam.text = "1.15 GB"
        } else {
            tvModelStatus.text = "Trạng thái: Chưa tải mô hình (~980MB)"
            tvModelStatus.setTextColor(android.graphics.Color.parseColor("#FFD700"))
            tvGaugeRam.text = "0.05 GB"
        }
    }

    private fun setupListeners() {
        // 0. Tải mô hình Qwen 1.5B trực tiếp trên máy
        btnDownloadModel.setOnClickListener {
            btnDownloadModel.isEnabled = false
            pbDownloadModel.visibility = View.VISIBLE
            tvModelStatus.text = "Đang tải mô hình từ Hugging Face... 0%"

            lifecycleScope.launch {
                val success = ModelManager.downloadModel(this@MainActivity) { progress ->
                    runOnUiThread {
                        pbDownloadModel.progress = progress
                        tvModelStatus.text = "Đang tải: $progress%"
                    }
                }
                pbDownloadModel.visibility = View.GONE
                if (success) {
                    checkModelStatus()
                    Toast.makeText(this@MainActivity, "Tải mô hình thành công!", Toast.LENGTH_SHORT).show()
                } else {
                    btnDownloadModel.isEnabled = true
                    tvModelStatus.text = "Tải thất bại. Vui lòng kiểm tra kết nối mạng."
                    Toast.makeText(this@MainActivity, "Lỗi tải mô hình", Toast.LENGTH_SHORT).show()
                }
            }
        }

        // 1. Cập nhật tên gọi động (G2P Dynamic Wake Word)
        btnSaveName.setOnClickListener {
            val customName = etAiName.text.toString().trim()
            if (customName.isNotEmpty()) {
                val intent = Intent(this, WakeWordService::class.java).apply {
                    putExtra("CUSTOM_NAME", customName)
                }
                startService(intent)
                wifiSwarmManager?.registerService(customName)
                Toast.makeText(this, "Đã cập nhật tên gọi thành: $customName", Toast.LENGTH_SHORT).show()
            }
        }

        // 2. Bật/Tắt Micro-Robot nổi 35dp x 40dp
        btnToggleOverlay.setOnClickListener {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                val intent = Intent(
                    Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:$packageName")
                )
                startActivity(intent)
                Toast.makeText(this, "Vui lòng cấp quyền Vẽ đè màn hình cho Nít", Toast.LENGTH_LONG).show()
            } else {
                val intent = Intent(this, MicroRobotOverlayService::class.java)
                if (isOverlayRunning) {
                    stopService(intent)
                    isOverlayRunning = false
                    btnToggleOverlay.text = "BẬT 3D"
                } else {
                    startService(intent)
                    isOverlayRunning = true
                    btnToggleOverlay.text = "TẮT 3D"
                }
            }
        }

        // 3. Mở cài đặt quyền Trợ năng (Accessibility)
        btnOpenAccessibility.setOnClickListener {
            val intent = Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            startActivity(intent)
            Toast.makeText(this, "Hãy tìm và Bật dịch vụ 'Hyper-Nexus (Nít)'", Toast.LENGTH_LONG).show()
        }
    }

    private fun setupActionCards() {
        // 1. SOLANA DEX QUANT PRO
        cardActionSolana.setOnClickListener {
            Toast.makeText(this, "Nít: Đang quét thanh khoản Solana DEX...", Toast.LENGTH_SHORT).show()
            tvTerminalOutput.text = "🪐 [SOLANA DEX]: Đang lấy dữ liệu nến thật từ DexScreener & Binance..."
            lifecycleScope.launch {
                val result = SolanaDexDataManager.analyzeSolanaDexToken("SOL")
                tvTerminalOutput.text = result
                voiceEngine?.speak("Đã phân tích xong Solana DEX. Kế hoạch giao dịch định lượng đã hiển thị trên màn hình.")
            }
        }

        // 2. PHÂN TÍCH VÀNG THẾ GIỚI
        cardActionGold.setOnClickListener {
            Toast.makeText(this, "Nít: Đang phân tích kỹ thuật Vàng XAU...", Toast.LENGTH_SHORT).show()
            tvTerminalOutput.text = "👑 [VÀNG THẾ GIỚI]: Đang đo dải Bollinger Bands & ATR nến thật..."
            lifecycleScope.launch {
                val result = SolanaDexDataManager.analyzeWorldGold()
                tvTerminalOutput.text = result
                voiceEngine?.speak("Đã phân tích kỹ thuật thị trường Vàng thế giới.")
            }
        }

        // 3. CAPCUT THEME & AUDIO PRO STUDIO (ĐỘC BẢN THEO MÔ TẢ TỰ DO)
        cardActionCapcut.setOnClickListener {
            showCapCutCustomDialog()
        }

        // 4. TÌM KIẾM INTERNET THỜI GIAN THỰC
        cardActionWeb.setOnClickListener {
            Toast.makeText(this, "Nít: Đang tìm kiếm tin tức trên Internet...", Toast.LENGTH_SHORT).show()
            tvTerminalOutput.text = "🌐 [INTERNET RAG]: Đang truy vấn DuckDuckGo & Wikipedia..."
            lifecycleScope.launch {
                val results = WebSearchEngine.searchWeb("tin tức công nghệ AI nổi bật hôm nay")
                val sb = StringBuilder("🌐 [INTERNET REAL-TIME RAG]:\n\n")
                results.forEachIndexed { idx, r ->
                    sb.append("[${idx + 1}] ${r.title}\n${r.snippet}\nLink: ${r.url}\n\n")
                }
                tvTerminalOutput.text = sb.toString().trim()
                val text = if (results.isNotEmpty()) results[0].snippet else "Đã hoàn thành tìm kiếm Internet."
                voiceEngine?.speak(text)
            }
        }

        // 5. KIỂM TOÁN AN TOÀN RUGCHECK SOLANA
        cardActionRugcheck.setOnClickListener {
            Toast.makeText(this, "Nít: Đang quét hợp đồng On-Chain...", Toast.LENGTH_SHORT).show()
            tvTerminalOutput.text = "🛡️ [RUGCHECK AUDIT]: Đang quét Mint Authority & Freeze Authority..."
            lifecycleScope.launch {
                val audit = com.hypernexus.nit.finance.SolanaSafetyAuditor.auditTokenSecurity(SolanaDexDataManager.SOL_MINT)
                val auditReport = """
                    🛡️ [KẾT QUẢ KIỂM TOÁN ON-CHAIN RUGCHECK]:
                    • Token: Solana Native (SOL) | Điểm an toàn: ${audit.safetyScore}/100
                    • Phân loại: ${audit.riskLevel}
                    • Mint Authority: ${if (audit.mintAuthorityRevoked) "✅ Đã từ bỏ quyền in token" else "🚨 Chưa từ bỏ"}
                    • Freeze Authority: ${if (audit.freezeAuthorityRevoked) "✅ Đã hủy đóng băng" else "🚨 Còn bật"}
                    • Khóa thanh khoản: ${if (audit.lpBurnedOrLocked) "✅ Thanh khoản an toàn" else "⚠️ Rủi ro"}
                    • Tóm tắt: ${audit.summaryNote}
                """.trimIndent()
                tvTerminalOutput.text = auditReport
                voiceEngine?.speak("Kiểm toán token đạt ${audit.safetyScore} điểm, phân loại ${audit.riskLevel}.")
            }
        }

        // 6. HOÁN ĐỔI SWAP JUPITER V6 (XÁC THỰC VÂN TAY SAMSUNG KNOX)
        cardActionSwap.setOnClickListener {
            Toast.makeText(this, "Nít: Đang lấy báo giá Jupiter v6...", Toast.LENGTH_SHORT).show()
            tvTerminalOutput.text = "⚡ [JUPITER SWAP]: Đang định tuyến qua Raydium/Orca..."
            lifecycleScope.launch {
                val quote = com.hypernexus.nit.finance.SolanaAutoTrader.getBestSwapQuote(0.1, "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v")
                if (quote != null) {
                    val (walletPubkey, _) = com.hypernexus.nit.security.SolanaKeypairManager.getOrCreateWallet(this@MainActivity)
                    tvTerminalOutput.text = """
                        ⚡ [BÁO GIÁ JUPITER V6 ON-CHAIN]:
                        • Đổi: 0.1 SOL -> USDC
                        • Nhận ước tính: ${"%,.2f".format(quote.outAmount)} USDC
                        • Sàn thực thi: ${quote.routePlan} | Trượt giá: ${"%.2f".format(quote.priceImpactPct)}%
                        • Ví: ${walletPubkey.take(8)}...
                        👉 Đang kích hoạt xác thực vân tay Samsung Knox...
                    """.trimIndent()

                    com.hypernexus.nit.security.BiometricSecurityManager.promptBiometricForTrade(
                        this@MainActivity,
                        "Hoán đổi 0.1 SOL sang USDC qua sàn ${quote.routePlan}",
                        onSuccess = {
                            lifecycleScope.launch {
                                val txResult = com.hypernexus.nit.finance.SolanaAutoTrader.executeAutoSwap(quote, walletPubkey)
                                tvTerminalOutput.text = txResult
                                voiceEngine?.speak("Xác thực vân tay thành công! Giao dịch swap Solana đã được tạo.")
                            }
                        },
                        onError = { err ->
                            tvTerminalOutput.text = "❌ Giao dịch bị hủy bỏ: $err"
                            voiceEngine?.speak("Giao dịch bị hủy bỏ.")
                        }
                    )
                } else {
                    tvTerminalOutput.text = "Không thể kết nối máy chủ Jupiter Swap API."
                }
            }
        }

        // 7. THỊ GIÁC MÀN HÌNH AI COPILOT
        cardActionVision.setOnClickListener {
            val sampleOcr = "Giao dịch thành công Vietcombank STK 1023456789 số tiền 2.500.000 VND"
            val parsed = com.hypernexus.nit.vision.ScreenVisionCoPilot.parseBankTransferFromText(sampleOcr)
            tvTerminalOutput.text = """
                👁️ [SCREEN VISION COPILOT]:
                • Nhận diện hóa đơn OCR: ${parsed?.bankName} - STK: ${parsed?.accountNumber} - Số tiền: ${"%,.0f".format(parsed?.amount)} VND
                • Quét pixel biểu đồ TradingView: Sẵn sàng phân tích tỷ lệ nến Bullish/Bearish theo thời gian thực.
            """.trimIndent()
            voiceEngine?.speak("Screen Vision đã nhận diện hóa đơn chuyển khoản ngân hàng ${parsed?.bankName}.")
        }

        // 8. CỬ CHỈ KHÔNG CHẠM CAMERA TRƯỚC
        cardActionGesture.setOnClickListener {
            if (!isGestureActive) {
                gestureDriver = com.hypernexus.nit.gesture.FrontCameraGestureDriver(this).apply {
                    start { gesture ->
                        runOnUiThread {
                            tvTerminalOutput.text = "🖐️ [AIR GESTURES]: Phát hiện cử chỉ $gesture (Tự động cuộn màn hình)"
                            when (gesture) {
                                com.hypernexus.nit.gesture.AirGestureEngine.RecognizedGesture.SWIPE_UP -> {
                                    NitAccessibilityService.instance?.performSwipe(540f, 1600f, 540f, 600f, 250)
                                }
                                com.hypernexus.nit.gesture.AirGestureEngine.RecognizedGesture.SWIPE_DOWN -> {
                                    NitAccessibilityService.instance?.performSwipe(540f, 600f, 540f, 1600f, 250)
                                }
                                else -> {}
                            }
                        }
                    }
                }
                isGestureActive = true
                tvTerminalOutput.text = "🖐️ [AIR GESTURES]: ĐÃ BẬT CAMERA TRƯỚC. Hãy vẫy tay trước màn hình để lướt video không cần chạm!"
                voiceEngine?.speak("Đã bật cử chỉ không chạm qua camera trước.")
            } else {
                gestureDriver?.stop()
                gestureDriver = null
                isGestureActive = false
                tvTerminalOutput.text = "🖐️ [AIR GESTURES]: ĐÃ TẮT CỬ CHỈ KHÔNG CHẠM."
                voiceEngine?.speak("Đã tắt cử chỉ không chạm.")
            }
        }

        // 9. KÝ ỨC MÀN HÌNH NGƯỢC DÒNG THỜI GIAN (SCREEN REWIND FTS4)
        cardActionRewind.setOnClickListener {
            Toast.makeText(this, "Nít: Đang truy xuất ký ức màn hình FTS4...", Toast.LENGTH_SHORT).show()
            tvTerminalOutput.text = "⏳ [SCREEN REWIND]: Đang tra cứu cơ sở dữ liệu SQLite FTS4 cục bộ..."
            val tm = NitAccessibilityService.instance?.getTimelineManager()
                ?: com.hypernexus.nit.evolution.ScreenTimelineMemoryManager(this)
            val memories = tm.searchTimelineMemory("", limit = 3)
            if (memories.isNotEmpty()) {
                val sb = StringBuilder("⏳ [KÝ ỨC MÀN HÌNH - NGƯỢC DÒNG THỜI GIAN FTS4]:\n\n")
                memories.forEachIndexed { idx, m ->
                    sb.append("[${idx + 1}] Lúc ${m.formattedTime} trên ${m.appLabel} (${m.packageName}):\n")
                    sb.append("• Trích đoạn: \"${m.textSnippet}\"\n\n")
                }
                tvTerminalOutput.text = sb.toString().trim()
                voiceEngine?.speak("Đã tìm thấy ${memories.size} mốc ký ức màn hình gần nhất.")
            } else {
                tvTerminalOutput.text = "⏳ [SCREEN REWIND]: Chưa có bản ghi ký ức màn hình nào. Khi bạn lướt web, đọc báo hoặc dùng Zalo, Nít sẽ tự động ghi nhớ an toàn vào SQLite FTS4!"
                voiceEngine?.speak("Chưa có ký ức màn hình nào được ghi nhận.")
            }
        }

        // 10. GAME BOT TACTICAL ASSISTANT
        cardActionGamebot.setOnClickListener {
            Toast.makeText(this, "Nít: Đang kích hoạt Game Tactical Bot...", Toast.LENGTH_SHORT).show()
            tvTerminalOutput.text = "⚔️ [GAME TACTICS]: Đang kích hoạt chuỗi combo chiêu 1, chiêu 2, đánh thường và né đòn ngẫu nhiên chống phát hiện..."
            val service = NitAccessibilityService.instance
            if (service != null) {
                com.hypernexus.nit.accessibility.GameBotManager.startAutoCombatCombo()
                voiceEngine?.speak("Đã kích hoạt hỗ trợ chiến đấu game tự động.")
            } else {
                tvTerminalOutput.text = "⚠️ Vui lòng cấp quyền Trợ năng (Accessibility) để Nít có thể chạm màn hình hỗ trợ combo trong game."
                voiceEngine?.speak("Vui lòng cấp quyền trợ năng.")
            }
        }

        // 11. BÁO CÁO TỔ CHỨC SMC & QUANT RISK (SOL / CRYPTO)
        cardActionInstitutional.setOnClickListener {
            Toast.makeText(this, "Nít: Đang phân tích thị trường chuẩn quỹ đầu tư...", Toast.LENGTH_SHORT).show()
            tvTerminalOutput.text = "🏛️ [INSTITUTIONAL SMC & QUANT RISK]: Đang bóc tách đa khung thời gian MTF, Order Block, FVG và rủi ro VaR 95%..."
            lifecycleScope.launch {
                val dossier = com.hypernexus.nit.finance.InstitutionalMarketAnalyzer.analyzeInstitutionalMarket("SOL")
                tvTerminalOutput.text = dossier.formatExecutiveMemo()
                voiceEngine?.speak(dossier.formatVoiceBriefing())
            }
        }

        // 12. BITCOIN INSTITUTIONAL EXECUTIVE MEMORANDUM
        cardActionBtcMacro.setOnClickListener {
            Toast.makeText(this, "Nít: Đang tạo Executive Memo cho Bitcoin...", Toast.LENGTH_SHORT).show()
            tvTerminalOutput.text = "₿ [BITCOIN QUANT MEMO]: Đang tính toán dòng tiền Smart Money, ma trận 3 kịch bản và tỷ trọng vốn Kelly..."
            lifecycleScope.launch {
                val dossier = com.hypernexus.nit.finance.InstitutionalMarketAnalyzer.analyzeInstitutionalMarket("BTC")
                tvTerminalOutput.text = dossier.formatExecutiveMemo()
                voiceEngine?.speak(dossier.formatVoiceBriefing())
            }
        }

        // 13. XƯỞNG LẬP TRÌNH WEB PRO (HTML5/CSS3/JS SANDBOX 120 FPS)
        cardActionWebStudio.setOnClickListener {
            Toast.makeText(this, "Nít: Đang kiến tạo dự án Web & mở Live Preview 120Hz...", Toast.LENGTH_SHORT).show()
            tvTerminalOutput.text = "🌐 [AUTONOMOUS WEB STUDIO]: Đang sinh mã nguồn HTML5/CSS3/JS, kiểm định W3C và khởi chạy máy chủ cục bộ..."
            lifecycleScope.launch {
                val template = com.hypernexus.nit.web.WebDevelopmentEngine.WebProjectTemplate.LANDING_PAGE_SAAS
                val project = com.hypernexus.nit.web.WebDevelopmentEngine.generateProject(template)
                val validation = com.hypernexus.nit.web.WebDevelopmentEngine.validateWebCode(project)
                com.hypernexus.nit.web.WebDevelopmentEngine.exportProjectToDisk(this@MainActivity, project, createZip = true)
                com.hypernexus.nit.web.LocalWebSandboxServer.startServer(project)
                val serverUrl = com.hypernexus.nit.web.LocalWebSandboxServer.getServerUrl()

                val report = """
                    🌐 [XƯỞNG LẬP TRÌNH WEB THẾ HỆ MỚI - HYPER NEXUS]:
                    • Dự án: ${project.title} (${project.template.code})
                    • Phân loại: ${project.template.category}
                    • Tệp mã nguồn: ${project.files.keys.joinToString(", ")}
                    • Thống kê: ${validation.totalLines} dòng mã | ${validation.totalBytes} bytes
                    • Điểm chuẩn W3C/Responsive: ${validation.qualityScore}/100
                    • Cổng Sandbox cục bộ: $serverUrl (120 FPS GPU Mali-G78)
                    👉 Đang mở khung nhìn Live Preview tương tác trực tiếp...
                """.trimIndent()
                tvTerminalOutput.text = report
                voiceEngine?.speak("Đã lập trình xong trang web ${project.title}. Đang mở khung nhìn Live Preview 120 FPS.")

                // Mở Dialog xem trước Web tương tác
                com.hypernexus.nit.web.WebPreviewDialog(this@MainActivity, project, serverUrl).show()
            }
        }

        // 14. MÁY CHỦ WEB LIVE & XUẤT ZIP
        cardActionWebServer.setOnClickListener {
            Toast.makeText(this, "Nít: Đang xuất bản và đóng gói mã nguồn Web...", Toast.LENGTH_SHORT).show()
            tvTerminalOutput.text = "🚀 [WEB PACKAGER & SERVER]: Đang đóng gói toàn bộ HTML/CSS/JS thành file ZIP..."
            lifecycleScope.launch {
                val template = com.hypernexus.nit.web.WebDevelopmentEngine.WebProjectTemplate.ANALYTICS_DASHBOARD
                val project = com.hypernexus.nit.web.WebDevelopmentEngine.generateProject(template)
                val exportRes = com.hypernexus.nit.web.WebDevelopmentEngine.exportProjectToDisk(this@MainActivity, project, createZip = true)
                com.hypernexus.nit.web.LocalWebSandboxServer.startServer(project)
                val serverUrl = com.hypernexus.nit.web.LocalWebSandboxServer.getServerUrl()

                val report = """
                    🚀 [KẾT QUẢ ĐÓNG GÓI & MÁY CHỦ WEB LIVE]:
                    • Trạng thái xuất bản: ${if (exportRes.success) "✅ THÀNH CÔNG" else "❌ THẤT BẠI"}
                    • Thư mục mã nguồn: ${exportRes.projectDir}
                    • Tệp nén ZIP xuất bản: ${exportRes.zipFilePath ?: "Không có"}
                    • Tổng dung lượng: ${exportRes.totalBytes} bytes (${exportRes.totalFiles} tệp)
                    • Máy chủ nội bộ: $serverUrl
                    👉 Sẵn sàng tải lên Vercel, Netlify hoặc GitHub Pages!
                """.trimIndent()
                tvTerminalOutput.text = report
                voiceEngine?.speak("Đã đóng gói dự án web thành công ra file nén ZIP và đang phục vụ tại máy chủ cục bộ.")
            }
        }

        // 15. XƯỞNG LẬP TRÌNH GAME WEB 120 FPS & ĐỘC BẢN THEO MÔ TẢ
        cardActionGameDev.setOnClickListener {
            showGameCreationDialog()
        }

        // 16. PHÒNG GAME 120HZ MÊ CUNG 3D
        cardActionGamePlay.setOnClickListener {
            Toast.makeText(this, "Nít: Đang khởi chạy game Mê Cung 3D Raycasting...", Toast.LENGTH_SHORT).show()
            tvTerminalOutput.text = "🕹️ [PHÒNG GAME 3D 120HZ]: Đang nạp thuật toán đồ họa DDA Raycasting 3D, radar mini-map và mở Sandbox..."
            lifecycleScope.launch {
                val genre = com.hypernexus.nit.web.WebGameDevelopmentEngine.WebGameGenre.WEBGL_3D_RAYCAST_MAZE
                val project = com.hypernexus.nit.web.WebGameDevelopmentEngine.generateGameProject(genre)
                com.hypernexus.nit.web.WebDevelopmentEngine.exportProjectToDisk(this@MainActivity, project, createZip = true)
                com.hypernexus.nit.web.LocalWebSandboxServer.startServer(project)
                val serverUrl = com.hypernexus.nit.web.LocalWebSandboxServer.getServerUrl()

                val report = """
                    🕹️ [PHÒNG GAME 3D RAYCASTING - HYPER NEXUS]:
                    • Trò chơi: ${genre.displayName}
                    • Thuật toán hiển thị: Wolfenstein-style DDA Raycaster 120 FPS trên Canvas
                    • Radar: Mini-map thời gian thực quét tọa độ người chơi
                    • Cổng Sandbox: $serverUrl
                    👉 Đang mở giao diện game 3D trực tiếp...
                """.trimIndent()
                tvTerminalOutput.text = report
                voiceEngine?.speak("Đang mở phòng game mê cung ba đê 120 FPS.")

                com.hypernexus.nit.web.WebPreviewDialog(this@MainActivity, project, serverUrl).show()
            }
        }
    }

    private fun showGameCreationDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "Ví dụ: Game cá lớn nuốt cá bé đại dương neon, Game đua xe tránh xe tải nhặt bình xăng nitro màu đỏ, Game né thiên thạch có khiên..."
            setHintTextColor(android.graphics.Color.parseColor("#64748B"))
            setTextColor(android.graphics.Color.parseColor("#00E5FF"))
            setBackgroundColor(android.graphics.Color.parseColor("#0E1320"))
            setPadding(32, 28, 32, 28)
            textSize = 14f
        }

        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(48, 24, 48, 24)
            addView(input)
        }

        android.app.AlertDialog.Builder(this)
            .setTitle("🎮 LẬP TRÌNH GAME WEB ĐỘC BẢN THEO MÔ TẢ")
            .setMessage("Nít sẽ tự động bóc tách cơ chế, luật chơi, đồ họa thủ tục và lập trình mã nguồn 120 FPS Delta-Time + Web Audio Synth chạy cục bộ trên S21 FE:")
            .setView(container)
            .setPositiveButton("LẬP TRÌNH NGAY") { _, _ ->
                val prompt = input.text.toString().trim()
                val finalPrompt = if (prompt.isNotEmpty()) prompt else "Game cá lớn nuốt cá bé đại dương neon"
                executeGameSynthesis(finalPrompt)
            }
            .setNegativeButton("GAME MẪU MẶC ĐỊNH") { _, _ ->
                executeGameSynthesis("lập trình game bắn phi thuyền không gian arcade 120 fps")
            }
            .setNeutralButton("HỦY", null)
            .show()
    }

    private fun executeGameSynthesis(prompt: String) {
        Toast.makeText(this, "Nít: Đang phân tích mô tả và sinh mã nguồn game...", Toast.LENGTH_SHORT).show()
        tvTerminalOutput.text = "🎮 [DYNAMIC GAME ENGINE]: Đang phân tích ngữ nghĩa: \"$prompt\"..."
        lifecycleScope.launch {
            val isCustom = com.hypernexus.nit.web.DynamicGameSynthesisEngine.isCustomGamePrompt(prompt)
            val project = if (isCustom) {
                com.hypernexus.nit.web.DynamicGameSynthesisEngine.synthesizeGameFromPrompt(this@MainActivity, prompt)
            } else {
                val genre = com.hypernexus.nit.web.WebGameDevelopmentEngine.matchGameGenreFromCommand(prompt)
                com.hypernexus.nit.web.WebGameDevelopmentEngine.generateGameProject(genre)
            }

            val validation = com.hypernexus.nit.web.WebGameDevelopmentEngine.validateGameCode(project)
            com.hypernexus.nit.web.WebDevelopmentEngine.exportProjectToDisk(this@MainActivity, project, createZip = true)
            com.hypernexus.nit.web.LocalWebSandboxServer.startServer(project)
            val serverUrl = com.hypernexus.nit.web.LocalWebSandboxServer.getServerUrl()

            val report = """
                🎮 [XƯỞNG LẬP TRÌNH GAME WEB ${if (isCustom) "ĐỘC BẢN" else "PRO"} - HYPER NEXUS]:
                • Tên trò chơi: ${project.title}
                • Yêu cầu gốc: "$prompt"
                • Vòng lặp: 120 FPS Delta-Time Game Loop (Mali-G78 120Hz)
                • Âm thanh: Web Audio API Oscillator Synth (Không cần tải file ngoài)
                • Điều khiển: Virtual Touch Joypad & Keyboard
                • Thống kê: ${validation.totalLines} dòng mã | Điểm chất lượng: ${validation.qualityScore}/100
                • Cổng Server Game: $serverUrl
                👉 Đang mở phòng chơi game trực tiếp...
            """.trimIndent()
            tvTerminalOutput.text = report
            voiceEngine?.speak("Đã lập trình xong game ${project.title}. Đang mở phòng chơi game 120 FPS.")

            com.hypernexus.nit.web.WebPreviewDialog(this@MainActivity, project, serverUrl).show()
        }
    }

    // =========================================================================
    // BIÊN TẬP VIDEO CAPCUT ĐỘC BẢN THEO MÔ TẢ TỰ DO
    // =========================================================================
    private fun showCapCutCustomDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "Ví dụ: Review quán ăn ấm cúng, nhạc acoustic dịu êm, màu vintage vàng, cắt mỗi 3s, zoom chậm, phụ đề chữ vàng viền đen..."
            setHintTextColor(android.graphics.Color.parseColor("#64748B"))
            setTextColor(android.graphics.Color.parseColor("#00E5FF"))
            setBackgroundColor(android.graphics.Color.parseColor("#0E1320"))
            setPadding(32, 28, 32, 28)
            textSize = 14f
        }

        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(48, 24, 48, 24)
            addView(input)
        }

        android.app.AlertDialog.Builder(this)
            .setTitle("🎬 BIÊN TẬP VIDEO CAPCUT ĐỘC BẢN THEO MÔ TẢ")
            .setMessage("Nít sẽ tự động bóc tách tỷ lệ khung, màu LUT, hiệu ứng thị giác, BGM, SFX foley, ducking âm lượng và điều khiển CapCut:")
            .setView(container)
            .setPositiveButton("BIÊN TẬP NGAY") { _, _ ->
                val prompt = input.text.toString().trim()
                val finalPrompt = if (prompt.isNotEmpty()) prompt else "Vlog ẩm thực ấm cúng nhạc acoustic màu vintage"
                executeCapCutCustomProduction(finalPrompt)
            }
            .setNegativeButton("THEME CYBERPUNK MẪU") { _, _ ->
                executeCapCutCustomProduction("Cyberpunk Futuristic")
            }
            .setNeutralButton("HỦY", null)
            .show()
    }

    private fun executeCapCutCustomProduction(prompt: String) {
        Toast.makeText(this, "Nít: Đang khởi chạy chuỗi sản xuất CapCut độc bản...", Toast.LENGTH_SHORT).show()
        tvTerminalOutput.text = "🎬 [CAPCUT DYNAMIC STUDIO]: Đang phân tích yêu cầu: \"$prompt\"..."
        lifecycleScope.launch {
            val isCustom = com.hypernexus.nit.video.DynamicCapCutSynthesisEngine.isCustomCapCutPrompt(prompt)
            val report = if (isCustom) {
                com.hypernexus.nit.video.DynamicCapCutSynthesisEngine.executeFromPrompt(
                    this@MainActivity,
                    prompt
                ) { stepNum, stage, msg ->
                    runOnUiThread {
                        tvTerminalOutput.text = "🎬 [CAPCUT STUDIO] Bước $stepNum - [$stage]: $msg"
                    }
                }
            } else {
                val theme = com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.VideoTheme.CYBERPUNK_FUTURISTIC
                val config = com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.buildDefaultConfigForTheme(theme)
                com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.executeThemeAndAudioProduction(
                    this@MainActivity,
                    config
                ) { stepNum, stage, msg ->
                    runOnUiThread {
                        tvTerminalOutput.text = "🎬 [CAPCUT STUDIO] Bước $stepNum - [$stage]: $msg"
                    }
                }
            }
            tvTerminalOutput.text = report
            voiceEngine?.speak("Đã hoàn tất sản xuất video trên CapCut!")
        }
    }

    // =========================================================================
    // DỰNG MÔ HÌNH 3D THAM SỐ ĐỘC BẢN THEO MÔ TẢ TỰ DO
    // =========================================================================
    private fun show3DCustomDialog() {
        val input = android.widget.EditText(this).apply {
            hint = "Ví dụ: Cốc uống nước lòng rỗng thành dày, Bánh răng 18 răng có lỗ trục lục giác, Hộp tai nghe bluetooth vát cạnh, Bình hoa xoắn ốc 6 cạnh..."
            setHintTextColor(android.graphics.Color.parseColor("#64748B"))
            setTextColor(android.graphics.Color.parseColor("#00E5FF"))
            setBackgroundColor(android.graphics.Color.parseColor("#0E1320"))
            setPadding(32, 28, 32, 28)
            textSize = 14f
        }

        val container = android.widget.LinearLayout(this).apply {
            orientation = android.widget.LinearLayout.VERTICAL
            setPadding(48, 24, 48, 24)
            addView(input)
        }

        android.app.AlertDialog.Builder(this)
            .setTitle("📐 DỰNG MÔ HÌNH 3D ĐỘC BẢN THEO MÔ TẢ")
            .setMessage("Nít sẽ tự động phân tích hình học, tạo lưới tam giác tham số chuẩn 2-Manifold kín nước và kết xuất 120 FPS trên GPU Mali-G78:")
            .setView(container)
            .setPositiveButton("DỰNG HÌNH NGAY") { _, _ ->
                val prompt = input.text.toString().trim()
                val finalPrompt = if (prompt.isNotEmpty()) prompt else "Cốc uống nước lòng rỗng thành dày"
                loadCustomDynamic3DMesh(finalPrompt)
            }
            .setNeutralButton("HỦY", null)
            .show()
    }

    private fun loadCustomDynamic3DMesh(prompt: String) {
        currentMeshType = Procedural3DGenerator.MeshType.CUSTOM_DYNAMIC
        val mesh = com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.synthesize3DMeshFromPrompt(prompt)
        currentMeshData = mesh
        viewport3D.setModelMesh(mesh)
        tv3dMeshInfo.text = "Tam giác: ${mesh.triangleCount} | ${mesh.customTitle.take(16)}"
        tvTerminalOutput.text = "📐 [DỰNG 3D ĐỘC BẢN]: Đã dựng xong mô hình 3D \"${mesh.customTitle}\" (${mesh.triangleCount} tam giác, chuẩn 2-Manifold kín nước) trên GPU Mali-G78 120 FPS."
        voiceEngine?.speak("Đã dựng xong mô hình ba đê ${mesh.customTitle}.")
    }

    private fun setupWifiSwarm() {
        val currentName = etAiName.text.toString().ifEmpty { "Nít" }
        wifiSwarmManager = WifiSwarmManager(this).apply {
            registerService(currentName)
            startDiscovery { peerName, host, port ->
                runOnUiThread {
                    tvSwarmStatus.text = "📡 SWARM P2P: Phát hiện $peerName ($host:$port)"
                }
            }
        }
    }

    // =========================================================================
    // KHUNG NHÌN 3D TƯƠNG TÁC 120 FPS & XƯỞNG DỰNG HÌNH THAM SỐ (3D PRINTING)
    // =========================================================================
    private fun setup3DViewport() {
        // 1. Lắng nghe FPS đo đạc thực tế từ GLSurfaceView 120Hz
        viewport3D.renderer.onFpsUpdated = { fps ->
            runOnUiThread {
                tv3dFpsBadge.text = "● $fps FPS MALI"
            }
        }

        // 2. Nạp mô hình 3D mặc định (CYBER_ROBOT) & Hỗ trợ nhấn giữ để dựng 3D theo mô tả
        load3DMesh(Procedural3DGenerator.MeshType.CYBER_ROBOT)
        viewport3D.setOnLongClickListener {
            show3DCustomDialog()
            true
        }

        // 3. Lắng nghe chọn mô hình tham số (Model Chips)
        btnChipRobot.setOnClickListener { load3DMesh(Procedural3DGenerator.MeshType.CYBER_ROBOT) }
        btnChipSword.setOnClickListener { load3DMesh(Procedural3DGenerator.MeshType.MECHA_SWORD) }
        btnChipSatellite.setOnClickListener { load3DMesh(Procedural3DGenerator.MeshType.QUANTUM_SATELLITE) }
        btnChipHelmet.setOnClickListener { load3DMesh(Procedural3DGenerator.MeshType.CYBER_HELMET) }
        btnChipSpaceship.setOnClickListener { load3DMesh(Procedural3DGenerator.MeshType.SPACESHIP) }
        btnChipDrone.setOnClickListener { load3DMesh(Procedural3DGenerator.MeshType.NANO_DRONE) }
        btnChipChair.setOnClickListener { load3DMesh(Procedural3DGenerator.MeshType.FURNITURE_CHAIR) }
        btnChipGear.setOnClickListener { load3DMesh(Procedural3DGenerator.MeshType.SPUR_GEAR) }
        btnChipPhoneStand.setOnClickListener { load3DMesh(Procedural3DGenerator.MeshType.PHONE_STAND) }
        btnChipWrench.setOnClickListener { load3DMesh(Procedural3DGenerator.MeshType.MECHANICAL_WRENCH) }
        btnChipVase.setOnClickListener { load3DMesh(Procedural3DGenerator.MeshType.PARAMETRIC_VASE) }
        btnChipHeatsink.setOnClickListener { load3DMesh(Procedural3DGenerator.MeshType.HEATSINK) }

        // 4. Chuyển đổi qua lại giữa 4 chế độ Shader kỹ thuật (PBR, Lưới Neon, Normal Map, Cắt Lớp In)
        btn3dCycleShader.setOnClickListener {
            val mode = viewport3D.cycleRenderMode()
            btn3dCycleShader.text = "SHADER: ${mode.name.take(6)}"
            Toast.makeText(this, "Chế độ Shader: ${mode.displayName}", Toast.LENGTH_SHORT).show()
            tvTerminalOutput.text = "🎨 [CHẾ ĐỘ SHADER 3D]: Đang kích hoạt '${mode.displayName}' trên GPU Mali-G78 120 FPS."
        }

        // 5. Phân tích Kỹ thuật Máy In 3D (Slicer Analytics: Thể tích, Khối lượng nhựa, Thời gian in, Manifold)
        btn3dAnalyzeSlicer.setOnClickListener {
            val analysis = viewport3D.getSlicerAnalysis()
            if (analysis != null) {
                val report = """
                    📐 [PHÂN TÍCH KỸ THUẬT MÁY IN 3D CHUYÊN NGHIỆP]:
                    • Mô hình: ${currentMeshType.name} (${analysis.triangleCount} tam giác)
                    • Thể tích đùn nhựa: ${"%.2f".format(analysis.volumeCm3)} cm³
                    • Kích thước in: ${"%.1f".format(analysis.boundingBoxMm.widthMm)} x ${"%.1f".format(analysis.boundingBoxMm.heightMm)} x ${"%.1f".format(analysis.boundingBoxMm.depthMm)} mm
                    • Khối lượng nhựa cần dùng (Infill 20%):
                      - Nhựa PLA: ${"%.1f".format(analysis.weightGramsPla)} gram
                      - Nhựa PETG: ${"%.1f".format(analysis.weightGramsPetg)} gram
                      - Nhựa ABS: ${"%.1f".format(analysis.weightGramsAbs)} gram
                    • Thời gian in ước tính (0.2mm layer): ~${analysis.estimatedPrintTimeMinutes} phút (${analysis.estimatedPrintTimeMinutes / 60}h ${analysis.estimatedPrintTimeMinutes % 60}p)
                    • Độ kín nước (2-Manifold Watertight): ${if (analysis.isWatertight) "✅ KÍN NƯỚC (Sẵn sàng in)" else "⚠️ Cần tạo Support"}
                    👉 Tương thích phần mềm: Bambu Studio, UltiMaker Cura, PrusaSlicer, OrcaSlicer.
                """.trimIndent()
                tvTerminalOutput.text = report
                voiceEngine?.speak("Mô hình ${currentMeshType.name} có thể tích ${"%.1f".format(analysis.volumeCm3)} xăng ti mét khối, cần khoảng ${"%.0f".format(analysis.weightGramsPla)} gam nhựa P-L-A, thời gian in khoảng ${analysis.estimatedPrintTimeMinutes} phút.")
            }
        }

        // 6. Bật/Tắt Lưới Bàn In 3D (Print Bed Grid)
        btn3dToggleGrid.setOnClickListener {
            val show = viewport3D.toggleGridFloor()
            val cyanColor = android.graphics.Color.parseColor("#00E5FF")
            val grayColor = android.graphics.Color.parseColor("#94A3B8")
            btn3dToggleGrid.setTextColor(if (show) cyanColor else grayColor)
            Toast.makeText(this, if (show) "Đã bật bàn in 3D" else "Đã tắt bàn in 3D", Toast.LENGTH_SHORT).show()
        }

        // 7. Xuất file BINARY STL (.STL) chuẩn máy in 3D công nghiệp
        btn3dExportBinaryStl.setOnClickListener {
            lifecycleScope.launch {
                val mesh = currentMeshData ?: Procedural3DGenerator.buildMeshData(currentMeshType)
                val fileName = "nit_${currentMeshType.name.lowercase()}_binary.stl"
                val file = Procedural3DGenerator.exportToBinaryStlFile(this@MainActivity, mesh, fileName)
                val msg = """
                    🖨️ [XUẤT BINARY .STL CHUẨN CÔNG NGHIỆP]:
                    • Mô hình: ${currentMeshType.name} (${mesh.triangleCount} tam giác)
                    • Tệp: ${file.name} (${file.length()} bytes)
                    • Vị trí: ${file.absolutePath}
                    👉 Tối ưu hóa nhị phân IEEE 754 Little-Endian (nhỏ hơn 5x). Nạp trực tiếp vào thẻ nhớ hoặc qua Wi-Fi máy in 3D!
                """.trimIndent()
                tvTerminalOutput.text = msg
                Toast.makeText(this@MainActivity, "Đã xuất Binary STL: ${file.name}", Toast.LENGTH_SHORT).show()
                voiceEngine?.speak("Đã xuất file Binary S-T-L chuẩn máy in ba đê công nghiệp.")
            }
        }

        // 8. Xuất file ASCII .STL
        btn3dExportStl.setOnClickListener {
            lifecycleScope.launch {
                val mesh = currentMeshData ?: Procedural3DGenerator.buildMeshData(currentMeshType)
                val fileName = "nit_${currentMeshType.name.lowercase()}_ascii.stl"
                val file = Procedural3DGenerator.exportToStlFile(this@MainActivity, mesh, fileName)
                val msg = """
                    🖨️ [XUẤT ASCII .STL MÁY IN 3D]:
                    • Mô hình: ${currentMeshType.name} (${mesh.triangleCount} tam giác)
                    • Tệp: ${file.name} (${file.length()} bytes)
                    • Vị trí: ${file.absolutePath}
                """.trimIndent()
                tvTerminalOutput.text = msg
                Toast.makeText(this@MainActivity, "Đã xuất ASCII STL: ${file.name}", Toast.LENGTH_SHORT).show()
            }
        }

        // 9. Xuất file đa giác Wavefront (.OBJ) cho phần mềm đồ họa CAD / Blender
        btn3dExportObj.setOnClickListener {
            lifecycleScope.launch {
                val fileName = "nit_${currentMeshType.name.lowercase()}.obj"
                val file = Procedural3DGenerator.generate3DMesh(this@MainActivity, currentMeshType, fileName)
                val msg = """
                    📐 [XUẤT MÔ HÌNH 3D WAVEFRONT OBJ]:
                    • Mô hình: ${currentMeshType.name} (${mesh.triangleCount} tam giác)
                    • Tệp: ${file.name} (${file.length()} bytes)
                    • Vị trí: ${file.absolutePath}
                    👉 Sẵn sàng import vào Blender, Maya, AutoCAD hoặc Unity!
                """.trimIndent()
                tvTerminalOutput.text = msg
                Toast.makeText(this@MainActivity, "Đã xuất file 3D: ${file.name}", Toast.LENGTH_SHORT).show()
                voiceEngine?.speak("Đã xuất file 3D định dạng OBJ.")
            }
        }
    }

    private fun load3DMesh(type: Procedural3DGenerator.MeshType) {
        currentMeshType = type
        val mesh = Procedural3DGenerator.buildMeshData(type)
        currentMeshData = mesh
        viewport3D.setModelMesh(mesh)
        tv3dMeshInfo.text = "Tam giác: ${mesh.triangleCount}"
        updateChipStyles(type)
    }

    private fun updateChipStyles(selected: Procedural3DGenerator.MeshType) {
        val cyanColor = android.graphics.Color.parseColor("#00E5FF")
        val grayColor = android.graphics.Color.parseColor("#94A3B8")

        btnChipRobot.setTextColor(if (selected == Procedural3DGenerator.MeshType.CYBER_ROBOT) cyanColor else grayColor)
        btnChipSword.setTextColor(if (selected == Procedural3DGenerator.MeshType.MECHA_SWORD) cyanColor else grayColor)
        btnChipSatellite.setTextColor(if (selected == Procedural3DGenerator.MeshType.QUANTUM_SATELLITE) cyanColor else grayColor)
        btnChipHelmet.setTextColor(if (selected == Procedural3DGenerator.MeshType.CYBER_HELMET) cyanColor else grayColor)
        btnChipSpaceship.setTextColor(if (selected == Procedural3DGenerator.MeshType.SPACESHIP) cyanColor else grayColor)
        btnChipDrone.setTextColor(if (selected == Procedural3DGenerator.MeshType.NANO_DRONE) cyanColor else grayColor)
        btnChipChair.setTextColor(if (selected == Procedural3DGenerator.MeshType.FURNITURE_CHAIR) cyanColor else grayColor)
        btnChipGear.setTextColor(if (selected == Procedural3DGenerator.MeshType.SPUR_GEAR) cyanColor else grayColor)
        btnChipPhoneStand.setTextColor(if (selected == Procedural3DGenerator.MeshType.PHONE_STAND) cyanColor else grayColor)
        btnChipWrench.setTextColor(if (selected == Procedural3DGenerator.MeshType.MECHANICAL_WRENCH) cyanColor else grayColor)
        btnChipVase.setTextColor(if (selected == Procedural3DGenerator.MeshType.PARAMETRIC_VASE) cyanColor else grayColor)
        btnChipHeatsink.setTextColor(if (selected == Procedural3DGenerator.MeshType.HEATSINK) cyanColor else grayColor)
    }

    // =========================================================================
    // BUỒNG LÁI LẬP KẾ HOẠCH & LỊCH TRÌNH TỰ HÀNH (COGNITIVE TASK PLANNER)
    // =========================================================================
    private fun setupPlannerCockpit() {
        // 1. Nút Phân rã mục tiêu (Reason & Decompose into DAG Action Graph)
        btnPlanReason.setOnClickListener {
            val userGoal = etPlannerGoal.text.toString().trim()
            if (userGoal.isEmpty()) {
                Toast.makeText(this, "Vui lòng nhập mục tiêu cần lập kế hoạch", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val plan = com.hypernexus.nit.planner.CognitiveTaskReasoner.reasonAndCreatePlan(userGoal)
            currentGeneratedPlan = plan

            val timeFormat = java.text.SimpleDateFormat("HH:mm dd/MM", java.util.Locale.getDefault())
            val triggerInfo = when (plan.triggerType) {
                com.hypernexus.nit.planner.TriggerType.IMMEDIATE -> "Thực thi ngay lập tức"
                com.hypernexus.nit.planner.TriggerType.EXACT_TIME -> "Hẹn giờ Alarm: " + timeFormat.format(java.util.Date(plan.triggerTimeMs))
                com.hypernexus.nit.planner.TriggerType.PERIODIC -> "Định kỳ WorkManager: mỗi ${plan.repeatIntervalMs / 60000} phút"
                com.hypernexus.nit.planner.TriggerType.MARKET_CONDITION -> "Điều kiện thị trường: ${plan.triggerCondition}"
                com.hypernexus.nit.planner.TriggerType.DEVICE_CONDITION -> "Điều kiện thiết bị: ${plan.triggerCondition}"
            }

            val sb = StringBuilder("📋 [KẾ HOẠCH HÀNH ĐỘNG ĐÃ PHÂN RÃ]:\n")
            sb.append("• Tiêu đề: ${plan.title}\n")
            sb.append("• Kích hoạt: $triggerInfo\n\n")
            plan.steps.forEachIndexed { idx, s ->
                sb.append("${idx + 1}. [${s.actionType.name}] ${s.title}\n")
                if (s.condition != null) sb.append("   ⚠️ Điều kiện: ${s.condition}\n")
            }
            tvPlanStepsPreview.text = sb.toString().trim()
            tvTerminalOutput.text = "🧠 [PLAN REASONER]: Đã phân rã mục tiêu thành ${plan.steps.size} bước hành động tự hành."
            voiceEngine?.speak("Đã lập kế hoạch gồm ${plan.steps.size} bước hành động.")
        }

        // 2. Nút Thực thi ngay lập tức chuỗi hành động (Execute Plan Now)
        btnPlanExecuteNow.setOnClickListener {
            val goal = etPlannerGoal.text.toString().trim()
            val plan = currentGeneratedPlan ?: com.hypernexus.nit.planner.CognitiveTaskReasoner.reasonAndCreatePlan(
                if (goal.isNotEmpty()) goal else "quét giá sol và báo cáo"
            )
            currentGeneratedPlan = plan

            tvTerminalOutput.text = "🚀 [PLANNER]: Bắt đầu thực thi tự hành ${plan.steps.size} bước..."
            Toast.makeText(this, "Đang thực thi chuỗi hành động...", Toast.LENGTH_SHORT).show()

            lifecycleScope.launch {
                val report = com.hypernexus.nit.planner.AutonomousExecutionEngine.executePlan(
                    this@MainActivity,
                    plan
                ) { step ->
                    runOnUiThread {
                        tvTerminalOutput.text = "⚡ Đang chạy: ${step.title}..."
                    }
                }
                tvTerminalOutput.text = report
                voiceEngine?.speak("Đã thực thi xong kế hoạch ${plan.title}.")
            }
        }

        // 3. Nút Lên lịch bền vững (Schedule via AlarmManager & SQLite)
        btnPlanSchedule.setOnClickListener {
            val goal = etPlannerGoal.text.toString().trim()
            val plan = currentGeneratedPlan ?: com.hypernexus.nit.planner.CognitiveTaskReasoner.reasonAndCreatePlan(
                if (goal.isNotEmpty()) goal else "Sáng mai 7h quét giá SOL"
            )
            currentGeneratedPlan = plan

            com.hypernexus.nit.planner.TaskPlanningManager.schedulePlan(this, plan)

            val timeFormat = java.text.SimpleDateFormat("HH:mm dd/MM", java.util.Locale.getDefault())
            val schedMsg = """
                ⏰ [LÊN LỊCH TỰ HÀNH THÀNH CÔNG]:
                • Kế hoạch: ${plan.title}
                • Phân loại Trigger: ${plan.triggerType}
                • Thời điểm: ${if (plan.triggerTimeMs > 0) timeFormat.format(java.util.Date(plan.triggerTimeMs)) else "Theo điều kiện kích hoạt"}
                • Lưu trữ: Bền vững trong SQLite & AlarmManager Android.
                👉 Nít sẽ tự động đánh thức máy và thực thi tuần tự các bước ngay cả khi bạn khóa màn hình!
            """.trimIndent()
            tvTerminalOutput.text = schedMsg
            Toast.makeText(this, "Đã lên lịch kế hoạch thành công!", Toast.LENGTH_SHORT).show()
            voiceEngine?.speak("Đã lưu kế hoạch vào lịch hẹn tự hành.")
        }
    }

    private fun observeAgentExecutionState() {
        lifecycleScope.launch {
            com.hypernexus.nit.planner.AutonomousExecutionEngine.executionState.collect { state ->
                when (state) {
                    is com.hypernexus.nit.planner.AgentExecutionState.ExecutingStep -> {
                        tvTerminalOutput.text = "⚡ [TỰ HÀNH BƯỚC ${state.stepId}/${state.totalSteps}]: ${state.title}..."
                    }
                    is com.hypernexus.nit.planner.AgentExecutionState.Healing -> {
                        tvTerminalOutput.text = "🩹 [TỰ CHỮA LÀNH BƯỚC ${state.stepId}]: ${state.title}\n• Chiến lược: ${state.strategy}\n• Chi tiết: ${state.reason}"
                    }
                    is com.hypernexus.nit.planner.AgentExecutionState.Completed -> {
                        tvPlanStepsPreview.text = "✅ ĐÃ HOÀN TẤT KẾ HOẠCH: ${state.planTitle}\n\n${state.summary.take(200)}..."
                    }
                    is com.hypernexus.nit.planner.AgentExecutionState.Failed -> {
                        tvTerminalOutput.text = "❌ Kế hoạch \"${state.planTitle}\" gặp sự cố: ${state.error}"
                    }
                    else -> {}
                }
            }
        }
    }

    override fun onResume() {

        super.onResume()
        viewport3D.onResume()
    }

    override fun onPause() {
        super.onPause()
        viewport3D.onPause()
    }

    override fun onDestroy() {
        super.onDestroy()
        gestureDriver?.stop()
        gestureDriver = null
        wifiSwarmManager?.stop()
        voiceEngine?.destroy()
    }
}

