package com.hypernexus.nit.engine

object LlamaEngine {
    init {
        System.loadLibrary("hypernexus_native")
    }

    external fun getNativeVersion(): String
    external fun initModel(modelPath: String): Boolean
    external fun generateResponse(prompt: String, maxTokens: Int = 512, temperature: Float = 0.7f): String
    external fun unloadModel()

    // 1. CHỈ SỐ RSI
    external fun calculateRSI(prices: DoubleArray, period: Int): DoubleArray

    // 2. CHỈ SỐ MACD (Trả về: [MACD Line, Signal Line, Histogram])
    external fun calculateMACD(prices: DoubleArray, fastPeriod: Int = 12, slowPeriod: Int = 26, signalPeriod: Int = 9): DoubleArray

    // 3. DẢI BOLLINGER BANDS (Trả về: [Upper Band, Middle SMA, Lower Band, Bandwidth %])
    external fun calculateBollingerBands(prices: DoubleArray, period: Int = 20, stdDevMultiplier: Double = 2.0): DoubleArray

    // 4. CHỈ SỐ EMA (Exponential Moving Average)
    external fun calculateEMA(prices: DoubleArray, period: Int): DoubleArray

    // 5. CHỈ SỐ STOCHASTIC OSCILLATOR (Trả về: [%K, %D])
    external fun calculateStochastic(highs: DoubleArray, lows: DoubleArray, closes: DoubleArray, kPeriod: Int = 14, dPeriod: Int = 3): DoubleArray

    // 6. ĐỘ BIẾN ĐỘNG ATR (Average True Range - Đo lường biến động tính Stop-Loss/Take-Profit)
    external fun calculateATR(highs: DoubleArray, lows: DoubleArray, closes: DoubleArray, period: Int = 14): Double

    // 7. TIỆN ÍCH HỆ THỐNG
    external fun fuzzyScore(targetStr: String, candidateStr: String): Int
    external fun mergeLoRAWeights(baseGgufPath: String, deltaLoraPath: String, alpha: Float): Boolean
}
