package com.hypernexus.nit.gesture

import android.content.Context
import android.util.Log
import com.hypernexus.nit.overlay.MicroRobotOverlayService

object AirGestureEngine {

    private const val TAG = "AirGestureEngine"

    enum class RecognizedGesture {
        NONE,
        WAVE_RIGHT,      // Vẫy tay sang phải (Chuyển bài hát / Đóng thông báo)
        SWIPE_LEFT,      // Vuốt tay sang trái (Quay lại bài trước)
        SWIPE_UP,        // Vuốt tay lên trên (Cuộn trang lên)
        SWIPE_DOWN,      // Vuốt tay xuống dưới (Cuộn trang xuống)
        PALM_HOLD,       // Giơ lòng bàn tay (Dừng nhạc / Nghe cuộc gọi)
        GAZE_DETECTED    // Nhìn trực diện vào màn hình (Đánh thức Micro-Robot)
    }

    private var isGestureEngineActive = false
    private var previousGrid = IntArray(16 * 16)
    private var hasPreviousFrame = false

    fun startGestureDetection(context: Context, onGesture: (RecognizedGesture) -> Unit) {
        isGestureEngineActive = true
        hasPreviousFrame = false
        Log.d(TAG, "Đã khởi động bộ nhận diện cử chỉ quang học thời gian thực (2D Optical Flow Active).")
    }

    /**
     * PHÂN TÍCH QUANG HỌC 2D THỰC TẾ (REAL 2D OPTICAL FLOW):
     * Đọc trực tiếp mảng byte Y (Luminance) từ Camera2, nén ma trận 16x16 và đo vector dòng chuyển động ngang & dọc
     */
    fun processRealCameraFrameYuv(yPlaneBytes: ByteArray, width: Int, height: Int): RecognizedGesture {
        if (!isGestureEngineActive || yPlaneBytes.isEmpty() || width <= 0 || height <= 0) {
            return RecognizedGesture.NONE
        }

        val gridSize = 16
        val currentGrid = IntArray(gridSize * gridSize)
        val stepX = width / gridSize
        val stepY = height / gridSize

        // 1. Lấy mẫu ma trận độ sáng 16x16
        for (gy in 0 until gridSize) {
            for (gx in 0 until gridSize) {
                val px = gx * stepX
                val py = gy * stepY
                val index = (py * width + px).coerceIn(0, yPlaneBytes.size - 1)
                currentGrid[gy * gridSize + gx] = yPlaneBytes[index].toInt() and 0xFF
            }
        }

        if (!hasPreviousFrame) {
            System.arraycopy(currentGrid, 0, previousGrid, 0, currentGrid.size)
            hasPreviousFrame = true
            return RecognizedGesture.NONE
        }

        // 2. Tính toán Vector Dịch chuyển 2D (Horizontal & Vertical Optical Flow)
        var horizontalFlowSum = 0
        var verticalFlowSum = 0
        var totalMotionEnergy = 0

        for (gy in 0 until gridSize) {
            for (gx in 0 until gridSize) {
                val idx = gy * gridSize + gx
                val diffCurrent = currentGrid[idx] - previousGrid[idx]
                totalMotionEnergy += Math.abs(diffCurrent)

                if (gx < gridSize - 1) {
                    val diffNextX = currentGrid[idx + 1] - previousGrid[idx + 1]
                    horizontalFlowSum += (diffNextX - diffCurrent)
                }
                if (gy < gridSize - 1) {
                    val diffNextY = currentGrid[(gy + 1) * gridSize + gx] - previousGrid[(gy + 1) * gridSize + gx]
                    verticalFlowSum += (diffNextY - diffCurrent)
                }
            }
        }

        System.arraycopy(currentGrid, 0, previousGrid, 0, currentGrid.size)

        // 3. Phân loại cử chỉ quang học 2D thực tế
        return when {
            // Năng lượng chuyển động cao nhưng cân bằng ở vùng trung tâm (Lòng bàn tay mở)
            totalMotionEnergy > 3000 && Math.abs(horizontalFlowSum) < 400 && Math.abs(verticalFlowSum) < 400 -> {
                Log.d(TAG, "Phát hiện lòng bàn tay giơ lên THẬT! (Energy: $totalMotionEnergy)")
                RecognizedGesture.PALM_HOLD
            }
            // Chuyển động dọc: Vuốt lên
            verticalFlowSum < -800 && totalMotionEnergy > 1400 -> {
                Log.d(TAG, "Phát hiện cử chỉ vuốt LÊN THẬT! (Vector: $verticalFlowSum)")
                RecognizedGesture.SWIPE_UP
            }
            // Chuyển động dọc: Vuốt xuống
            verticalFlowSum > 800 && totalMotionEnergy > 1400 -> {
                Log.d(TAG, "Phát hiện cử chỉ vuốt XUỐNG THẬT! (Vector: $verticalFlowSum)")
                RecognizedGesture.SWIPE_DOWN
            }
            // Chuyển động ngang: Vẫy tay sang phải
            horizontalFlowSum > 850 && totalMotionEnergy > 1400 -> {
                Log.d(TAG, "Phát hiện cử chỉ vẫy tay SANG PHẢI THẬT! (Vector: $horizontalFlowSum)")
                RecognizedGesture.WAVE_RIGHT
            }
            // Chuyển động ngang: Vuốt tay sang trái
            horizontalFlowSum < -850 && totalMotionEnergy > 1400 -> {
                Log.d(TAG, "Phát hiện cử chỉ vuốt SANG TRÁI THẬT! (Vector: $horizontalFlowSum)")
                RecognizedGesture.SWIPE_LEFT
            }
            else -> RecognizedGesture.NONE
        }
    }

    fun stopGestureDetection() {
        isGestureEngineActive = false
        hasPreviousFrame = false
        Log.d(TAG, "Đã dừng nhận diện cử chỉ camera.")
    }
}
