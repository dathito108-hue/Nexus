package com.hypernexus.nit.gesture

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.ImageFormat
import android.hardware.camera2.CameraCaptureSession
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraDevice
import android.hardware.camera2.CameraManager
import android.media.ImageReader
import android.os.Handler
import android.os.HandlerThread
import android.util.Log

class FrontCameraGestureDriver(private val context: Context) {

    companion object {
        private const val TAG = "FrontCameraDriver"
        private const val PREVIEW_WIDTH = 320
        private const val PREVIEW_HEIGHT = 240
    }

    private var cameraDevice: CameraDevice? = null
    private var imageReader: ImageReader? = null
    private var backgroundThread: HandlerThread? = null
    private var backgroundHandler: Handler? = null

    fun start(onGestureDetected: (AirGestureEngine.RecognizedGesture) -> Unit) {
        startBackgroundThread()
        AirGestureEngine.startGestureDetection(context) { gesture ->
            onGestureDetected(gesture)
        }
        openFrontCamera(onGestureDetected)
    }

    private fun startBackgroundThread() {
        backgroundThread = HandlerThread("CameraGestureThread").apply { start() }
        backgroundHandler = Handler(backgroundThread?.looper!!)
    }

    @SuppressLint("MissingPermission")
    private fun openFrontCamera(onGestureDetected: (AirGestureEngine.RecognizedGesture) -> Unit) {
        val manager = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        try {
            var frontCameraId: String? = null
            for (id in manager.cameraIdList) {
                val chars = manager.getCameraCharacteristics(id)
                val facing = chars.get(CameraCharacteristics.LENS_FACING)
                if (facing == CameraCharacteristics.LENS_FACING_FRONT) {
                    frontCameraId = id
                    break
                }
            }

            if (frontCameraId == null) {
                Log.w(TAG, "Không tìm thấy Camera trước trên thiết bị.")
                return
            }

            imageReader = ImageReader.newInstance(PREVIEW_WIDTH, PREVIEW_HEIGHT, ImageFormat.YUV_420_888, 2).apply {
                setOnImageAvailableListener({ reader ->
                    val image = reader.acquireLatestImage() ?: return@setOnImageAvailableListener
                    try {
                        val planes = image.planes
                        if (planes.isNotEmpty()) {
                            val yBuffer = planes[0].buffer
                            val yBytes = ByteArray(yBuffer.remaining())
                            yBuffer.get(yBytes)

                            // Đưa mảng byte YUV thật vào thuật toán phân tích dòng quang học
                            val gesture = AirGestureEngine.processRealCameraFrameYuv(yBytes, PREVIEW_WIDTH, PREVIEW_HEIGHT)
                            if (gesture != AirGestureEngine.RecognizedGesture.NONE) {
                                onGestureDetected(gesture)
                            }
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Lỗi đọc frame camera: ${e.message}")
                    } finally {
                        image.close()
                    }
                }, backgroundHandler)
            }

            manager.openCamera(frontCameraId, object : CameraDevice.StateCallback() {
                override fun onOpened(camera: CameraDevice) {
                    cameraDevice = camera
                    startCaptureSession()
                }
                override fun onDisconnected(camera: CameraDevice) {
                    camera.close()
                    cameraDevice = null
                }
                override fun onError(camera: CameraDevice, error: Int) {
                    camera.close()
                    cameraDevice = null
                    Log.e(TAG, "Lỗi mở Camera2: $error")
                }
            }, backgroundHandler)

        } catch (e: Exception) {
            Log.e(TAG, "Lỗi khởi tạo Camera trước: ${e.message}")
        }
    }

    private fun startCaptureSession() {
        val camera = cameraDevice ?: return
        val readerSurface = imageReader?.surface ?: return

        try {
            val builder = camera.createCaptureRequest(CameraDevice.TEMPLATE_PREVIEW).apply {
                addTarget(readerSurface)
            }

            @Suppress("DEPRECATION")
            camera.createCaptureSession(listOf(readerSurface), object : CameraCaptureSession.StateCallback() {
                override fun onConfigured(session: CameraCaptureSession) {
                    try {
                        session.setRepeatingRequest(builder.build(), null, backgroundHandler)
                        Log.d(TAG, "Camera trước đang stream khung hình YUV thật vào AI Engine (320x240).")
                    } catch (e: Exception) {
                        Log.e(TAG, "Lỗi setRepeatingRequest: ${e.message}")
                    }
                }
                override fun onConfigureFailed(session: CameraCaptureSession) {}
            }, backgroundHandler)

        } catch (e: Exception) {
            Log.e(TAG, "Lỗi capture session: ${e.message}")
        }
    }

    fun stop() {
        AirGestureEngine.stopGestureDetection()
        cameraDevice?.close()
        cameraDevice = null
        imageReader?.close()
        imageReader = null
        backgroundThread?.quitSafely()
        backgroundThread = null
    }
}
