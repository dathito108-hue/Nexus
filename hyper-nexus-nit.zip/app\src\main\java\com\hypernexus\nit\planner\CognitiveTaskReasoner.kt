package com.hypernexus.nit.planner

import java.util.Calendar
import java.util.regex.Pattern

/**
 * LÕI SUY LUẬN PHÂN RÃ MỤC TIÊU & BIÊN DỊCH KẾ HOẠCH TỰ HÀNH (COGNITIVE TASK REASONER)
 * Phân tích ngôn ngữ tự nhiên tiếng Việt, trích xuất thời gian, điều kiện thị trường/thiết bị,
 * và phân rã mục tiêu phức tạp thành chuỗi các bước hành động (Action Graph).
 */
object CognitiveTaskReasoner {

    /**
     * SUY LUẬN & LẬP KẾ HOẠCH TỪ MỤC TIÊU CỦA NGƯỜI DÙNG
     */
    fun reasonAndCreatePlan(userGoal: String): TaskPlan {
        val lowerGoal = userGoal.lowercase().trim()

        // 1. Phân tích Thời Gian Kích Hoạt (Trigger Time Extraction)
        val (triggerType, triggerTimeMs, triggerCondition) = extractTrigger(lowerGoal)

        val steps = mutableListOf<PlanStep>()
        var stepCounter = 1

        // 2. Phân rã mục tiêu thành các bước hành động (Action Decomposition)

        // HƯỚNG 1: DỰNG HÌNH & XUẤT MÁY IN 3D (PROCEDURAL & DYNAMIC SYNTHESIS THEO MÔ TẢ)
        if (containsAny(lowerGoal, "3d", "mô hình", "in 3d", "máy in", "stl", "bánh răng", "giá đỡ", "cờ lê", "bình hoa", "tản nhiệt", "robot", "phi thuyền", "cốc", "ly", "hộp", "tai nghe", "vỏ", "chân đế") ||
            (containsAny(lowerGoal, "dựng", "thiết kế", "vẽ") && containsAny(lowerGoal, "3d", "mô hình"))) {

            val isCustom = com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.isCustom3DPrompt(userGoal)
            if (isCustom) {
                val spec = com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.parse3DSpecFromPrompt(userGoal)
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Dựng hình 3D độc bản theo mô tả: ${spec.title}",
                        actionType = ActionType.GENERATE_3D_MODEL,
                        params = mapOf("CUSTOM_3D_PROMPT" to userGoal, "TITLE" to spec.title)
                    )
                )
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Phân tích thể tích & khối lượng nhựa Slicer kín nước (Watertight)",
                        actionType = ActionType.SLICER_ANALYZE,
                        params = mapOf("CUSTOM_3D_PROMPT" to userGoal)
                    )
                )
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Xuất file máy in 3D Binary STL (.STL)",
                        actionType = ActionType.EXPORT_3D_PRINT,
                        params = mapOf("CUSTOM_3D_PROMPT" to userGoal, "FORMAT" to "BINARY_STL")
                    )
                )
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Thông báo hoàn thành qua giọng nói",
                        actionType = ActionType.VOICE_NOTIFY,
                        params = mapOf("MESSAGE" to "Đã hoàn thành dựng mô hình 3D độc bản ${spec.title} và sẵn sàng in 3D.")
                    )
                )
                return TaskPlan(
                    title = "Kế hoạch dựng 3D độc bản: ${spec.title}",
                    rawGoal = userGoal,
                    triggerType = triggerType,
                    triggerTimeMs = triggerTimeMs,
                    triggerCondition = triggerCondition,
                    steps = steps
                )
            } else {
                val modelType = detect3DModelType(lowerGoal)
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Dựng hình tham số 3D $modelType",
                        actionType = ActionType.GENERATE_3D_MODEL,
                        params = mapOf("MODEL_TYPE" to modelType)
                    )
                )
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Phân tích thể tích & khối lượng nhựa in 3D (Slicer Analytics)",
                        actionType = ActionType.SLICER_ANALYZE,
                        params = mapOf("MODEL_TYPE" to modelType)
                    )
                )
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Xuất file máy in 3D Binary STL (.STL)",
                        actionType = ActionType.EXPORT_3D_PRINT,
                        params = mapOf("MODEL_TYPE" to modelType, "FORMAT" to "BINARY_STL")
                    )
                )
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Thông báo hoàn thành qua giọng nói",
                        actionType = ActionType.VOICE_NOTIFY,
                        params = mapOf("MESSAGE" to "Đã hoàn thành dựng và xuất file in 3D mô hình $modelType.")
                    )
                )
                return TaskPlan(
                    title = "Kế hoạch dựng & xuất in 3D: $modelType",
                    rawGoal = userGoal,
                    triggerType = triggerType,
                    triggerTimeMs = triggerTimeMs,
                    triggerCondition = triggerCondition,
                    steps = steps
                )
            }
        }

        // HƯỚNG 2: ĐỊNH LƯỢNG TÀI CHÍNH SOLANA & HOÁN ĐỔI SWAP
        if (containsAny(lowerGoal, "solana", "sol", "dex", "quant", "rsi", "macd", "giá sol", "săn đáy", "swap", "hoán đổi")) {
            val token = detectToken(lowerGoal)
            steps.add(
                PlanStep(
                    stepId = stepCounter++,
                    title = "Quét thanh khoản & đo chỉ số nến TA-Lib cho $token",
                    actionType = ActionType.SOLANA_QUANT_ANALYZE,
                    params = mapOf("TOKEN" to token)
                )
            )
            if (containsAny(lowerGoal, "swap", "mua", "bán", "hoán đổi", "vào lệnh")) {
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Định tuyến Jupiter v6 & Ký xác thực Knox Biometric",
                        actionType = ActionType.TOKEN_SWAP,
                        params = mapOf("TOKEN" to token, "AMOUNT" to "0.1"),
                        condition = if (lowerGoal.contains("rsi")) "RSI < 35" else null
                    )
                )
            }
            steps.add(
                PlanStep(
                    stepId = stepCounter++,
                    title = "Báo cáo tín hiệu định lượng qua giọng nói",
                    actionType = ActionType.VOICE_NOTIFY,
                    params = mapOf("MESSAGE" to "Đã phân tích xong thị trường $token theo kế hoạch.")
                )
            )
            return TaskPlan(
                title = "Kế hoạch định lượng & theo dõi $token",
                rawGoal = userGoal,
                triggerType = triggerType,
                triggerTimeMs = triggerTimeMs,
                triggerCondition = triggerCondition,
                steps = steps
            )
        }

        // HƯỚNG 3: KIỂM TOÁN HỢP ĐỒNG ON-CHAIN RUGCHECK
        if (containsAny(lowerGoal, "rugcheck", "kiểm toán", "quét token", "an toàn không", "honeypot")) {
            steps.add(
                PlanStep(
                    stepId = stepCounter++,
                    title = "Quét Mint/Freeze Authority On-Chain RugCheck",
                    actionType = ActionType.RUGCHECK_AUDIT,
                    params = mapOf("TOKEN_MINT" to "So11111111111111111111111111111111111111112")
                )
            )
            steps.add(
                PlanStep(
                    stepId = stepCounter++,
                    title = "Cảnh báo mức độ an toàn qua giọng nói",
                    actionType = ActionType.VOICE_NOTIFY,
                    params = mapOf("MESSAGE" to "Đã kiểm toán hợp đồng On-Chain xong.")
                )
            )
            return TaskPlan(
                title = "Kế hoạch kiểm toán bảo mật On-Chain",
                rawGoal = userGoal,
                triggerType = triggerType,
                triggerTimeMs = triggerTimeMs,
                triggerCondition = triggerCondition,
                steps = steps
            )
        }

        // HƯỚNG 4: TÌM KIẾM INTERNET THỜI GIAN THỰC & RAG
        if (containsAny(lowerGoal, "tìm kiếm", "tra cứu", "tin tức", "xem bài viết", "internet", "google", "đọc báo")) {
            val query = extractSearchQuery(lowerGoal)
            steps.add(
                PlanStep(
                    stepId = stepCounter++,
                    title = "Truy vấn Internet thời gian thực: $query",
                    actionType = ActionType.WEB_SEARCH,
                    params = mapOf("QUERY" to query)
                )
            )
            steps.add(
                PlanStep(
                    stepId = stepCounter++,
                    title = "Tóm tắt thông tin quan trọng qua giọng nói",
                    actionType = ActionType.VOICE_NOTIFY,
                    params = mapOf("MESSAGE" to "Đã tìm thấy tin tức mới nhất về $query.")
                )
            )
            return TaskPlan(
                title = "Kế hoạch tra cứu Internet: $query",
                rawGoal = userGoal,
                triggerType = triggerType,
                triggerTimeMs = triggerTimeMs,
                triggerCondition = triggerCondition,
                steps = steps
            )
        }

        // HƯỚNG 5: TỰ ĐỘNG HÓA BIÊN TẬP CAPCUT PRO STUDIO (DYNAMIC PROMPT SYNTHESIS & PRESETS)
        if (containsAny(lowerGoal, "capcut", "cắt video", "ghép video", "dựng clip", "phụ đề video", "sub video", "video 9:16", "xuất 4k", "chủ đề video", "hiệu ứng video", "ghép âm thanh", "cyberpunk", "vintage", "vlog", "ẩm thực", "review")) {
            val isCustomCapcut = com.hypernexus.nit.video.DynamicCapCutSynthesisEngine.isCustomCapCutPrompt(userGoal)
            if (isCustomCapcut) {
                val spec = com.hypernexus.nit.video.DynamicCapCutSynthesisEngine.parseCapCutSpecFromPrompt(userGoal)
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Biên tập video độc bản: ${spec.projectTitle} (Cắt ${spec.cutPacingIntervalSeconds}s, ${spec.targetAspectRatio}, LUT ${spec.colorFilterName})",
                        actionType = ActionType.CAPCUT_MACRO,
                        params = mapOf("CUSTOM_CAPCUT_PROMPT" to userGoal, "TITLE" to spec.projectTitle)
                    )
                )
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Báo cáo tiến trình xuất bản video độc bản qua giọng nói",
                        actionType = ActionType.VOICE_NOTIFY,
                        params = mapOf("MESSAGE" to "Đã hoàn thành sản xuất video CapCut độc bản ${spec.projectTitle}.")
                    )
                )
                return TaskPlan(
                    title = "Kế hoạch CapCut Độc Bản: ${spec.projectTitle}",
                    rawGoal = userGoal,
                    triggerType = triggerType,
                    triggerTimeMs = triggerTimeMs,
                    triggerCondition = triggerCondition,
                    steps = steps
                )
            }

            val hasTheme = containsAny(lowerGoal, "chủ đề", "hiệu ứng", "âm thanh", "nhạc", "cyberpunk", "vintage", "vlog", "du lịch", "gaming", "sang trọng")
            if (hasTheme) {
                val theme = com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.matchThemeFromCommand(lowerGoal)
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Định hình chủ đề ${theme.displayName}, chèn hiệu ứng & ghép BGM/SFX",
                        actionType = ActionType.CAPCUT_MACRO,
                        params = mapOf("THEME" to theme.code)
                    )
                )
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Báo cáo tiến trình xuất bản video chủ đề qua giọng nói",
                        actionType = ActionType.VOICE_NOTIFY,
                        params = mapOf("MESSAGE" to "Đã hoàn thành sản xuất video chủ đề ${theme.displayName} trên CapCut.")
                    )
                )
                return TaskPlan(
                    title = "Kế hoạch CapCut Theme: ${theme.displayName}",
                    rawGoal = userGoal,
                    triggerType = triggerType,
                    triggerTimeMs = triggerTimeMs,
                    triggerCondition = triggerCondition,
                    steps = steps
                )
            } else {
                val preset = com.hypernexus.nit.video.CapCutProAutomationEngine.matchPresetFromCommand(lowerGoal)
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Thực thi kịch bản CapCut Pro: ${preset.displayName}",
                        actionType = ActionType.CAPCUT_MACRO,
                        params = mapOf("PRESET" to preset.code)
                    )
                )
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Báo cáo tiến trình xuất bản video qua giọng nói",
                        actionType = ActionType.VOICE_NOTIFY,
                        params = mapOf("MESSAGE" to "Đã hoàn thành kịch bản biên tập ${preset.displayName} trên CapCut.")
                    )
                )
                return TaskPlan(
                    title = "Kế hoạch CapCut Pro: ${preset.displayName}",
                    rawGoal = userGoal,
                    triggerType = triggerType,
                    triggerTimeMs = triggerTimeMs,
                    triggerCondition = triggerCondition,
                    steps = steps
                )
            }
        }

        // HƯỚNG 6: NHÀ THÔNG MINH (SMART HOME)
        if (containsAny(lowerGoal, "đèn", "điều hòa", "máy lạnh", "quạt", "phòng khách", "phòng ngủ")) {
            val isLight = lowerGoal.contains("đèn")
            val isTurnOn = lowerGoal.contains("bật") || lowerGoal.contains("mở")
            steps.add(
                PlanStep(
                    stepId = stepCounter++,
                    title = "Điều khiển thiết bị qua mạng nội bộ LAN",
                    actionType = ActionType.SMART_HOME_CONTROL,
                    params = mapOf(
                        "DEVICE" to if (isLight) "LIGHT" else "AIR_CONDITIONER",
                        "STATE" to if (isTurnOn) "ON" else "OFF"
                    )
                )
            )
            steps.add(
                PlanStep(
                    stepId = stepCounter++,
                    title = "Xác nhận trạng thái thiết bị",
                    actionType = ActionType.VOICE_NOTIFY,
                    params = mapOf("MESSAGE" to if (isTurnOn) "Đã bật thiết bị theo kế hoạch." else "Đã tắt thiết bị theo kế hoạch.")
                )
            )
            return TaskPlan(
                title = "Kế hoạch điều khiển nhà thông minh",
                rawGoal = userGoal,
                triggerType = triggerType,
                triggerTimeMs = triggerTimeMs,
                triggerCondition = triggerCondition,
                steps = steps
            )
        }

        // HƯỚNG 7: KÝ ỨC MÀN HÌNH (SCREEN REWIND FTS4)
        if (containsAny(lowerGoal, "ký ức", "hồi tưởng", "rewind", "đã xem gì", "đã đọc gì", "hôm qua")) {
            val query = lowerGoal.replace("tìm lại", "").replace("ký ức", "").trim()
            steps.add(
                PlanStep(
                    stepId = stepCounter++,
                    title = "Truy vấn SQLite FTS4 ký ức màn hình: $query",
                    actionType = ActionType.SCREEN_REWIND_QUERY,
                    params = mapOf("QUERY" to query)
                )
            )
            steps.add(
                PlanStep(
                    stepId = stepCounter++,
                    title = "Báo cáo mốc thời gian và ứng dụng đã xem",
                    actionType = ActionType.VOICE_NOTIFY,
                    params = mapOf("MESSAGE" to "Đã tìm thấy bản ghi ký ức màn hình phù hợp.")
                )
            )
            return TaskPlan(
                title = "Kế hoạch truy xuất ký ức màn hình",
                rawGoal = userGoal,
                triggerType = triggerType,
                triggerTimeMs = triggerTimeMs,
                triggerCondition = triggerCondition,
                steps = steps
            )
        }

        // HƯỚNG 8: LẬP TRÌNH GAME TRÊN WEB 120 FPS (WEB GAME ENGINE PRO & DYNAMIC PROMPT SYNTHESIS)
        if (containsAny(lowerGoal, "game web", "game trên web", "trò chơi web", "game canvas", "bắn phi thuyền", "nhảy đi ải", "phá gạch", "rắn săn mồi", "mê cung 3d", "thủ trụ", "cá lớn nuốt cá bé", "cá lớn", "đua xe", "né thiên thạch", "đấu trường", "sinh tồn") ||
            (containsAny(lowerGoal, "game", "trò chơi") && containsAny(lowerGoal, "lập trình", "tạo", "code", "thiết kế", "web", "mô tả", "theo ý", "độc bản"))) {

            val isCustom = com.hypernexus.nit.web.DynamicGameSynthesisEngine.isCustomGamePrompt(userGoal)
            if (isCustom) {
                val spec = com.hypernexus.nit.web.DynamicGameSynthesisEngine.parseGameSpecFromPrompt(userGoal)
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Phân tích ngữ nghĩa & lập trình game độc bản: ${spec.gameTitle}",
                        actionType = ActionType.WEB_DEVELOP,
                        params = mapOf("CUSTOM_GAME_PROMPT" to userGoal, "TITLE" to spec.gameTitle)
                    )
                )
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Khởi chạy máy chủ HTTP Game Sandbox (127.0.0.1:8088)",
                        actionType = ActionType.WEB_HOST_LOCAL,
                        params = mapOf("CUSTOM_GAME_PROMPT" to userGoal)
                    )
                )
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Thông báo hoàn thành qua giọng nói & sẵn sàng trải nghiệm 120 FPS",
                        actionType = ActionType.VOICE_NOTIFY,
                        params = mapOf("MESSAGE" to "Đã lập trình xong game độc bản ${spec.gameTitle} theo đúng mô tả của bạn và sẵn sàng trải nghiệm 120 FPS.")
                    )
                )
                return TaskPlan(
                    title = "Kế hoạch Game Tự Hành Độc Bản: ${spec.gameTitle}",
                    rawGoal = userGoal,
                    triggerType = triggerType,
                    triggerTimeMs = triggerTimeMs,
                    triggerCondition = triggerCondition,
                    steps = steps
                )
            } else {
                val genre = com.hypernexus.nit.web.WebGameDevelopmentEngine.matchGameGenreFromCommand(lowerGoal)
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Kiến tạo kiến trúc & lập trình game: ${genre.displayName}",
                        actionType = ActionType.WEB_DEVELOP,
                        params = mapOf("GAME_GENRE" to genre.code, "TITLE" to genre.displayName)
                    )
                )
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Khởi chạy máy chủ HTTP Game Sandbox (127.0.0.1:8088)",
                        actionType = ActionType.WEB_HOST_LOCAL,
                        params = mapOf("GAME_GENRE" to genre.code)
                    )
                )
                steps.add(
                    PlanStep(
                        stepId = stepCounter++,
                        title = "Thông báo hoàn thành qua giọng nói & sẵn sàng trải nghiệm 120 FPS",
                        actionType = ActionType.VOICE_NOTIFY,
                        params = mapOf("MESSAGE" to "Đã lập trình xong game ${genre.displayName} 120 FPS và khởi chạy máy chủ cục bộ.")
                    )
                )
                return TaskPlan(
                    title = "Kế hoạch Game Studio: ${genre.displayName}",
                    rawGoal = userGoal,
                    triggerType = triggerType,
                    triggerTimeMs = triggerTimeMs,
                    triggerCondition = triggerCondition,
                    steps = steps
                )
            }
        }

        // HƯỚNG 9: LẬP TRÌNH & XUẤT BẢN DỰ ÁN WEB PRO (HTML5/CSS3/JS/CANVAS)
        if (containsAny(lowerGoal, "lập trình web", "thiết kế web", "tạo web", "tạo trang web", "code web", "web bán hàng", "web dashboard", "web portfolio", "web 3d", "web landing")) {
            val template = com.hypernexus.nit.web.WebDevelopmentEngine.matchTemplateFromCommand(lowerGoal)
            steps.add(
                PlanStep(
                    stepId = stepCounter++,
                    title = "Khởi tạo cấu trúc & sinh mã nguồn Web: ${template.displayName}",
                    actionType = ActionType.WEB_DEVELOP,
                    params = mapOf("TEMPLATE" to template.code, "TITLE" to template.displayName)
                )
            )
            steps.add(
                PlanStep(
                    stepId = stepCounter++,
                    title = "Khởi chạy máy chủ HTTP Sandbox cục bộ (127.0.0.1:8088)",
                    actionType = ActionType.WEB_HOST_LOCAL,
                    params = mapOf("TEMPLATE" to template.code)
                )
            )
            steps.add(
                PlanStep(
                    stepId = stepCounter++,
                    title = "Thông báo hoàn thành qua giọng nói & sẵn sàng Live Preview",
                    actionType = ActionType.VOICE_NOTIFY,
                    params = mapOf("MESSAGE" to "Đã lập trình xong trang web ${template.displayName} và khởi chạy máy chủ cục bộ.")
                )
            )
            return TaskPlan(
                title = "Kế hoạch Web Studio: ${template.displayName}",
                rawGoal = userGoal,
                triggerType = triggerType,
                triggerTimeMs = triggerTimeMs,
                triggerCondition = triggerCondition,
                steps = steps
            )
        }

        // MẶC ĐỊNH: KẾ HOẠCH TỔNG QUÁT NHẮC NHỞ & PHÂN TÍCH
        steps.add(
            PlanStep(
                stepId = stepCounter++,
                title = "Thực hiện nhiệm vụ: $userGoal",
                actionType = ActionType.VOICE_NOTIFY,
                params = mapOf("MESSAGE" to "Nít đã kích hoạt nhiệm vụ theo lịch hẹn: $userGoal")
            )
        )
        return TaskPlan(
            title = "Nhiệm vụ tự hành: ${userGoal.take(24)}...",
            rawGoal = userGoal,
            triggerType = triggerType,
            triggerTimeMs = triggerTimeMs,
            triggerCondition = triggerCondition,
            steps = steps
        )
    }

    // =========================================================================
    // CÁC THUẬT TOÁN BÓC TÁCH NGỮ NGHĨA PHỤ TRỢ (SEMANTIC EXTRACTION HELPERS)
    // =========================================================================

    private fun extractTrigger(goal: String): Triple<TriggerType, Long, String?> {
        val now = System.currentTimeMillis()
        val cal = Calendar.getInstance()

        // 1. Điều kiện thị trường
        if (goal.contains("khi giá") || goal.contains("khi rsi")) {
            return Triple(TriggerType.MARKET_CONDITION, 0L, goal)
        }

        // 2. Điều kiện thiết bị (cắm sạc, ban đêm)
        if (goal.contains("cắm sạc") || goal.contains("khi sạc") || goal.contains("ban đêm")) {
            return Triple(TriggerType.DEVICE_CONDITION, 0L, "CHARGING_OR_NIGHT")
        }

        // 3. Thời gian: Sau X phút nữa
        val minutePattern = Pattern.compile("sau\\s+(\\d+)\\s*phút")
        val minMatcher = minutePattern.matcher(goal)
        if (minMatcher.find()) {
            val minutes = minMatcher.group(1)?.toIntOrNull() ?: 10
            return Triple(TriggerType.EXACT_TIME, now + minutes * 60 * 1000L, null)
        }

        // 4. Thời gian: Lúc H giờ [M phút] (sáng/tối)
        val hourPattern = Pattern.compile("(\\d{1,2})\\s*(?:h|giờ)(?:\\s*(\\d{1,2}))?")
        val hourMatcher = hourPattern.matcher(goal)
        if (hourMatcher.find()) {
            var hour = hourMatcher.group(1)?.toIntOrNull() ?: 8
            val minute = hourMatcher.group(2)?.toIntOrNull() ?: 0

            if (goal.contains("tối") || goal.contains("chiều")) {
                if (hour < 12) hour += 12
            }

            cal.set(Calendar.HOUR_OF_DAY, hour)
            cal.set(Calendar.MINUTE, minute)
            cal.set(Calendar.SECOND, 0)
            cal.set(Calendar.MILLISECOND, 0)

            // Nếu giờ đó hôm nay đã qua thì sang ngày mai
            if (cal.timeInMillis <= now || goal.contains("mai")) {
                cal.add(Calendar.DAY_OF_YEAR, 1)
            }
            return Triple(TriggerType.EXACT_TIME, cal.timeInMillis, null)
        }

        // Mặc định: Kích hoạt ngay lập tức
        return Triple(TriggerType.IMMEDIATE, now, null)
    }

    private fun detect3DModelType(goal: String): String {
        return when {
            goal.contains("bánh răng") -> "SPUR_GEAR"
            goal.contains("giá đỡ") || goal.contains("điện thoại") -> "PHONE_STAND"
            goal.contains("cờ lê") -> "MECHANICAL_WRENCH"
            goal.contains("bình") || goal.contains("lọ hoa") -> "PARAMETRIC_VASE"
            goal.contains("tản nhiệt") -> "HEATSINK"
            goal.contains("kiếm") -> "MECHA_SWORD"
            goal.contains("vệ tinh") -> "QUANTUM_SATELLITE"
            goal.contains("mũ") -> "CYBER_HELMET"
            goal.contains("phi thuyền") -> "SPACESHIP"
            goal.contains("drone") -> "NANO_DRONE"
            goal.contains("ghế") -> "FURNITURE_CHAIR"
            else -> "CYBER_ROBOT"
        }
    }

    private fun detectToken(goal: String): String {
        return when {
            goal.contains("jup") -> "JUP"
            goal.contains("ray") -> "RAY"
            goal.contains("bonk") -> "BONK"
            goal.contains("wif") -> "WIF"
            goal.contains("vàng") || goal.contains("gold") -> "GOLD"
            else -> "SOL"
        }
    }

    private fun extractSearchQuery(goal: String): String {
        val trimmed = goal.replace("tìm kiếm", "")
            .replace("tra cứu", "")
            .replace("xem tin tức", "")
            .replace("tin tức", "")
            .replace("trên internet", "")
            .trim()
        return if (trimmed.isNotEmpty()) trimmed else "tin tức công nghệ AI nổi bật hôm nay"
    }

    private fun containsAny(text: String, vararg keywords: String): Boolean {
        for (kw in keywords) {
            if (text.contains(kw)) return true
        }
        return false
    }
}
