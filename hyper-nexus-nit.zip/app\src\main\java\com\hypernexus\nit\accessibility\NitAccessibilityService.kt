package com.hypernexus.nit.accessibility

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import com.hypernexus.nit.overlay.MicroRobotOverlayService

class NitAccessibilityService : AccessibilityService() {

    companion object {
        var instance: NitAccessibilityService? = null
        private const val CAPCUT_PACKAGE = "com.lemon.lvoverseas"
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    private var screenTimelineManager: com.hypernexus.nit.evolution.ScreenTimelineMemoryManager? = null
    private var lastExtractTime = 0L

    fun getTimelineManager(): com.hypernexus.nit.evolution.ScreenTimelineMemoryManager? {
        if (screenTimelineManager == null) {
            screenTimelineManager = com.hypernexus.nit.evolution.ScreenTimelineMemoryManager(this)
        }
        return screenTimelineManager
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        screenTimelineManager = com.hypernexus.nit.evolution.ScreenTimelineMemoryManager(this)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val now = System.currentTimeMillis()
        if (now - lastExtractTime < 3500) return // Giới hạn tần suất 3.5s để bảo toàn pin

        val pkg = event.packageName?.toString() ?: return
        if (pkg == packageName) return // Bỏ qua màn hình của chính Nít

        val root = rootInActiveWindow ?: return
        lastExtractTime = now

        val sb = StringBuilder()
        extractNodeText(root, sb)

        val content = sb.toString().trim()
        if (content.length >= 25) {
            val appLabel = try {
                val pm = packageManager
                val appInfo = pm.getApplicationInfo(pkg, 0)
                pm.getApplicationLabel(appInfo).toString()
            } catch (e: Exception) {
                pkg
            }
            screenTimelineManager?.recordScreenContent(pkg, appLabel, content)
        }
    }

    private fun extractNodeText(node: AccessibilityNodeInfo?, sb: StringBuilder) {
        if (node == null || !node.isVisibleToUser) return
        if (node.isPassword) return // TUYỆT ĐỐI BẢO MẬT: Bỏ qua trường mật khẩu!
        val text = node.text
        if (!text.isNullOrBlank()) {
            sb.append(text).append(". ")
        }
        val desc = node.contentDescription
        if (!desc.isNullOrBlank() && desc != text) {
            sb.append(desc).append(". ")
        }
        for (i in 0 until node.childCount) {
            extractNodeText(node.getChild(i), sb)
        }
    }

    override fun onInterrupt() {
        instance = null
    }

    override fun onDestroy() {
        super.onDestroy()
        screenTimelineManager?.close()
        screenTimelineManager = null
        instance = null
    }

    /**
     * Tự động chạm vào tọa độ (X, Y) trên màn hình Samsung S21 FE (1080x2340)
     */
    fun performClick(x: Float, y: Float, durationMs: Long = 100, onComplete: (() -> Unit)? = null) {
        val clickPath = Path().apply {
            moveTo(x, y)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(clickPath, 0, durationMs))
            .build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                onComplete?.invoke()
            }
        }, null)
    }

    /**
     * Tự động vuốt từ (startX, startY) đến (endX, endY)
     */
    fun performSwipe(startX: Float, startY: Float, endX: Float, endY: Float, durationMs: Long = 300, onComplete: (() -> Unit)? = null) {
        val swipePath = Path().apply {
            moveTo(startX, startY)
            lineTo(endX, endY)
        }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(swipePath, 0, durationMs))
            .build()

        dispatchGesture(gesture, object : GestureResultCallback() {
            override fun onCompleted(gestureDescription: GestureDescription?) {
                super.onCompleted(gestureDescription)
                onComplete?.invoke()
            }
        }, null)
    }

    /**
     * THẺ CHUYÊN GIA: TỰ ĐỘNG HÓA CAPCUT CHUẨN XÁC TRÊN SAMSUNG S21 FE
     * Quy trình: Mở CapCut -> Bấm Dự án mới -> Chọn video đầu tiên -> Bấm Thêm -> Tách -> Xuất video
     */
    fun executeCapCutMacro(command: String) {
        val dm = resources.displayMetrics
        val width = dm.widthPixels.toFloat()   // 1080 px trên S21 FE
        val height = dm.heightPixels.toFloat() // 2340 px trên S21 FE

        // Báo hiệu robot đang trong chế độ hành động
        MicroRobotOverlayService.updateState(MicroRobotOverlayService.RobotState.ACTION)

        when (command) {
            "NEW_PROJECT" -> {
                // Tọa độ nút Dự án mới (Icon dấu cộng lớn ở nửa trên màn hình)
                performClick(width * 0.50f, height * 0.28f)
            }
            "SELECT_FIRST_VIDEO" -> {
                // Chọn video đầu tiên ở góc trên bên trái thư viện
                performClick(width * 0.20f, height * 0.22f) {
                    mainHandler.postDelayed({
                        // Bấm nút "Thêm" ở góc dưới bên phải
                        performClick(width * 0.85f, height * 0.95f)
                    }, 500)
                }
            }
            "SPLIT_TIMELINE" -> {
                // Tọa độ nút Tách (icon cái kéo) trên thanh công cụ timeline
                performClick(width * 0.12f, height * 0.92f)
            }
            "EXPORT_VIDEO" -> {
                // Tọa độ nút "Xuất" màu xanh ở góc trên bên phải
                performClick(width * 0.90f, height * 0.06f)
            }
            "AUTO_SUBTITLES" -> {
                kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
                    com.hypernexus.nit.video.CapCutProAutomationEngine.executeProEditingPreset(this@NitAccessibilityService, com.hypernexus.nit.video.CapCutProAutomationEngine.EditingPreset.AUTO_SUBTITLES)
                }
            }
            "VIRAL_REELS_916" -> {
                kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
                    com.hypernexus.nit.video.CapCutProAutomationEngine.executeProEditingPreset(this@NitAccessibilityService, com.hypernexus.nit.video.CapCutProAutomationEngine.EditingPreset.VIRAL_REELS_916)
                }
            }
            "EXPORT_4K_60FPS" -> {
                kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
                    com.hypernexus.nit.video.CapCutProAutomationEngine.executeProEditingPreset(this@NitAccessibilityService, com.hypernexus.nit.video.CapCutProAutomationEngine.EditingPreset.EXPORT_4K_60FPS)
                }
            }
            "BEAT_SYNC_CUTS" -> {
                kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
                    com.hypernexus.nit.video.CapCutProAutomationEngine.executeProEditingPreset(this@NitAccessibilityService, com.hypernexus.nit.video.CapCutProAutomationEngine.EditingPreset.BEAT_SYNC_CUTS)
                }
            }
            "SMART_AUDIO_ENHANCE" -> {
                kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
                    com.hypernexus.nit.video.CapCutProAutomationEngine.executeProEditingPreset(this@NitAccessibilityService, com.hypernexus.nit.video.CapCutProAutomationEngine.EditingPreset.SMART_AUDIO_ENHANCE)
                }
            }
            "FULL_AUTO_EDIT", "FULL_STUDIO_PIPELINE" -> {
                kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.Main).launch {
                    com.hypernexus.nit.video.CapCutProAutomationEngine.executeProEditingPreset(this@NitAccessibilityService, com.hypernexus.nit.video.CapCutProAutomationEngine.EditingPreset.FULL_STUDIO_PIPELINE)
                }
            }
        }
    }

    /**
     * Tìm kiếm và click vào node có chứa văn bản chỉ định trên màn hình
     */
    fun clickNodeByText(targetText: String): Boolean {
        val rootNode = rootInActiveWindow ?: return false
        val matchedNodes = rootNode.findAccessibilityNodeInfosByText(targetText)
        if (!matchedNodes.isNullOrEmpty()) {
            val node = matchedNodes[0]
            if (node.isClickable) {
                return node.performAction(AccessibilityNodeInfo.ACTION_CLICK)
            } else {
                node.parent?.let {
                    if (it.isClickable) return it.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
            }
        }
        return false
    }
}
