package com.hypernexus.nit.planner

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject

/**
 * CƠ SỞ DỮ LIỆU SQLITE LƯU TRỮ KẾ HOẠCH & LỊCH TRÌNH BỀN VỮNG (PERSISTENT PLAN DATABASE)
 */
class PlanDatabaseHelper(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val DATABASE_NAME = "hyper_nexus_planner.db"
        private const val DATABASE_VERSION = 1

        private const val TABLE_PLANS = "task_plans"
        private const val TABLE_STEPS = "plan_steps"
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE $TABLE_PLANS (
                plan_id TEXT PRIMARY KEY,
                title TEXT,
                raw_goal TEXT,
                trigger_type TEXT,
                trigger_time_ms INTEGER,
                repeat_interval_ms INTEGER,
                trigger_condition TEXT,
                status TEXT,
                created_at_ms INTEGER
            )
        """.trimIndent())

        db.execSQL("""
            CREATE TABLE $TABLE_STEPS (
                plan_id TEXT,
                step_id INTEGER,
                title TEXT,
                action_type TEXT,
                params_json TEXT,
                condition TEXT,
                status TEXT,
                output TEXT,
                PRIMARY KEY (plan_id, step_id)
            )
        """.trimIndent())
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_STEPS")
        db.execSQL("DROP TABLE IF EXISTS $TABLE_PLANS")
        onCreate(db)
    }

    fun savePlan(plan: TaskPlan) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            val cv = ContentValues().apply {
                put("plan_id", plan.planId)
                put("title", plan.title)
                put("raw_goal", plan.rawGoal)
                put("trigger_type", plan.triggerType.name)
                put("trigger_time_ms", plan.triggerTimeMs)
                put("repeat_interval_ms", plan.repeatIntervalMs)
                put("trigger_condition", plan.triggerCondition)
                put("status", plan.status.name)
                put("created_at_ms", plan.createdAtMs)
            }
            db.insertWithOnConflict(TABLE_PLANS, null, cv, SQLiteDatabase.CONFLICT_REPLACE)

            for (step in plan.steps) {
                val combinedMap = step.params.toMutableMap()
                if (step.dependsOnStepIds.isNotEmpty()) {
                    combinedMap["__DEPENDS_ON__"] = step.dependsOnStepIds.joinToString(",")
                }
                if (!step.healingReport.isNullOrEmpty()) {
                    combinedMap["__HEALING_REPORT__"] = step.healingReport!!
                }
                val scv = ContentValues().apply {
                    put("plan_id", plan.planId)
                    put("step_id", step.stepId)
                    put("title", step.title)
                    put("action_type", step.actionType.name)
                    put("params_json", JSONObject(combinedMap as Map<*, *>).toString())
                    put("condition", step.condition)
                    put("status", step.status.name)
                    put("output", step.output)
                }
                db.insertWithOnConflict(TABLE_STEPS, null, scv, SQLiteDatabase.CONFLICT_REPLACE)
            }
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    fun updatePlanStatus(planId: String, status: PlanStatus) {
        val db = writableDatabase
        val cv = ContentValues().apply {
            put("status", status.name)
        }
        db.update(TABLE_PLANS, cv, "plan_id = ?", arrayOf(planId))
    }

    fun updateStepStatus(planId: String, stepId: Int, status: StepStatus, output: String? = null) {
        val db = writableDatabase
        val cv = ContentValues().apply {
            put("status", status.name)
            if (output != null) put("output", output)
        }
        db.update(TABLE_STEPS, cv, "plan_id = ? AND step_id = ?", arrayOf(planId, stepId.toString()))
    }

    fun getAllActivePlans(): List<TaskPlan> {
        val db = readableDatabase
        val plans = mutableListOf<TaskPlan>()

        val cursor = db.rawQuery(
            "SELECT * FROM $TABLE_PLANS WHERE status IN ('ACTIVE', 'RUNNING') ORDER BY created_at_ms DESC",
            null
        )
        while (cursor.moveToNext()) {
            val planId = cursor.getString(cursor.getColumnIndexOrThrow("plan_id"))
            val title = cursor.getString(cursor.getColumnIndexOrThrow("title"))
            val rawGoal = cursor.getString(cursor.getColumnIndexOrThrow("raw_goal"))
            val triggerType = TriggerType.valueOf(cursor.getString(cursor.getColumnIndexOrThrow("trigger_type")))
            val triggerTimeMs = cursor.getLong(cursor.getColumnIndexOrThrow("trigger_time_ms"))
            val repeatIntervalMs = cursor.getLong(cursor.getColumnIndexOrThrow("repeat_interval_ms"))
            val triggerCondition = cursor.getString(cursor.getColumnIndexOrThrow("trigger_condition"))
            val status = PlanStatus.valueOf(cursor.getString(cursor.getColumnIndexOrThrow("status")))
            val createdAtMs = cursor.getLong(cursor.getColumnIndexOrThrow("created_at_ms"))

            val steps = getStepsForPlan(planId)

            plans.add(
                TaskPlan(
                    planId = planId,
                    title = title,
                    rawGoal = rawGoal,
                    triggerType = triggerType,
                    triggerTimeMs = triggerTimeMs,
                    repeatIntervalMs = repeatIntervalMs,
                    triggerCondition = triggerCondition,
                    steps = steps.toMutableList(),
                    status = status,
                    createdAtMs = createdAtMs
                )
            )
        }
        cursor.close()
        return plans
    }

    fun getAllPlans(): List<TaskPlan> {
        val db = readableDatabase
        val plans = mutableListOf<TaskPlan>()

        val cursor = db.rawQuery(
            "SELECT * FROM task_plans ORDER BY created_at_ms DESC",
            null
        )
        while (cursor.moveToNext()) {
            val planId = cursor.getString(cursor.getColumnIndexOrThrow("plan_id"))
            val title = cursor.getString(cursor.getColumnIndexOrThrow("title"))
            val rawGoal = cursor.getString(cursor.getColumnIndexOrThrow("raw_goal"))
            val triggerType = TriggerType.valueOf(cursor.getString(cursor.getColumnIndexOrThrow("trigger_type")))
            val triggerTimeMs = cursor.getLong(cursor.getColumnIndexOrThrow("trigger_time_ms"))
            val repeatIntervalMs = cursor.getLong(cursor.getColumnIndexOrThrow("repeat_interval_ms"))
            val triggerCondition = cursor.getString(cursor.getColumnIndexOrThrow("trigger_condition"))
            val status = PlanStatus.valueOf(cursor.getString(cursor.getColumnIndexOrThrow("status")))
            val createdAtMs = cursor.getLong(cursor.getColumnIndexOrThrow("created_at_ms"))

            val steps = getStepsForPlan(planId)

            plans.add(
                TaskPlan(
                    planId = planId,
                    title = title,
                    rawGoal = rawGoal,
                    triggerType = triggerType,
                    triggerTimeMs = triggerTimeMs,
                    repeatIntervalMs = repeatIntervalMs,
                    triggerCondition = triggerCondition,
                    steps = steps.toMutableList(),
                    status = status,
                    createdAtMs = createdAtMs
                )
            )
        }
        cursor.close()
        return plans
    }

    fun getStepsForPlan(planId: String): List<PlanStep> {
        val db = readableDatabase
        val steps = mutableListOf<PlanStep>()
        val cursor = db.rawQuery(
            "SELECT * FROM $TABLE_STEPS WHERE plan_id = ? ORDER BY step_id ASC",
            arrayOf(planId)
        )
        while (cursor.moveToNext()) {
            val stepId = cursor.getInt(cursor.getColumnIndexOrThrow("step_id"))
            val title = cursor.getString(cursor.getColumnIndexOrThrow("title"))
            val actionType = ActionType.valueOf(cursor.getString(cursor.getColumnIndexOrThrow("action_type")))
            val paramsJson = cursor.getString(cursor.getColumnIndexOrThrow("params_json"))
            val condition = cursor.getString(cursor.getColumnIndexOrThrow("condition"))
            val status = StepStatus.valueOf(cursor.getString(cursor.getColumnIndexOrThrow("status")))
            val output = cursor.getString(cursor.getColumnIndexOrThrow("output"))

            val paramsMap = mutableMapOf<String, String>()
            if (!paramsJson.isNullOrEmpty()) {
                val jsonObj = JSONObject(paramsJson)
                val keys = jsonObj.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    paramsMap[k] = jsonObj.optString(k, "")
                }
            }

            val dependsOnList = paramsMap.remove("__DEPENDS_ON__")
                ?.split(",")
                ?.mapNotNull { it.trim().toIntOrNull() }
                ?: emptyList()
            val healingReport = paramsMap.remove("__HEALING_REPORT__")

            steps.add(
                PlanStep(
                    stepId = stepId,
                    title = title,
                    actionType = actionType,
                    params = paramsMap,
                    condition = condition,
                    dependsOnStepIds = dependsOnList,
                    status = status,
                    output = output,
                    healingReport = healingReport
                )
            )
        }
        cursor.close()
        return steps
    }

    fun deletePlan(planId: String) {
        val db = writableDatabase
        db.delete(TABLE_STEPS, "plan_id = ?", arrayOf(planId))
        db.delete(TABLE_PLANS, "plan_id = ?", arrayOf(planId))
    }
}
