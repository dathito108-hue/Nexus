package com.hypernexus.nit.router

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import com.hypernexus.nit.accessibility.NitAccessibilityService
import com.hypernexus.nit.engine.LlamaEngine
import com.hypernexus.nit.engine.LoraHotSwapManager
import com.hypernexus.nit.engine.ModelManager
import com.hypernexus.nit.engine.Procedural3DGenerator
import com.hypernexus.nit.evolution.ContextMemoryManager
import com.hypernexus.nit.finance.FinanceDataManager
import com.hypernexus.nit.finance.SolanaDexDataManager
import com.hypernexus.nit.planner.AutonomousExecutionEngine
import com.hypernexus.nit.planner.CognitiveTaskReasoner
import com.hypernexus.nit.planner.TaskPlanningManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext

/**
 * BỘ PHÂN LOẠI & ĐỊNH TUYẾN TƯ DUY NÂNG CẤP (HYBRID DUAL-SYSTEM ROUTER PRO)
 * • 100% Non-Blocking Reactive Architecture: Triệt tiêu hoàn toàn runBlocking trên luồng UI.
 * • Bóc tách đa ý định (Multi-Intent Decomposition) cho các mệnh đề phức hợp.
 * • Tích hợp LLM Tool Calling JSON cho System 2 (Qwen 1.5B GGUF).
 * • Truyền phát trạng thái tiến trình thời gian thực (StateFlow) cho giao diện 120 FPS.
 */
class SystemRouter(private val context: Context) {

    private val memoryManager = ContextMemoryManager(context)

    val executionState: StateFlow<com.hypernexus.nit.planner.AgentExecutionState>
        get() = AutonomousExecutionEngine.executionState

    init {
        // Tự động nạp mô hình vào GPU Mali-G78 nếu file GGUF đã có sẵn
        if (ModelManager.isModelReady(context)) {
            val modelFile = ModelManager.getModelFile(context)
            LlamaEngine.initModel(modelFile.absolutePath)
        }
    }

    /**
     * GỌI ĐỒNG BỘ ĐẢM BẢO TƯƠNG THÍCH NGƯỢC (BACKWARD COMPATIBLE WRAPPER)
     */
    fun routeCommand(rawInput: String): String = runBlocking(Dispatchers.Default) {
        routeCommandAsync(rawInput)
    }

    /**
     * GỌI BẤT ĐỒNG BỘ PHẢN ỨNG TOÀN DIỆN (FULL NON-BLOCKING SUSPEND FUNCTION)
     * Giữ vững tần số quét 120 FPS của Samsung Galaxy S21 FE.
     */
    suspend fun routeCommandAsync(rawInput: String): String = withContext(Dispatchers.Default) {
        memoryManager.saveInteraction("user", rawInput)

        // 1. KIỂM TRA & BÓC TÁCH ĐA Ý ĐỊNH (MULTI-INTENT DECOMPOSITION)
        val subIntents = HybridSemanticDispatcher.decomposeMultiIntents(rawInput)
        if (subIntents.size > 1) {
            val sb = StringBuilder("📋 [THỰC THI ĐA Ý ĐỊNH PHỐI HỢP (${subIntents.size} TÁC VỤ)]:\n\n")
            for ((idx, sub) in subIntents.withIndex()) {
                val subResult = routeSingleCommandAsync(sub)
                sb.append("[Tác vụ ${idx + 1}]: \"$sub\"\n")
                sb.append("👉 $subResult\n\n")
            }
            val finalCombined = sb.toString().trim()
            memoryManager.saveInteraction("assistant", finalCombined)
            return@withContext finalCombined
        }

        // 2. THỰC THI Ý ĐỊNH ĐƠN LẺ
        val finalReply = routeSingleCommandAsync(rawInput)
        memoryManager.saveInteraction("assistant", finalReply)
        return@withContext finalReply
    }

    /**
     * ĐỊNH TUYẾN 1 Ý ĐỊNH ĐƠN LẺ KHÔNG BLOCKING
     */
    private suspend fun routeSingleCommandAsync(rawInput: String): String {
        val command = rawInput.trim().lowercase()
        var finalReply = ""

        // 0. ĐIỂM TIN BUỔI SÁNG CHỦ ĐỘNG
        if (command.contains("buổi sáng") || command.contains("điểm tin") || command.contains("thời tiết")) {
            val briefing = com.hypernexus.nit.proactive.ProactiveAssistantManager.generateMorningBriefing(context)
            finalReply = "${briefing.greeting} ${briefing.timeString}. ${briefing.solanaStatus} ${briefing.goldStatus} ${briefing.batteryAdvice}"
        }

        // 0.1 ĐIỀU KHIỂN NHÀ THÔNG MINH CỤC BỘ (SMART HOME WI-FI)
        else if (command.contains("đèn") || command.contains("điều hòa") || command.contains("máy lạnh") || command.contains("quạt") || command.contains("hút bụi")) {
            val device = when {
                command.contains("đèn") -> com.hypernexus.nit.smarthome.SmartHomeLocalBridge.DeviceType.LIGHT
                command.contains("điều hòa") || command.contains("máy lạnh") -> com.hypernexus.nit.smarthome.SmartHomeLocalBridge.DeviceType.AIR_CONDITIONER
                command.contains("quạt") -> com.hypernexus.nit.smarthome.SmartHomeLocalBridge.DeviceType.FAN
                else -> com.hypernexus.nit.smarthome.SmartHomeLocalBridge.DeviceType.ROBOT_VACUUM
            }
            val action = if (command.contains("tắt")) "turn_off" else "turn_on"
            finalReply = com.hypernexus.nit.smarthome.SmartHomeLocalBridge.controlDevice(device, action)
        }

        // 0.2 ĐỌC VÀ TÓM TẮT TRANG WEB TỪ LINK (WEB SCRAPING)
        else if (command.contains("http://") || command.contains("https://")) {
            val urlPattern = java.util.regex.Pattern.compile("https?://[\\w\\d:#@%/;$()~_?\\+-=\\\\.&]+")
            val matcher = urlPattern.matcher(rawInput)
            if (matcher.find()) {
                val targetUrl = matcher.group()
                val webContent = com.hypernexus.nit.web.WebArticleScraper.scrapeCleanTextFromUrl(targetUrl)
                val prompt = "<|im_start|>system\nBạn là Nít. Hãy đọc nội dung trang web sau đây và tóm tắt ngắn gọn các ý quan trọng nhất bằng tiếng Việt:\n\n$webContent<|im_end|>\n<|im_start|>user\nTóm tắt trang web này cho tôi.<|im_end|>\n<|im_start|>assistant\n"
                finalReply = LlamaEngine.generateResponse(prompt, maxTokens = 350, temperature = 0.5f)
            } else {
                finalReply = "Không tìm thấy đường link URL hợp lệ trong câu lệnh."
            }
        }

        // 0.3 TÌM KIẾM INTERNET THỜI GIAN THỰC (REAL-TIME WEB-RAG SEARCH)
        else if (command.startsWith("tìm kiếm ") || command.startsWith("tra cứu ") || command.contains("tin tức") || command.contains("trên mạng")) {
            val searchQuery = command.removePrefix("tìm kiếm ").removePrefix("tra cứu ").removePrefix("tin tức ").trim()
            val searchResults = com.hypernexus.nit.web.WebSearchEngine.searchWeb(searchQuery, maxResults = 3)

            if (searchResults.isNotEmpty()) {
                val contextBuilder = StringBuilder()
                searchResults.forEachIndexed { idx, res ->
                    contextBuilder.append("[Nguồn ${idx + 1}]: ${res.snippet}\n")
                }
                val ragPrompt = "<|im_start|>system\nBạn là Nít. Dưới đây là thông tin tìm kiếm thời gian thực từ Internet:\n$contextBuilder\nHãy trả lời câu hỏi của người dùng một cách chính xác, cập nhật dựa trên thông tin trên.<|im_end|>\n<|im_start|>user\n$rawInput<|im_end|>\n<|im_start|>assistant\n"
                finalReply = LlamaEngine.generateResponse(ragPrompt, maxTokens = 300, temperature = 0.6f)
            } else {
                finalReply = "Nít đã tìm kiếm trên mạng nhưng chưa thấy kết quả phù hợp cho: $searchQuery"
            }
        }

        // 0.4 BỘ SUY LUẬN LẬP KẾ HOẠCH & LỊCH TRÌNH TỰ HÀNH (COGNITIVE TASK PLANNER & PARALLEL DAG SCHEDULER)
        else if (command.contains("lập kế hoạch") || command.contains("lên lịch") || command.contains("hẹn giờ") || command.contains("nhắc tôi") || command.contains("kế hoạch") || (command.contains("tự động") && (command.contains("lúc") || command.contains("khi")))) {
            val plan = CognitiveTaskReasoner.reasonAndCreatePlan(rawInput)
            val isScheduleRequest = command.contains("lên lịch") || command.contains("hẹn giờ") || command.contains("nhắc") ||
                    command.contains("sáng") || command.contains("chiều") || command.contains("tối") || command.contains("mai") ||
                    command.contains("phút") || command.contains("giờ") || plan.triggerType != com.hypernexus.nit.planner.TriggerType.IMMEDIATE

            if (isScheduleRequest) {
                TaskPlanningManager.schedulePlan(context, plan)
                val timeFormat = java.text.SimpleDateFormat("HH:mm ngày dd/MM", java.util.Locale.getDefault())
                val triggerDesc = if (plan.triggerTimeMs > 0) timeFormat.format(java.util.Date(plan.triggerTimeMs)) else plan.triggerType.name
                finalReply = "Nít đã lên lịch thành công cho kế hoạch: \"${plan.title}\". Gồm ${plan.steps.size} bước tự hành (Đồ thị DAG), kích hoạt vào $triggerDesc."
            } else {
                val report = AutonomousExecutionEngine.executePlan(context, plan)
                finalReply = "Đã hoàn thành kế hoạch: \"${plan.title}\" gồm ${plan.steps.size} bước. Báo cáo: $report"
            }
        }

        // 1. XƯỞNG THIẾT KẾ 3D THAM SỐ, PHÂN TÍCH SLICER & XUẤT BINARY STL (CAD / CAM PRO & DYNAMIC SYNTHESIS)
        else if (command.contains("dựng 3d") || command.contains("tạo 3d") || command.contains("mô hình 3d") || command.contains("in 3d") || command.contains("slicer") || command.contains("stl") || command.contains("bánh răng") || command.contains("giá đỡ") || command.contains("cờ lê") || command.contains("tản nhiệt") || command.contains("cốc") || command.contains("ly") || command.contains("hộp") || command.contains("vỏ tai nghe") || command.contains("chân đế")) {
            LoraHotSwapManager.hotSwapLora(LoraHotSwapManager.LoraType.GEOMETRY_3D)
            val isCustom3D = com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.isCustom3DPrompt(rawInput)

            val mesh = if (isCustom3D) {
                com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.synthesize3DMeshFromPrompt(rawInput)
            } else {
                val meshType = when {
                    command.contains("bánh răng") || command.contains("gear") -> Procedural3DGenerator.MeshType.SPUR_GEAR
                    command.contains("giá đỡ") || command.contains("chân đế") -> Procedural3DGenerator.MeshType.PHONE_STAND
                    command.contains("cờ lê") || command.contains("mỏ lết") || command.contains("wrench") -> Procedural3DGenerator.MeshType.MECHANICAL_WRENCH
                    command.contains("tản nhiệt") || command.contains("heatsink") -> Procedural3DGenerator.MeshType.HEATSINK
                    command.contains("bình") || command.contains("lọ") || command.contains("vase") -> Procedural3DGenerator.MeshType.PARAMETRIC_VASE
                    command.contains("vệ tinh") || command.contains("satellite") -> Procedural3DGenerator.MeshType.QUANTUM_SATELLITE
                    command.contains("mũ") || command.contains("nón") || command.contains("helmet") -> Procedural3DGenerator.MeshType.CYBER_HELMET
                    command.contains("kiếm") || command.contains("sword") -> Procedural3DGenerator.MeshType.MECHA_SWORD
                    command.contains("phi thuyền") || command.contains("tàu") || command.contains("spaceship") -> Procedural3DGenerator.MeshType.SPACESHIP
                    command.contains("drone") || command.contains("máy bay") -> Procedural3DGenerator.MeshType.NANO_DRONE
                    command.contains("ghế") || command.contains("chair") -> Procedural3DGenerator.MeshType.FURNITURE_CHAIR
                    else -> Procedural3DGenerator.MeshType.CYBER_ROBOT
                }
                Procedural3DGenerator.buildMeshData(meshType)
            }

            val displayName = if (mesh.customTitle.isNotEmpty()) mesh.customTitle else mesh.type.name

            if (command.contains("phân tích") || command.contains("slicer") || command.contains("thể tích") || command.contains("khối lượng") || command.contains("bao lâu") || command.contains("tốn bao nhiêu")) {
                val analysis = Procedural3DGenerator.analyzeMeshFor3DPrinting(mesh)
                finalReply = "Mô hình 3D \"$displayName\" có thể tích ${"%.2f".format(analysis.volumeCm3)} cm³, dùng khoảng ${"%.1f".format(analysis.weightGramsPla)} gram nhựa PLA, thời gian in ước tính ${analysis.estimatedPrintTimeMinutes} phút. Độ kín nước (2-Manifold): ${if (analysis.isWatertight) "Kín nước tuyệt đối (Sẵn sàng in)" else "Cần thêm Support"}."
            } else if (command.contains("xuất") || command.contains("stl") || command.contains("tải file") || command.contains("lưu file")) {
                val file = Procedural3DGenerator.exportToBinaryStlFile(context, mesh, "nit_${System.currentTimeMillis() % 10000}_binary.stl")
                finalReply = "Đã xuất file Binary STL cho \"$displayName\" (${mesh.triangleCount} tam giác, kích thước ${file.length()} bytes) tại: ${file.name}. Chuẩn nhị phân IEEE-754 sẵn sàng nạp máy in 3D công nghiệp."
            } else {
                val file = Procedural3DGenerator.generate3DMesh(context, mesh.type)
                finalReply = "Nít đã dựng xong mô hình 3D độc bản: \"$displayName\" gồm ${mesh.triangleCount} tam giác (chuẩn kín nước 2-Manifold). Sẵn sàng kết xuất đồ họa 120 FPS trên GPU Mali-G78 và nạp máy in 3D."
            }
        }

        // 1.1 XƯỞNG LẬP TRÌNH GAME TRÊN WEB 120 FPS (WEB GAME ENGINE PRO & DYNAMIC SYNTHESIS THEO MÔ TẢ)
        else if (command.contains("game web") || command.contains("game trên web") || command.contains("trò chơi web") ||
                 (command.contains("game") && (command.contains("lập trình") || command.contains("code") || command.contains("tạo") || command.contains("thiết kế") || command.contains("mô tả") || command.contains("độc bản"))) ||
                 command.contains("bắn phi thuyền") || command.contains("phá gạch") || command.contains("rắn săn mồi") || command.contains("mê cung 3d") || command.contains("thủ trụ") ||
                 command.contains("cá lớn") || command.contains("nuốt cá") || command.contains("đua xe") || command.contains("chướng ngại vật") || command.contains("né thiên thạch") || command.contains("sinh tồn")) {
            val isCustom = com.hypernexus.nit.web.DynamicGameSynthesisEngine.isCustomGamePrompt(rawInput)
            val project = if (isCustom) {
                com.hypernexus.nit.web.DynamicGameSynthesisEngine.synthesizeGameFromPrompt(context, rawInput)
            } else {
                val genre = com.hypernexus.nit.web.WebGameDevelopmentEngine.matchGameGenreFromCommand(command)
                com.hypernexus.nit.web.WebGameDevelopmentEngine.generateGameProject(genre)
            }
            val gameVal = com.hypernexus.nit.web.WebGameDevelopmentEngine.validateGameCode(project)
            val exportRes = com.hypernexus.nit.web.WebDevelopmentEngine.exportProjectToDisk(context, project, createZip = true)

            // Khởi động máy chủ cục bộ 127.0.0.1:8088
            com.hypernexus.nit.web.LocalWebSandboxServer.startServer(project)
            val serverUrl = com.hypernexus.nit.web.LocalWebSandboxServer.getServerUrl()

            finalReply = "Nít đã lập trình xong Game Web ${if (isCustom) "ĐỘC BẢN theo mô tả" else ""}: \"${project.title}\" (${gameVal.totalLines} dòng, 120 FPS Delta-Time: ${if (gameVal.hasGameLoopDeltaTime) "BẬT" else "TẮT"}, Web Audio Synth: ${if (gameVal.hasWebAudioSynth) "BẬT" else "TẮT"}, Điểm chất lượng: ${gameVal.qualityScore}/100). Máy chủ Live Game 120Hz đang chạy tại: $serverUrl. Đã đóng gói ZIP tại: ${exportRes.zipFilePath ?: "bộ nhớ máy"}."
        }

        // 1.2 XƯỞNG LẬP TRÌNH WEB PRO (HTML5/CSS3/JS SANDBOX 120 FPS & LOCALHOST:8088)
        else if (command.contains("lập trình web") || command.contains("thiết kế web") || command.contains("code web") || command.contains("tạo trang web") || command.contains("tạo web") || command.contains("máy chủ web") || (command.contains("web") && (command.contains("bán hàng") || command.contains("dashboard") || command.contains("portfolio") || command.contains("landing") || command.contains("sandbox")))) {
            val template = com.hypernexus.nit.web.WebDevelopmentEngine.matchTemplateFromCommand(command)
            val project = com.hypernexus.nit.web.WebDevelopmentEngine.generateProject(template)
            val validation = com.hypernexus.nit.web.WebDevelopmentEngine.validateWebCode(project)
            val exportRes = com.hypernexus.nit.web.WebDevelopmentEngine.exportProjectToDisk(context, project, createZip = true)

            com.hypernexus.nit.web.LocalWebSandboxServer.startServer(project)
            val serverUrl = com.hypernexus.nit.web.LocalWebSandboxServer.getServerUrl()

            finalReply = "Nít đã lập trình xong dự án Web: \"${project.title}\" (${template.category}). Gồm ${project.files.size} tệp (${validation.totalLines} dòng, ${validation.totalBytes} bytes, Chuẩn W3C: ${validation.qualityScore}/100). Máy chủ Live Sandbox 120Hz đang chạy tại: $serverUrl. Đã đóng gói ZIP tại: ${exportRes.zipFilePath ?: "bộ nhớ máy"}."
        }

        // 2. SYSTEM 1: YÊU CẦU MỞ ỨNG DỤNG ("Mở app X", "Bật Zalo", "Vào Youtube")
        else if (command.startsWith("mở ") || command.startsWith("bật ") || command.startsWith("vào ")) {
            LoraHotSwapManager.hotSwapLora(LoraHotSwapManager.LoraType.ANDROID_NAVIGATOR)
            val targetAppName = command.substringAfter(" ").trim()
            val launched = launchAppInstantly(targetAppName)
            finalReply = if (launched) "Đã mở $targetAppName trong 5 mili-giây." else "Không tìm thấy ứng dụng $targetAppName trên máy."
        }

        // 3. SYSTEM 1: TỰ ĐỘNG HÓA BIÊN TẬP VIDEO CAPCUT PRO STUDIO & DYNAMIC SYNTHESIS THEO MÔ TẢ
        else if (command.contains("capcut") || command.contains("chủ đề video") || command.contains("hiệu ứng video") || command.contains("ghép âm thanh") || (command.contains("biên tập video") && !command.contains("youtube")) || (command.contains("edit video") && !command.contains("youtube"))) {
            LoraHotSwapManager.hotSwapLora(LoraHotSwapManager.LoraType.CAPCUT_AUTOMATION)
            val service = NitAccessibilityService.instance
            finalReply = if (service != null) {
                val isCustomCapcut = com.hypernexus.nit.video.DynamicCapCutSynthesisEngine.isCustomCapCutPrompt(rawInput)
                if (isCustomCapcut) {
                    com.hypernexus.nit.video.DynamicCapCutSynthesisEngine.executeFromPrompt(context, rawInput)
                } else {
                    val hasThemeRequest = command.contains("chủ đề") || command.contains("hiệu ứng") || command.contains("âm thanh") ||
                            command.contains("nhạc") || command.contains("cyberpunk") || command.contains("vintage") || command.contains("vlog") ||
                            command.contains("du lịch") || command.contains("gaming") || command.contains("sang trọng")

                    if (hasThemeRequest) {
                        val theme = com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.matchThemeFromCommand(command)
                        val config = com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.buildDefaultConfigForTheme(theme)
                        com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.executeThemeAndAudioProduction(context, config)
                    } else {
                        val preset = com.hypernexus.nit.video.CapCutProAutomationEngine.matchPresetFromCommand(command)
                        com.hypernexus.nit.video.CapCutProAutomationEngine.executeProEditingPreset(context, preset)
                    }
                }
            } else {
                "Vui lòng bật quyền Accessibility Service để Nít có thể kích hoạt chuỗi biên tập CapCut Pro Studio."
            }
        }

        // 3.0 SYSTEM 1: KÝ ỨC MÀN HÌNH NGƯỢC DÒNG THỜI GIAN (SCREEN TIMELINE REWIND)
        else if (command.contains("ký ức") || command.contains("hồi tưởng") || command.contains("rewind") || command.contains("đã xem gì") || command.contains("đã đọc gì") || command.startsWith("tìm lại ") || (command.contains("hôm qua") && (command.contains("xem") || command.contains("đọc")))) {
            val keyword = extractRewindKeyword(command)
            val timelineManager = NitAccessibilityService.instance?.getTimelineManager()
                ?: com.hypernexus.nit.evolution.ScreenTimelineMemoryManager(context)
            val memories = timelineManager.searchTimelineMemory(keyword, limit = 3)
            if (memories.isNotEmpty()) {
                val sb = StringBuilder("⏳ [KÝ ỨC MÀN HÌNH REWIND]:\n")
                memories.forEachIndexed { idx, item ->
                    sb.append("\n[${idx + 1}] Lúc ${item.formattedTime} trên ${item.appLabel}:\n")
                    sb.append("• Trích đoạn: \"${item.textSnippet}\"\n")
                }
                sb.append("\n👉 Nít đã lưu vết an toàn trong SQLite FTS4 cục bộ trên S21 FE.")
                finalReply = sb.toString().trim()
            } else {
                finalReply = "Nít đã quét toàn bộ ký ức màn hình FTS4 nhưng chưa tìm thấy nội dung nào chứa: '$keyword'."
            }
        }

        // 3.1 SYSTEM 1: GAME BOT TACTICAL ASSISTANT
        else if (command.contains("bot game") || command.contains("hỗ trợ game") || command.contains("liên quân") || command.contains("tự động combo")) {
            LoraHotSwapManager.hotSwapLora(LoraHotSwapManager.LoraType.GAMING_TACTICS)
            val service = NitAccessibilityService.instance
            if (service != null) {
                com.hypernexus.nit.accessibility.GameBotManager.startAutoCombatCombo()
                finalReply = "Đã kích hoạt Game Tactical Bot: Tự động combo chiêu 1, chiêu 2, đánh thường và né đòn ngẫu nhiên chống phát hiện."
            } else {
                finalReply = "Vui lòng cấp quyền Accessibility Service để Nít có thể hỗ trợ combo trong game."
            }
        }

        // 3.2 SYSTEM 1: THỊ GIÁC MÀN HÌNH AI COPILOT
        else if (command.contains("đọc màn hình") || command.contains("quét màn hình") || command.contains("soi biểu đồ") || command.contains("soi chart") || command.contains("chuyển khoản") || command.contains("xem chart")) {
            finalReply = "Nít đang bật Screen Vision CoPilot. Hãy mở màn hình biểu đồ TradingView hoặc hóa đơn, Nít sẽ phân tích điểm ảnh RGB hoặc bóc tách chuyển khoản."
        }

        // 3.3 SYSTEM 1: CỬ CHỈ KHÔNG CHẠM
        else if (command.contains("cử chỉ") || command.contains("vẫy tay") || command.contains("không chạm")) {
            finalReply = "Cử chỉ không chạm Camera trước đã sẵn sàng: Vẫy trái/phải để lướt video, vuốt lên/xuống để cuộn trang, giơ lòng bàn tay để tạm dừng."
        }

        // 3.4 SYSTEM 1: KIỂM TOÁN BẢO MẬT TOKEN ON-CHAIN (RUGCHECK SOLANA)
        else if (command.contains("quét token") || command.contains("kiểm toán") || command.contains("rugcheck") || command.contains("an toàn không") || command.contains("check token")) {
            LoraHotSwapManager.hotSwapLora(LoraHotSwapManager.LoraType.FINANCE_EXPERT)
            val tokenQuery = extractTokenQuery(command)
            val auditResult = com.hypernexus.nit.finance.SolanaSafetyAuditor.auditTokenSecurity(tokenQuery)
            finalReply = """
                🛡️ [KIỂM TOÁN BẢO MẬT RUGCHECK]:
                • Token: $tokenQuery | Điểm: ${auditResult.safetyScore}/100
                • Phân loại: ${auditResult.riskLevel}
                • Mint Authority: ${if (auditResult.mintAuthorityRevoked) "✅ Đã từ bỏ quyền in" else "🚨 CÒN BẬT"}
                • Freeze Authority: ${if (auditResult.freezeAuthorityRevoked) "✅ Đã hủy đóng băng" else "🚨 CÒN BẬT"}
                • Đánh giá: ${auditResult.summaryNote}
            """.trimIndent()
        }

        // 3.5 SYSTEM 1: HOÁN ĐỔI TOKEN TỰ ĐỘNG (JUPITER V6 SWAP API)
        else if (command.contains("swap") || command.contains("hoán đổi") || command.contains("đổi sol") || (command.contains("mua ") && (command.contains("sol") || command.contains("usdc") || command.contains("jup")))) {
            LoraHotSwapManager.hotSwapLora(LoraHotSwapManager.LoraType.FINANCE_EXPERT)
            val amountSol = extractSolAmount(command)
            val targetMint = extractTargetMint(command)
            val quote = com.hypernexus.nit.finance.SolanaAutoTrader.getBestSwapQuote(amountSol, targetMint)
            if (quote != null) {
                val (walletPubkey, _) = com.hypernexus.nit.security.SolanaKeypairManager.getOrCreateWallet(context)
                finalReply = """
                    ⚡ [BÁO GIÁ JUPITER V6 ON-CHAIN]:
                    • Đổi: $amountSol SOL -> Token ${targetMint.take(6)}...
                    • Nhận ước tính: ${"%,.2f".format(quote.outAmount)} đơn vị
                    • Sàn: ${quote.routePlan} | Trượt giá: ${"%.2f".format(quote.priceImpactPct)}%
                    • Ví thực thi: ${walletPubkey.take(8)}...
                    👉 Mở màn hình chính và chạm vân tay để hoàn tất ký giao dịch trên blockchain!
                """.trimIndent()
            } else {
                finalReply = "Không thể lấy báo giá Jupiter v6 cho $amountSol SOL. Vui lòng kiểm tra lại thanh khoản."
            }
        }

        // 3.6 SYSTEM 1: PHÂN TÍCH THỊ TRƯỜNG TỔ CHỨC CHUYÊN SÂU (INSTITUTIONAL SMC & QUANT RISK)
        else if (command.contains("phân tích chuyên sâu") || command.contains("báo cáo tổ chức") || command.contains("tổ chức") ||
                command.contains("smart money") || command.contains("smc") || command.contains("order block") || command.contains("fvg") ||
                command.contains("định lượng rủi ro") || command.contains("var 95") || command.contains("kelly")) {
            LoraHotSwapManager.hotSwapLora(LoraHotSwapManager.LoraType.FINANCE_EXPERT)
            val asset = when {
                command.contains("vàng") || command.contains("gold") || command.contains("xau") -> "XAU"
                command.contains("sol") || command.contains("solana") -> "SOL"
                command.contains("eth") || command.contains("ethereum") -> "ETH"
                command.contains("bnb") -> "BNB"
                else -> "BTC"
            }
            val dossier = com.hypernexus.nit.finance.InstitutionalMarketAnalyzer.analyzeInstitutionalMarket(asset)
            finalReply = dossier.formatExecutiveMemo()
        }

        // 4. SYSTEM 1: PHÂN TÍCH SÀN DEX MẠNG SOLANA
        else if (command.contains("solana") || command.contains("sol") || command.contains("dex") || command.contains("raydium") || command.contains("token")) {
            LoraHotSwapManager.hotSwapLora(LoraHotSwapManager.LoraType.FINANCE_EXPERT)
            val tokenQuery = extractTokenQuery(command)
            finalReply = SolanaDexDataManager.analyzeSolanaDexToken(tokenQuery)
        }

        // 5. SYSTEM 1: PHÂN TÍCH THỊ TRƯỜNG VÀNG THẾ GIỚI (XAU/USD)
        else if (command.contains("vàng") || command.contains("gold") || command.contains("xau")) {
            LoraHotSwapManager.hotSwapLora(LoraHotSwapManager.LoraType.FINANCE_EXPERT)
            val dossier = com.hypernexus.nit.finance.InstitutionalMarketAnalyzer.analyzeInstitutionalMarket("XAU")
            finalReply = dossier.formatExecutiveMemo()
        }

        // 6. SYSTEM 1: PHÂN TÍCH BITCOIN LIVE CEX BINANCE & TỔ CHỨC
        else if (command.contains("bitcoin") || command.contains("btc") || command.contains("rsi")) {
            LoraHotSwapManager.hotSwapLora(LoraHotSwapManager.LoraType.FINANCE_EXPERT)
            val dossier = com.hypernexus.nit.finance.InstitutionalMarketAnalyzer.analyzeInstitutionalMarket("BTC")
            finalReply = dossier.formatExecutiveMemo()
        }

        // 7. SYSTEM 2: AGENTIC TOOL CALLING QUA LLM JSON SCHEMA HOẶC SUY LUẬN SÂU
        else {
            // Thử gọi công cụ tự hành thông qua LLM JSON Tool Calling
            val toolCallResult = HybridSemanticDispatcher.executeLlmToolCalling(context, rawInput)
            if (toolCallResult != null) {
                finalReply = toolCallResult
            } else {
                val systemPrompt = "Bạn là Nít, trợ lý AI tự hành tối tân trên Samsung Galaxy S21 FE. Hãy phản hồi ngắn gọn, thông minh và súc tích bằng tiếng Việt."
                val conversationHistory = memoryManager.getRecentSlidingWindowContext()
                val historyBuilder = StringBuilder()
                for ((role, content) in conversationHistory) {
                    historyBuilder.append("<|im_start|>$role\n$content<|im_end|>\n")
                }

                val fullPrompt = "<|im_start|>system\n$systemPrompt<|im_end|>\n${historyBuilder}<|im_start|>user\n$rawInput<|im_end|>\n<|im_start|>assistant\n"
                finalReply = LlamaEngine.generateResponse(fullPrompt, maxTokens = 256, temperature = 0.7f)
            }
        }

        return finalReply
    }

    private fun extractTokenQuery(command: String): String {
        val words = command.split(" ")
        for (i in words.indices) {
            if (words[i] in listOf("token", "đồng", "coin", "cặp", "solana") && i + 1 < words.size) {
                return words[i + 1].uppercase()
            }
        }
        if (command.contains("sol")) return "SOL"
        if (command.contains("ray")) return "RAY"
        if (command.contains("jup")) return "JUP"
        if (command.contains("wif")) return "WIF"
        if (command.contains("bonk")) return "BONK"
        return "SOL"
    }

    private fun extractSolAmount(command: String): Double {
        val pattern = java.util.regex.Pattern.compile("([0-9]+([.,][0-9]+)?)\\s*(sol|đồng|đ)?")
        val matcher = pattern.matcher(command)
        if (matcher.find()) {
            val numStr = matcher.group(1)?.replace(",", ".") ?: "0.1"
            return numStr.toDoubleOrNull() ?: 0.1
        }
        return 0.1
    }

    private fun extractTargetMint(command: String): String {
        return when {
            command.contains("usdc") || command.contains("usd") || command.contains("đô") -> "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
            command.contains("jup") -> "JUPyiwrYJFskUPiHa7hkeR8VUtAeFoSYbKedZNsDvCN"
            command.contains("ray") -> "4k3Dyjzvzp8eMZWUXbBCjEvwSkkk59S5iCNLY3QrkX6R"
            command.contains("bonk") -> "DezXAZ8z7PnrnRJjz3wXBoRgixCa6xjnB7YaB1pPB263"
            command.contains("wif") -> "EKpQGSJtjMFqKZ9KQanSqYXRcF8fBopzLHYxdM65zcjm"
            else -> "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v"
        }
    }

    private fun extractRewindKeyword(command: String): String {
        val clean = command
            .replace("tìm lại", "")
            .replace("ký ức", "")
            .replace("hồi tưởng", "")
            .replace("rewind", "")
            .replace("hôm qua tôi đã xem gì về", "")
            .replace("hôm qua tôi đọc gì về", "")
            .replace("hôm nay tôi đã xem gì về", "")
            .replace("đã xem gì về", "")
            .replace("đã đọc gì về", "")
            .replace("cho tôi biết", "")
            .replace("nít ơi", "")
            .trim()
        return if (clean.isNotBlank()) clean else "tin tức"
    }

    private fun launchAppInstantly(targetName: String): Boolean {
        val pm = context.packageManager
        val packages = pm.getInstalledApplications(PackageManager.GET_META_DATA)

        var bestMatchPkg: String? = null
        var lowestDistance = Int.MAX_VALUE

        for (app in packages) {
            if ((app.flags and ApplicationInfo.FLAG_SYSTEM) != 0 && pm.getLaunchIntentForPackage(app.packageName) == null) {
                continue
            }
            val appLabel = pm.getApplicationLabel(app).toString().lowercase()

            if (appLabel == targetName || appLabel.contains(targetName)) {
                bestMatchPkg = app.packageName
                break
            }

            val dist = LlamaEngine.fuzzyScore(targetName, appLabel)
            if (dist < lowestDistance && dist <= 3) {
                lowestDistance = dist
                bestMatchPkg = app.packageName
            }
        }

        return if (bestMatchPkg != null) {
            val launchIntent = pm.getLaunchIntentForPackage(bestMatchPkg)
            if (launchIntent != null) {
                launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(launchIntent)
                true
            } else false
        } else false
    }
}
