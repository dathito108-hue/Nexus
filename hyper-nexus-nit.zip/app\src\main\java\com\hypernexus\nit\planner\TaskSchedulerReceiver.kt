package com.hypernexus.nit.planner

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/**
 * BỘ THU PHÁT HẸN GIỜ ĐÁNH THỨC NÍT THỰC THI KẾ HOẠCH (TASK SCHEDULER RECEIVER)
 * Bắt tín hiệu AlarmManager đánh thức máy chính xác từng giây ngay cả trong Doze Mode.
 */
class TaskSchedulerReceiver : BroadcastReceiver() {

    companion object {
        const val ACTION_EXECUTE_PLAN = "com.hypernexus.nit.ACTION_EXECUTE_PLAN"
        const val EXTRA_PLAN_ID = "EXTRA_PLAN_ID"
        private const val TAG = "TaskSchedulerReceiver"
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == ACTION_EXECUTE_PLAN) {
            val planId = intent.getStringExtra(EXTRA_PLAN_ID) ?: return
            Log.d(TAG, "Đã nhận tín hiệu AlarmManager kích hoạt kế hoạch: $planId")

            val dbHelper = PlanDatabaseHelper(context)
            val plans = dbHelper.getAllActivePlans()
            val targetPlan = plans.find { it.planId == planId }

            if (targetPlan != null) {
                CoroutineScope(Dispatchers.IO).launch {
                    AutonomousExecutionEngine.executePlan(context, targetPlan)
                }
            }
        }
    }
}
