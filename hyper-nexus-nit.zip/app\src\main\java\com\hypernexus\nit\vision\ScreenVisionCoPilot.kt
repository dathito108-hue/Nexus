package com.hypernexus.nit.vision

import android.graphics.Bitmap
import android.graphics.Color
import android.util.Log
import java.util.regex.Pattern

object ScreenVisionCoPilot {

    private const val TAG = "ScreenVisionCoPilot"

    data class BankTransferInfo(
        val bankName: String,
        val accountNumber: String,
        val amount: Double?,
        val recipientName: String?
    )

    data class ChartVisionAnalysis(
        val bullishRatio: Float,
        val bearishRatio: Float,
        val trendDirection: String,
        val sampledPixels: Int
    )

    /**
     * PHÂN TÍCH THỊ GIÁC MÀN HÌNH: TỰ ĐỘNG BÓC TÁCH THÔNG TIN CHUYỂN KHOẢN NGÂN HÀNG THẬT (OCR)
     */
    fun parseBankTransferFromText(screenOcrText: String): BankTransferInfo? {
        val text = screenOcrText.lowercase()

        val banks = listOf("vietcombank", "techcombank", "mbbank", "acb", "vpbanks", "bidv", "vietinbank", "tpbank")
        val detectedBank = banks.firstOrNull { text.contains(it) }?.uppercase() ?: "NGÂN HÀNG NỘI ĐỊA"

        val accountPattern = Pattern.compile("\\b[0-9]{8,16}\\b")
        val accountMatcher = accountPattern.matcher(screenOcrText)
        val detectedAccount = if (accountMatcher.find()) accountMatcher.group() else null

        val amountPattern = Pattern.compile("([0-9]{1,3}([.,][0-9]{3})+)\\s*(đ|vnd|đồng)?", Pattern.CASE_INSENSITIVE)
        val amountMatcher = amountPattern.matcher(screenOcrText)
        val detectedAmount = if (amountMatcher.find()) {
            val cleanStr = amountMatcher.group(1)?.replace(".", "")?.replace(",", "") ?: "0"
            cleanStr.toDoubleOrNull()
        } else null

        if (detectedAccount != null) {
            Log.d(TAG, "Đã phát hiện thông tin chuyển khoản: Ngân hàng $detectedBank - STK $detectedAccount - Số tiền: $detectedAmount")
            return BankTransferInfo(
                bankName = detectedBank,
                accountNumber = detectedAccount,
                amount = detectedAmount,
                recipientName = null
            )
        }
        return null
    }

    /**
     * PHÂN TÍCH THỊ GIÁC MÀN HÌNH THẬT 100%: QUÉT ĐIỂM ẢNH PIXEL TRÊN BITMAP ĐỂ ĐO TỶ LỆ NẾN XANH/ĐỎ
     */
    fun analyzeTradingViewChart(screenBitmap: Bitmap?): ChartVisionAnalysis {
        if (screenBitmap == null) {
            return ChartVisionAnalysis(0.5f, 0.5f, "Không có khung hình", 0)
        }

        var greenCount = 0
        var redCount = 0
        var totalSampled = 0

        val width = screenBitmap.width
        val height = screenBitmap.height
        val stepX = (width / 50).coerceAtLeast(1)
        val stepY = (height / 50).coerceAtLeast(1)

        // Quét mẫu các điểm ảnh trên màn hình thực tế
        for (y in 0 until height step stepY) {
            for (x in 0 until width step stepX) {
                val pixel = screenBitmap.getPixel(x, y)
                val r = Color.red(pixel)
                val g = Color.green(pixel)
                val b = Color.blue(pixel)

                // Nhận diện pixel màu xanh lá cây của nến tăng (Bullish Candle)
                if (g > 140 && g > r * 1.3f && g > b * 1.2f) {
                    greenCount++
                }
                // Nhận diện pixel màu đỏ của nến giảm (Bearish Candle)
                else if (r > 140 && r > g * 1.3f && r > b * 1.2f) {
                    redCount++
                }
                totalSampled++
            }
        }

        val totalCandlePixels = (greenCount + redCount).coerceAtLeast(1)
        val bullishRatio = greenCount.toFloat() / totalCandlePixels
        val bearishRatio = redCount.toFloat() / totalCandlePixels

        val trend = when {
            bullishRatio > 0.60f -> "Áp đảo Tăng (Phe Mua kiểm soát ${"%.1f".format(bullishRatio * 100)}% biểu đồ)"
            bearishRatio > 0.60f -> "Áp đảo Giảm (Phe Bán kiểm soát ${"%.1f".format(bearishRatio * 100)}% biểu đồ)"
            else -> "Thị trường Cân bằng / Đi ngang (Sideway)"
        }

        Log.d(TAG, "Quét thị giác điểm ảnh thật: Xanh=$greenCount, Đỏ=$redCount, Xu hướng: $trend")

        return ChartVisionAnalysis(
            bullishRatio = bullishRatio,
            bearishRatio = bearishRatio,
            trendDirection = trend,
            sampledPixels = totalSampled
        )
    }
}
