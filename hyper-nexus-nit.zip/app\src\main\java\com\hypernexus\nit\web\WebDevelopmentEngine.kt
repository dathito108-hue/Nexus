package com.hypernexus.nit.web

import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * XƯỞNG LẬP TRÌNH & PHÁT TRIỂN WEB TỰ HÀNH CHUYÊN NGHIỆP (AUTONOMOUS WEB ENGINEERING ENGINE)
 * Thiết kế kiến trúc, sinh mã nguồn đa file (HTML5, Modern CSS3, JavaScript ES2024, SVG/Canvas 120 FPS),
 * kiểm định cú pháp W3C/Responsive và đóng gói xuất bản cho Samsung Galaxy S21 FE 5G.
 */
object WebDevelopmentEngine {

    private const val TAG = "WebDevelopmentEngine"

    enum class WebProjectTemplate(val code: String, val displayName: String, val category: String) {
        LANDING_PAGE_SAAS(
            "LANDING_PAGE_SAAS",
            "Trang Đích AI / SaaS Hiện Đại",
            "Marketing & Conversion"
        ),
        ANALYTICS_DASHBOARD(
            "ANALYTICS_DASHBOARD",
            "Bảng Điều Khiển Số Liệu Real-time",
            "Fintech & Analytics"
        ),
        E_COMMERCE_STORE(
            "E_COMMERCE_STORE",
            "Cửa Hàng Trực Tuyến Cyber Store",
            "E-Commerce & Retail"
        ),
        PORTFOLIO_CREATIVE(
            "PORTFOLIO_CREATIVE",
            "Hồ Sơ Năng Lực Kỹ Sư Công Nghệ",
            "Personal Branding"
        ),
        WEBGL_3D_EXPERIENCE(
            "WEBGL_3D_EXPERIENCE",
            "Trải Nghiệm 3D Canvas Tương Tác 120 FPS",
            "3D Graphics & Canvas"
        ),
        RETRO_WEB_GAME(
            "RETRO_WEB_GAME",
            "Trò Chơi Điện Tử Cyber Runner Canvas",
            "HTML5 Gaming"
        )
    }

    data class WebFile(
        val fileName: String,
        val content: String,
        val mimeType: String
    )

    data class WebProject(
        val projectId: String = UUID.randomUUID().toString(),
        val name: String,
        val title: String,
        val template: WebProjectTemplate,
        val files: Map<String, WebFile>,
        val createdAt: Long = System.currentTimeMillis()
    )

    data class WebValidationResult(
        val isValid: Boolean,
        val errors: List<String>,
        val warnings: List<String>,
        val totalLines: Int,
        val totalBytes: Long,
        val qualityScore: Int
    )

    data class WebExportResult(
        val success: Boolean,
        val projectDir: String,
        val zipFilePath: String?,
        val totalFiles: Int,
        val totalBytes: Long,
        val message: String
    )

    /**
     * TỰ ĐỘNG KHỚP TEMPLATE DỰ ÁN TỪ CÂU LỆNH TIẾNG VIỆT
     */
    fun matchTemplateFromCommand(command: String): WebProjectTemplate {
        val lower = command.lowercase().trim()
        return when {
            lower.contains("dashboard") || lower.contains("thống kê") || lower.contains("biểu đồ") || lower.contains("chỉ số") || lower.contains("analytics") -> {
                WebProjectTemplate.ANALYTICS_DASHBOARD
            }
            lower.contains("bán hàng") || lower.contains("cửa hàng") || lower.contains("shop") || lower.contains("giỏ hàng") || lower.contains("e-commerce") -> {
                WebProjectTemplate.E_COMMERCE_STORE
            }
            lower.contains("portfolio") || lower.contains("hồ sơ") || lower.contains("cv") || lower.contains("cá nhân") || lower.contains("giới thiệu") -> {
                WebProjectTemplate.PORTFOLIO_CREATIVE
            }
            lower.contains("3d") || lower.contains("webgl") || lower.contains("canvas 3d") || lower.contains("three") -> {
                WebProjectTemplate.WEBGL_3D_EXPERIENCE
            }
            lower.contains("game") || lower.contains("trò chơi") || lower.contains("runner") || lower.contains("bắn súng") || lower.contains("flappy") -> {
                WebProjectTemplate.RETRO_WEB_GAME
            }
            else -> WebProjectTemplate.LANDING_PAGE_SAAS
        }
    }

    /**
     * SINH MÃ NGUỒN DỰ ÁN WEB HOÀN CHỈNH ĐA TỆP
     */
    fun generateProject(
        template: WebProjectTemplate,
        customTitle: String? = null,
        extraParams: Map<String, String> = emptyMap()
    ): WebProject {
        val projectName = customTitle?.replace(Regex("[^a-zA-Z0-9_]"), "_")?.lowercase()
            ?: "nit_web_${template.code.lowercase()}"
        val displayTitle = customTitle ?: template.displayName

        val files = mutableMapOf<String, WebFile>()

        when (template) {
            WebProjectTemplate.LANDING_PAGE_SAAS -> {
                files["index.html"] = WebFile("index.html", buildSaasLandingHtml(displayTitle), "text/html")
                files["style.css"] = WebFile("style.css", buildSaasLandingCss(), "text/css")
                files["app.js"] = WebFile("app.js", buildSaasLandingJs(), "application/javascript")
                files["manifest.json"] = WebFile("manifest.json", buildWebManifest(displayTitle, template), "application/json")
            }
            WebProjectTemplate.ANALYTICS_DASHBOARD -> {
                files["index.html"] = WebFile("index.html", buildDashboardHtml(displayTitle), "text/html")
                files["style.css"] = WebFile("style.css", buildDashboardCss(), "text/css")
                files["app.js"] = WebFile("app.js", buildDashboardJs(), "application/javascript")
                files["manifest.json"] = WebFile("manifest.json", buildWebManifest(displayTitle, template), "application/json")
            }
            WebProjectTemplate.E_COMMERCE_STORE -> {
                files["index.html"] = WebFile("index.html", buildEcommerceHtml(displayTitle), "text/html")
                files["style.css"] = WebFile("style.css", buildEcommerceCss(), "text/css")
                files["app.js"] = WebFile("app.js", buildEcommerceJs(), "application/javascript")
                files["manifest.json"] = WebFile("manifest.json", buildWebManifest(displayTitle, template), "application/json")
            }
            WebProjectTemplate.PORTFOLIO_CREATIVE -> {
                files["index.html"] = WebFile("index.html", buildPortfolioHtml(displayTitle), "text/html")
                files["style.css"] = WebFile("style.css", buildPortfolioCss(), "text/css")
                files["app.js"] = WebFile("app.js", buildPortfolioJs(), "application/javascript")
                files["manifest.json"] = WebFile("manifest.json", buildWebManifest(displayTitle, template), "application/json")
            }
            WebProjectTemplate.WEBGL_3D_EXPERIENCE -> {
                files["index.html"] = WebFile("index.html", build3DExperienceHtml(displayTitle), "text/html")
                files["style.css"] = WebFile("style.css", build3DExperienceCss(), "text/css")
                files["app.js"] = WebFile("app.js", build3DExperienceJs(), "application/javascript")
                files["manifest.json"] = WebFile("manifest.json", buildWebManifest(displayTitle, template), "application/json")
            }
            WebProjectTemplate.RETRO_WEB_GAME -> {
                files["index.html"] = WebFile("index.html", buildRetroGameHtml(displayTitle), "text/html")
                files["style.css"] = WebFile("style.css", buildRetroGameCss(), "text/css")
                files["app.js"] = WebFile("app.js", buildRetroGameJs(), "application/javascript")
                files["manifest.json"] = WebFile("manifest.json", buildWebManifest(displayTitle, template), "application/json")
            }
        }

        return WebProject(
            name = projectName,
            title = displayTitle,
            template = template,
            files = files
        )
    }

    /**
     * BỘ KIỂM ĐỊNH MÃ NGUỒN W3C & RESPONSIVE LINTING ON-DEVICE
     */
    fun validateWebCode(project: WebProject): WebValidationResult {
        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()
        var totalLines = 0
        var totalBytes = 0L

        project.files.values.forEach { file ->
            val lines = file.content.lines()
            totalLines += lines.size
            totalBytes += file.content.toByteArray().size

            when (file.fileName) {
                "index.html" -> {
                    if (!file.content.contains("<!DOCTYPE html>", ignoreCase = true)) {
                        errors.add("Thiếu khai báo chuẩn <!DOCTYPE html> trong index.html")
                    }
                    if (!file.content.contains("<meta name=\"viewport\"", ignoreCase = true)) {
                        errors.add("Thiếu thẻ viewport chuẩn di động: <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">")
                    }
                    if (!file.content.contains("<title>", ignoreCase = true)) {
                        warnings.add("Nên có thẻ <title> để tối ưu SEO & Tab title")
                    }
                    if (!file.content.contains("style.css")) {
                        warnings.add("Chưa liên kết style.css trong thẻ <head>")
                    }
                    if (!file.content.contains("app.js")) {
                        warnings.add("Chưa nạp script app.js")
                    }
                }
                "style.css" -> {
                    if (!file.content.contains(":root")) {
                        warnings.add("Nên định nghĩa biến màu sắc CSS Custom Properties (:root) để hỗ trợ Theme")
                    }
                    if (!file.content.contains("@media")) {
                        warnings.add("Chưa có Media Queries responsive cho màn hình điện thoại & máy tính bảng")
                    }
                }
                "app.js" -> {
                    if (file.content.contains("eval(")) {
                        errors.add("Phát hiện hàm nguy hiểm eval() trong mã nguồn JavaScript!")
                    }
                    if (!file.content.contains("addEventListener")) {
                        warnings.add("Nên dùng chuẩn addEventListener thay vì gán thuộc tính DOM inline")
                    }
                }
            }
        }

        var score = 100
        score -= errors.size * 25
        score -= warnings.size * 5
        if (score < 0) score = 0

        return WebValidationResult(
            isValid = errors.isEmpty(),
            errors = errors,
            warnings = warnings,
            totalLines = totalLines,
            totalBytes = totalBytes,
            qualityScore = score
        )
    }

    /**
     * XUẤT MÃ NGUỒN RA BỘ NHỚ CỤC BỘ & ĐÓNG GÓI TỆP ZIP
     */
    fun exportProjectToDisk(context: Context, project: WebProject, createZip: Boolean = true): WebExportResult {
        return try {
            val baseDir = File(context.filesDir, "web_projects/${project.name}")
            if (!baseDir.exists()) baseDir.mkdirs()

            var totalBytes = 0L
            project.files.values.forEach { webFile ->
                val targetFile = File(baseDir, webFile.fileName)
                targetFile.writeText(webFile.content, Charsets.UTF_8)
                totalBytes += targetFile.length()
            }

            var zipPath: String? = null
            if (createZip) {
                val zipFile = File(context.filesDir, "web_projects/${project.name}.zip")
                ZipOutputStream(FileOutputStream(zipFile)).use { zos ->
                    project.files.values.forEach { webFile ->
                        val entry = ZipEntry(webFile.fileName)
                        zos.putNextEntry(entry)
                        val bytes = webFile.content.toByteArray(Charsets.UTF_8)
                        zos.write(bytes, 0, bytes.size)
                        zos.closeEntry()
                    }
                }
                zipPath = zipFile.absolutePath
            }

            WebExportResult(
                success = true,
                projectDir = baseDir.absolutePath,
                zipFilePath = zipPath,
                totalFiles = project.files.size,
                totalBytes = totalBytes,
                message = "Đã xuất thành công ${project.files.size} tệp tại: ${baseDir.name}" + (if (zipPath != null) " kèm file nén ZIP" else "")
            )
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi xuất bản dự án web: ${e.message}", e)
            WebExportResult(
                success = false,
                projectDir = "",
                zipFilePath = null,
                totalFiles = 0,
                totalBytes = 0L,
                message = "Lỗi ghi tệp dự án: ${e.message}"
            )
        }
    }

    // =========================================================================
    // TEMPLATE 1: SAAS / AI LANDING PAGE (HTML / CSS / JS)
    // =========================================================================
    private fun buildSaasLandingHtml(title: String): String = """
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>$title</title>
    <link rel="stylesheet" href="style.css">
</head>
<body data-theme="dark">
    <!-- NAVIGATION BAR -->
    <header class="navbar">
        <div class="nav-container">
            <a href="#" class="brand-logo">
                <span class="logo-icon">⚡</span>
                <span class="logo-text">NÍT <span class="highlight">STUDIO</span></span>
            </a>
            <nav class="nav-links">
                <a href="#features">Tính Năng</a>
                <a href="#demo">Live Demo</a>
                <a href="#pricing">Bảng Giá</a>
                <button type="button" id="theme-toggle" class="btn-icon" aria-label="Đổi giao diện">🌓</button>
                <a href="#cta" class="btn-primary">Bắt Đầu Ngay</a>
            </nav>
        </div>
    </header>

    <!-- HERO SECTION -->
    <main>
        <section class="hero-section">
            <div class="hero-content">
                <div class="badge-pill">🚀 NỀN TẢNG AI CẠNH THẾ HỆ MỚI</div>
                <h1 class="hero-title">Kiến Tạo Ứng Dụng Web Tương Lai Với <span class="gradient-text">Hyper Nexus AI</span></h1>
                <p class="hero-desc">Tự động sinh mã nguồn, tối ưu hóa 120 FPS trên màn hình Galaxy S21 FE và phân tích dữ liệu thời gian thực không độ trễ.</p>
                <div class="hero-actions">
                    <button type="button" class="btn-primary-large" id="btn-hero-cta">Trải Nghiệm Miễn Phí</button>
                    <button type="button" class="btn-secondary-large" id="btn-watch-demo">▶ Xem Video Demo</button>
                </div>
                <div class="hero-stats">
                    <div class="stat-item"><span class="stat-num">120 FPS</span><span class="stat-label">Hiệu Năng GPU</span></div>
                    <div class="stat-item"><span class="stat-num">&lt; 1.5 MB</span><span class="stat-label">Dung Lượng Nhẹ</span></div>
                    <div class="stat-item"><span class="stat-num">100%</span><span class="stat-label">On-Device Riêng Tư</span></div>
                </div>
            </div>
        </section>

        <!-- FEATURES GRID -->
        <section id="features" class="features-section">
            <h2 class="section-title">Năng Lực Đột Phá</h2>
            <div class="features-grid">
                <article class="feature-card">
                    <div class="card-icon">🧠</div>
                    <h3>Tự Động Hóa Nhận Thức</h3>
                    <p>Phân rã mục tiêu tự nhiên thành đồ thị hành động DAG, xử lý chuẩn xác không qua trung gian.</p>
                </article>
                <article class="feature-card">
                    <div class="card-icon">⚡</div>
                    <h3>Mali-G78 120Hz</h3>
                    <p>Tăng tốc phần cứng Vulkan & WebGL mượt mà, loại bỏ triệt để hiện tượng giật khung hình.</p>
                </article>
                <article class="feature-card">
                    <div class="card-icon">🛡️</div>
                    <h3>Bảo Mật Knox 100%</h3>
                    <p>Mã hóa dữ liệu tại chỗ, sinh trắc học vân tay an toàn bảo vệ mọi giao dịch nhạy cảm.</p>
                </article>
            </div>
        </section>

        <!-- PRICING TIERS -->
        <section id="pricing" class="pricing-section">
            <h2 class="section-title">Bảng Giá Linh Hoạt</h2>
            <div class="pricing-toggle">
                <span>Hàng Tháng</span>
                <input type="checkbox" id="pricing-switch" class="switch-checkbox">
                <label for="pricing-switch" class="switch-label"></label>
                <span>Hàng Năm <span class="discount-badge">-20%</span></span>
            </div>
            <div class="pricing-grid">
                <div class="pricing-card">
                    <h3>Khởi Nghiệp</h3>
                    <div class="price-val"><span class="currency">$</span><span class="amount" id="starter-price">0</span><span class="period">/tháng</span></div>
                    <ul class="features-list">
                        <li>✔ 10 Dự án Web tự động</li>
                        <li>✔ Live Sandbox 120Hz</li>
                        <li>✔ Xuất file nén ZIP</li>
                    </ul>
                    <button type="button" class="btn-card">Đăng Ký Miễn Phí</button>
                </div>
                <div class="pricing-card featured">
                    <div class="popular-badge">PHỔ BIẾN NHẤT</div>
                    <h3>Chuyên Nghiệp Pro</h3>
                    <div class="price-val"><span class="currency">$</span><span class="amount" id="pro-price">29</span><span class="period">/tháng</span></div>
                    <ul class="features-list">
                        <li>✔ Không giới hạn dự án Web</li>
                        <li>✔ WebGL 3D & Slicer CAD</li>
                        <li>✔ Máy chủ cục bộ Localhost:8088</li>
                        <li>✔ Tích hợp Smart Money SMC</li>
                    </ul>
                    <button type="button" class="btn-card btn-card-primary">Nâng Cấp Ngay</button>
                </div>
            </div>
        </section>
    </main>

    <footer class="footer">
        <p>© 2026 Hyper Nexus Nít. Thiết kế tự hành bởi Nít Autonomous Web Engine.</p>
    </footer>
    <script src="app.js"></script>
</body>
</html>
    """.trimIndent()

    private fun buildSaasLandingCss(): String = """
:root {
    --bg-primary: #090C12;
    --bg-card: rgba(18, 24, 38, 0.7);
    --border-color: rgba(0, 229, 255, 0.15);
    --text-primary: #F8FAFC;
    --text-muted: #94A3B8;
    --accent-cyan: #00E5FF;
    --accent-green: #14F195;
    --gradient-hero: linear-gradient(135deg, #00E5FF 0%, #14F195 100%);
    --font-stack: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
}
[data-theme="light"] {
    --bg-primary: #F8FAFC;
    --bg-card: rgba(255, 255, 255, 0.9);
    --border-color: rgba(0, 0, 0, 0.1);
    --text-primary: #0F172A;
    --text-muted: #64748B;
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body {
    background: var(--bg-primary);
    color: var(--text-primary);
    font-family: var(--font-stack);
    line-height: 1.6;
    overflow-x: hidden;
    scroll-behavior: smooth;
}
.navbar {
    position: sticky; top: 0; z-index: 100;
    backdrop-filter: blur(16px);
    background: rgba(9, 12, 18, 0.8);
    border-bottom: 1px solid var(--border-color);
    padding: 1rem 2rem;
}
.nav-container {
    max-width: 1200px; margin: 0 auto;
    display: flex; justify-content: space-between; align-items: center;
}
.brand-logo { text-decoration: none; font-size: 1.3rem; font-weight: 800; color: #FFF; display: flex; align-items: center; gap: 8px; }
.highlight { color: var(--accent-cyan); }
.nav-links { display: flex; align-items: center; gap: 1.5rem; }
.nav-links a { color: var(--text-muted); text-decoration: none; font-size: 0.95rem; font-weight: 500; transition: color 0.2s; }
.nav-links a:hover { color: var(--accent-cyan); }
.btn-icon { background: none; border: 1px solid var(--border-color); color: var(--text-primary); padding: 6px 10px; border-radius: 8px; cursor: pointer; font-size: 1rem; }
.btn-primary {
    background: var(--gradient-hero); color: #000; padding: 8px 18px;
    border-radius: 8px; font-weight: 700; text-decoration: none; border: none; cursor: pointer;
}
.hero-section {
    padding: 5rem 2rem; text-align: center; max-width: 900px; margin: 0 auto;
}
.badge-pill {
    display: inline-block; padding: 6px 14px; border-radius: 20px;
    background: rgba(0, 229, 255, 0.1); border: 1px solid var(--accent-cyan);
    color: var(--accent-cyan); font-size: 0.8rem; font-weight: 700; margin-bottom: 1.5rem;
}
.hero-title { font-size: 3rem; font-weight: 900; line-height: 1.2; margin-bottom: 1.5rem; }
.gradient-text { background: var(--gradient-hero); -webkit-background-clip: text; -webkit-text-fill-color: transparent; }
.hero-desc { font-size: 1.15rem; color: var(--text-muted); margin-bottom: 2.5rem; max-width: 700px; margin-inline: auto; }
.hero-actions { display: flex; justify-content: center; gap: 1rem; margin-bottom: 3rem; }
.btn-primary-large {
    background: var(--gradient-hero); color: #000; border: none; padding: 14px 28px;
    border-radius: 10px; font-size: 1.05rem; font-weight: 800; cursor: pointer; transition: transform 0.2s;
}
.btn-primary-large:hover { transform: scale(1.04); }
.btn-secondary-large {
    background: transparent; border: 1px solid var(--border-color); color: var(--text-primary);
    padding: 14px 28px; border-radius: 10px; font-size: 1.05rem; font-weight: 600; cursor: pointer;
}
.hero-stats {
    display: flex; justify-content: space-around; border-top: 1px solid var(--border-color);
    padding-top: 2rem; margin-top: 2rem;
}
.stat-num { display: block; font-size: 1.8rem; font-weight: 800; color: var(--accent-cyan); }
.stat-label { font-size: 0.85rem; color: var(--text-muted); }
.features-section, .pricing-section { max-width: 1100px; margin: 0 auto; padding: 4rem 2rem; }
.section-title { text-align: center; font-size: 2.2rem; font-weight: 800; margin-bottom: 2.5rem; }
.features-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem; }
.feature-card {
    background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 14px;
    padding: 2rem; backdrop-filter: blur(10px); transition: transform 0.2s;
}
.feature-card:hover { transform: translateY(-4px); }
.card-icon { font-size: 2.2rem; margin-bottom: 1rem; }
.pricing-toggle { display: flex; align-items: center; justify-content: center; gap: 12px; margin-bottom: 2.5rem; }
.switch-label { width: 44px; height: 24px; background: #334155; border-radius: 20px; position: relative; cursor: pointer; display: inline-block; }
.switch-label::after { content: ''; position: absolute; width: 18px; height: 18px; background: #FFF; border-radius: 50%; top: 3px; left: 3px; transition: 0.2s; }
.switch-checkbox { display: none; }
.switch-checkbox:checked + .switch-label { background: var(--accent-cyan); }
.switch-checkbox:checked + .switch-label::after { transform: translateX(20px); }
.discount-badge { background: var(--accent-green); color: #000; font-size: 0.75rem; font-weight: 800; padding: 2px 6px; border-radius: 6px; }
.pricing-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 2rem; max-width: 800px; margin: 0 auto; }
.pricing-card {
    background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 16px;
    padding: 2.5rem 2rem; text-align: center; position: relative;
}
.pricing-card.featured { border-color: var(--accent-cyan); box-shadow: 0 0 24px rgba(0, 229, 255, 0.15); }
.popular-badge {
    position: absolute; top: -12px; left: 50%; transform: translateX(-50%);
    background: var(--accent-cyan); color: #000; font-size: 0.75rem; font-weight: 800;
    padding: 4px 12px; border-radius: 20px;
}
.price-val { margin: 1.5rem 0; font-size: 2.5rem; font-weight: 900; }
.price-val .currency { font-size: 1.5rem; }
.price-val .period { font-size: 1rem; color: var(--text-muted); font-weight: 400; }
.features-list { list-style: none; text-align: left; margin: 1.5rem 0; font-size: 0.95rem; }
.features-list li { margin-bottom: 0.8rem; color: var(--text-muted); }
.btn-card {
    width: 100%; padding: 12px; border-radius: 8px; font-weight: 700;
    background: transparent; border: 1px solid var(--border-color); color: var(--text-primary); cursor: pointer;
}
.btn-card-primary { background: var(--gradient-hero); color: #000; border: none; }
.footer { border-top: 1px solid var(--border-color); padding: 2rem; text-align: center; color: var(--text-muted); font-size: 0.9rem; }
@media (max-width: 768px) {
    .hero-title { font-size: 2.2rem; }
    .nav-links { display: none; }
    .hero-actions { flex-direction: column; }
}
    """.trimIndent()

    private fun buildSaasLandingJs(): String = """
document.addEventListener('DOMContentLoaded', () => {
    // 1. Chuyển đổi Theme Dark / Light
    const themeBtn = document.getElementById('theme-toggle');
    themeBtn?.addEventListener('click', () => {
        const currentTheme = document.body.getAttribute('data-theme');
        const nextTheme = currentTheme === 'dark' ? 'light' : 'dark';
        document.body.setAttribute('data-theme', nextTheme);
        themeBtn.textContent = nextTheme === 'dark' ? '🌓' : '☀️';
    });

    // 2. Chuyển đổi giá tháng / năm linh hoạt
    const pricingSwitch = document.getElementById('pricing-switch');
    const starterPrice = document.getElementById('starter-price');
    const proPrice = document.getElementById('pro-price');

    pricingSwitch?.addEventListener('change', (e) => {
        if (e.target.checked) {
            // Hàng năm (Giảm 20%)
            if (starterPrice) starterPrice.textContent = '0';
            if (proPrice) proPrice.textContent = '23';
        } else {
            // Hàng tháng
            if (starterPrice) starterPrice.textContent = '0';
            if (proPrice) proPrice.textContent = '29';
        }
    });

    // 3. Nút CTA trải nghiệm
    document.getElementById('btn-hero-cta')?.addEventListener('click', () => {
        alert('Chào mừng bạn đến với Hyper Nexus Web Studio! Dự án đang chạy trơn tru trên thiết bị của bạn.');
    });

    console.log('🚀 [HYPER-NEXUS]: Landing Page đã khởi động hoàn tất trên WebView 120 FPS.');
});
    """.trimIndent()

    // =========================================================================
    // TEMPLATE 2: ANALYTICS REAL-TIME DASHBOARD (HTML / CSS / JS / CANVAS 120 FPS)
    // =========================================================================
    private fun buildDashboardHtml(title: String): String = """
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>$title</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="dashboard-layout">
        <!-- SIDEBAR -->
        <aside class="sidebar">
            <div class="logo">⚡ <span>QUANT CORE</span></div>
            <nav class="side-nav">
                <a href="#" class="nav-item active">📊 Tổng Quan</a>
                <a href="#" class="nav-item">📈 Biểu Đồ SMC</a>
                <a href="#" class="nav-item">🪙 Ví Solana DEX</a>
                <a href="#" class="nav-item">⚙️ Cài Đặt</a>
            </nav>
        </aside>

        <!-- MAIN CONTENT -->
        <main class="main-content">
            <header class="topbar">
                <h2>Bảng Điều Khiển Thị Trường Real-time</h2>
                <div class="status-indicator">
                    <span class="pulse-dot"></span>
                    <span>120 FPS LIVE FEED</span>
                </div>
            </header>

            <!-- METRIC CARDS -->
            <section class="metrics-grid">
                <div class="metric-card">
                    <span class="m-label">GIÁ SOLANA (SOL)</span>
                    <div class="m-val" id="sol-price">$184.20</div>
                    <span class="m-change positive">+5.42% (24H)</span>
                </div>
                <div class="metric-card">
                    <span class="m-label">BITCOIN (BTC)</span>
                    <div class="m-val" id="btc-price">$68,450.00</div>
                    <span class="m-change positive">+2.15% (24H)</span>
                </div>
                <div class="metric-card">
                    <span class="m-label">TỶ LỆ RỦI RO VaR 95%</span>
                    <div class="m-val text-warning">4.85%</div>
                    <span class="m-change">Ngưỡng An Toàn</span>
                </div>
                <div class="metric-card">
                    <span class="m-label">TỶ TRỌNG KELLY</span>
                    <div class="m-val text-success">14.2% NAV</div>
                    <span class="m-change">Tối Ưu Vốn</span>
                </div>
            </section>

            <!-- REAL-TIME CANVAS CHART -->
            <section class="chart-section">
                <div class="chart-header">
                    <h3>Biểu Đồ Sóng Biến Động Khung 15M (Mali-G78 Canvas)</h3>
                    <div class="chart-actions">
                        <button type="button" class="btn-time active" data-time="15M">15M</button>
                        <button type="button" class="btn-time" data-time="1H">1H</button>
                        <button type="button" class="btn-time" data-time="4H">4H</button>
                    </div>
                </div>
                <div class="canvas-container">
                    <canvas id="marketChart" width="800" height="320"></canvas>
                </div>
            </section>
        </main>
    </div>
    <script src="app.js"></script>
</body>
</html>
    """.trimIndent()

    private fun buildDashboardCss(): String = """
:root {
    --bg-dark: #07090E;
    --bg-card: #0F141C;
    --border-color: #1E293B;
    --accent-cyan: #00E5FF;
    --accent-green: #14F195;
    --text-primary: #F8FAFC;
    --text-muted: #64748B;
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body { background: var(--bg-dark); color: var(--text-primary); font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif; }
.dashboard-layout { display: flex; min-height: 100vh; }
.sidebar { width: 220px; background: var(--bg-card); border-right: 1px solid var(--border-color); padding: 1.5rem 1rem; }
.logo { font-size: 1.1rem; font-weight: 800; color: var(--accent-cyan); margin-bottom: 2rem; display: flex; align-items: center; gap: 8px; }
.side-nav { display: flex; flex-direction: column; gap: 8px; }
.nav-item { color: var(--text-muted); text-decoration: none; padding: 10px 14px; border-radius: 8px; font-weight: 600; font-size: 0.9rem; transition: 0.2s; }
.nav-item.active, .nav-item:hover { background: rgba(0, 229, 255, 0.1); color: var(--accent-cyan); }
.main-content { flex: 1; padding: 2rem; overflow-y: auto; }
.topbar { display: flex; justify-content: space-between; align-items: center; margin-bottom: 2rem; }
.status-indicator { display: flex; align-items: center; gap: 8px; font-size: 0.8rem; font-weight: 700; color: var(--accent-green); background: rgba(20, 241, 149, 0.1); padding: 6px 12px; border-radius: 20px; }
.pulse-dot { width: 8px; height: 8px; background: var(--accent-green); border-radius: 50%; box-shadow: 0 0 8px var(--accent-green); }
.metrics-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
.metric-card { background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 12px; padding: 1.2rem; }
.m-label { font-size: 0.75rem; color: var(--text-muted); font-weight: 700; letter-spacing: 0.05em; }
.m-val { font-size: 1.6rem; font-weight: 800; margin: 6px 0; }
.m-change { font-size: 0.8rem; color: var(--text-muted); font-weight: 600; }
.positive { color: var(--accent-green); }
.text-warning { color: #F59E0B; }
.text-success { color: var(--accent-green); }
.chart-section { background: var(--bg-card); border: 1px solid var(--border-color); border-radius: 14px; padding: 1.5rem; }
.chart-header { display: flex; justify-content: space-between; align-items: center; margin-bottom: 1rem; }
.chart-actions { display: flex; gap: 6px; }
.btn-time { background: transparent; border: 1px solid var(--border-color); color: var(--text-muted); padding: 4px 10px; border-radius: 6px; cursor: pointer; font-size: 0.8rem; }
.btn-time.active { background: var(--accent-cyan); color: #000; font-weight: 700; border-color: var(--accent-cyan); }
.canvas-container { width: 100%; overflow-x: auto; }
canvas { display: block; width: 100%; max-width: 800px; height: auto; }
@media (max-width: 768px) {
    .dashboard-layout { flex-direction: column; }
    .sidebar { width: 100%; border-right: none; border-bottom: 1px solid var(--border-color); }
    .side-nav { flex-direction: row; overflow-x: auto; }
}
    """.trimIndent()

    private fun buildDashboardJs(): String = """
document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('marketChart');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');

    let points = [];
    for (let i = 0; i < 40; i++) {
        points.push(180 + Math.sin(i * 0.4) * 8 + (Math.random() * 4));
    }

    function renderChart() {
        const w = canvas.width;
        const h = canvas.height;
        ctx.clearRect(0, 0, w, h);

        // Lưới tọa độ
        ctx.strokeStyle = '#1E293B';
        ctx.lineWidth = 1;
        for (let y = 40; y < h; y += 50) {
            ctx.beginPath();
            ctx.moveTo(0, y);
            ctx.lineTo(w, y);
            ctx.stroke();
        }

        // Vẽ đường sóng giá mượt mà
        ctx.beginPath();
        const step = w / (points.length - 1);
        const minVal = Math.min(...points) - 5;
        const maxVal = Math.max(...points) + 5;

        for (let i = 0; i < points.length; i++) {
            const x = i * step;
            const y = h - ((points[i] - minVal) / (maxVal - minVal)) * (h - 40) - 20;
            if (i === 0) ctx.moveTo(x, y);
            else ctx.lineTo(x, y);
        }

        ctx.strokeStyle = '#00E5FF';
        ctx.lineWidth = 2.5;
        ctx.stroke();

        // Đổ bóng gradient bên dưới
        ctx.lineTo(w, h);
        ctx.lineTo(0, h);
        ctx.closePath();
        const grad = ctx.createLinearGradient(0, 0, 0, h);
        grad.addColorStop(0, 'rgba(0, 229, 255, 0.25)');
        grad.addColorStop(1, 'rgba(0, 229, 255, 0.0)');
        ctx.fillStyle = grad;
        ctx.fill();
    }

    renderChart();

    // Mô phỏng tick giá biến động 120 FPS
    setInterval(() => {
        const last = points[points.length - 1];
        const next = last + (Math.random() - 0.48) * 1.5;
        points.shift();
        points.push(next);
        renderChart();

        const solEl = document.getElementById('sol-price');
        if (solEl) solEl.textContent = '$' + next.toFixed(2);
    }, 800);
});
    """.trimIndent()

    // =========================================================================
    // TEMPLATE 3: E-COMMERCE CYBER STORE (HTML / CSS / JS / REACTIVE CART)
    // =========================================================================
    private fun buildEcommerceHtml(title: String): String = """
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>$title</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <header class="store-nav">
        <div class="nav-brand">🛍️ CYBER GEAR STORE</div>
        <div class="cart-trigger" id="open-cart">
            <span>🛒 Giỏ Hàng</span>
            <span class="cart-badge" id="cart-count">0</span>
        </div>
    </header>

    <main class="store-container">
        <h1 class="store-title">Thiết Bị Công Nghệ Thế Hệ Mới</h1>
        <div class="products-grid" id="products-list">
            <!-- Sản phẩm render bằng JS -->
        </div>
    </main>

    <!-- SLIDE-OVER CART DRAWER -->
    <div class="cart-overlay" id="cart-drawer">
        <div class="cart-content">
            <div class="cart-header">
                <h2>Giỏ Hàng Của Bạn</h2>
                <button type="button" id="close-cart" class="btn-close">✕</button>
            </div>
            <div class="cart-items" id="cart-items-container">
                <p class="empty-msg">Giỏ hàng đang trống.</p>
            </div>
            <div class="cart-footer">
                <div class="cart-total">Tổng tiền: <span id="cart-total-price">0 đ</span></div>
                <button type="button" class="btn-checkout" id="btn-checkout">Thanh Toán Ngay</button>
            </div>
        </div>
    </div>
    <script src="app.js"></script>
</body>
</html>
    """.trimIndent()

    private fun buildEcommerceCss(): String = """
:root {
    --bg-primary: #0A0D14;
    --card-bg: #131924;
    --accent: #00E5FF;
    --accent-gold: #FFD700;
    --text-main: #F1F5F9;
}
* { margin: 0; padding: 0; box-sizing: border-box; }
body { background: var(--bg-primary); color: var(--text-main); font-family: -apple-system, BlinkMacSystemFont, sans-serif; }
.store-nav { display: flex; justify-content: space-between; align-items: center; padding: 1rem 2rem; background: #0E131E; border-bottom: 1px solid #1F293D; }
.nav-brand { font-size: 1.2rem; font-weight: 800; color: var(--accent); }
.cart-trigger { background: #1C2436; padding: 8px 16px; border-radius: 20px; cursor: pointer; display: flex; gap: 8px; font-weight: 700; }
.cart-badge { background: var(--accent); color: #000; border-radius: 50%; padding: 2px 7px; font-size: 0.8rem; }
.store-container { max-width: 1100px; margin: 2rem auto; padding: 0 1rem; }
.store-title { text-align: center; margin-bottom: 2rem; font-size: 2rem; }
.products-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(240px, 1fr)); gap: 1.5rem; }
.p-card { background: var(--card-bg); border: 1px solid #1F293D; border-radius: 12px; padding: 1.5rem; display: flex; flex-direction: column; justify-content: space-between; }
.p-emoji { font-size: 3rem; text-align: center; margin-bottom: 1rem; }
.p-title { font-size: 1.1rem; font-weight: 700; margin-bottom: 6px; }
.p-price { color: var(--accent-gold); font-weight: 800; font-size: 1.2rem; margin-bottom: 1rem; }
.btn-add { background: var(--accent); color: #000; border: none; padding: 10px; border-radius: 8px; font-weight: 700; cursor: pointer; }
.cart-overlay { position: fixed; inset: 0; background: rgba(0,0,0,0.6); display: none; justify-content: flex-end; z-index: 1000; }
.cart-overlay.open { display: flex; }
.cart-content { width: 340px; background: #0F1420; height: 100%; padding: 1.5rem; display: flex; flex-direction: column; }
.cart-header { display: flex; justify-content: space-between; align-items: center; border-bottom: 1px solid #1E293B; padding-bottom: 1rem; }
.btn-close { background: none; border: none; color: #FFF; font-size: 1.2rem; cursor: pointer; }
.cart-items { flex: 1; overflow-y: auto; padding: 1rem 0; }
.empty-msg { color: #64748B; text-align: center; margin-top: 2rem; }
.cart-item { display: flex; justify-content: space-between; padding: 8px 0; border-bottom: 1px solid #1E293B; font-size: 0.9rem; }
.cart-total { font-size: 1.1rem; font-weight: 800; margin-bottom: 1rem; }
.btn-checkout { width: 100%; background: #14F195; color: #000; border: none; padding: 12px; border-radius: 8px; font-weight: 800; cursor: pointer; }
    """.trimIndent()

    private fun buildEcommerceJs(): String = """
document.addEventListener('DOMContentLoaded', () => {
    const products = [
        { id: 1, name: 'Tai nghe Quantum Pro ANC', price: 1850000, emoji: '🎧' },
        { id: 2, name: 'Bàn phím cơ Cyberpunk 68%', price: 2450000, emoji: '⌨️' },
        { id: 3, name: 'Đồng hồ thông minh Nexus X', price: 3200000, emoji: '⌚' },
        { id: 4, name: 'Chuột quang Gaming 12000 DPI', price: 890000, emoji: '🖱️' }
    ];

    let cart = [];

    const productsContainer = document.getElementById('products-list');
    if (productsContainer) {
        productsContainer.innerHTML = products.map(p => `
            <div class="p-card">
                <div class="p-emoji">${'$'}{p.emoji}</div>
                <div>
                    <h3 class="p-title">${'$'}{p.name}</h3>
                    <div class="p-price">${'$'}{p.price.toLocaleString('vi-VN')} đ</div>
                </div>
                <button type="button" class="btn-add" onclick="addToCart(${'$'}{p.id})">Thêm Vào Giỏ</button>
            </div>
        `).join('');
    }

    window.addToCart = (id) => {
        const prod = products.find(p => p.id === id);
        if (prod) {
            cart.push(prod);
            updateCartUI();
        }
    };

    function updateCartUI() {
        document.getElementById('cart-count').textContent = cart.length;
        const total = cart.reduce((acc, cur) => acc + cur.price, 0);
        document.getElementById('cart-total-price').textContent = total.toLocaleString('vi-VN') + ' đ';

        const container = document.getElementById('cart-items-container');
        if (cart.length === 0) {
            container.innerHTML = '<p class="empty-msg">Giỏ hàng đang trống.</p>';
        } else {
            container.innerHTML = cart.map((item, idx) => `
                <div class="cart-item">
                    <span>${'$'}{item.name}</span>
                    <span>${'$'}{item.price.toLocaleString('vi-VN')} đ</span>
                </div>
            `).join('');
        }
    }

    const cartDrawer = document.getElementById('cart-drawer');
    document.getElementById('open-cart')?.addEventListener('click', () => cartDrawer.classList.add('open'));
    document.getElementById('close-cart')?.addEventListener('click', () => cartDrawer.classList.remove('open'));
    document.getElementById('btn-checkout')?.addEventListener('click', () => {
        if (cart.length === 0) alert('Giỏ hàng chưa có sản phẩm nào!');
        else alert('Đã tạo đơn hàng thành công! Tổng tiền: ' + document.getElementById('cart-total-price').textContent);
    });
});
    """.trimIndent()

    // =========================================================================
    // TEMPLATE 4: PORTFOLIO CREATIVE (HTML / CSS / JS)
    // =========================================================================
    private fun buildPortfolioHtml(title: String): String = """
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>$title</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="portfolio-container">
        <header class="hero-profile">
            <div class="avatar-ring">👨‍💻</div>
            <h1>Alex Tran</h1>
            <p class="role-badge">Lead Edge AI &amp; Web Architect</p>
            <p class="bio">Chuyên gia xây dựng hệ sinh thái AI cục bộ, tối ưu đồ họa 120 FPS trên di động và kiến trúc web thế hệ mới.</p>
        </header>

        <section class="skills-block">
            <h2>Kỹ Năng Cốt Lõi</h2>
            <div class="tags">
                <span class="tag">HTML5 / CSS3 Grid</span>
                <span class="tag">JavaScript ES2024</span>
                <span class="tag">WebGL / Canvas 2D</span>
                <span class="tag">Edge AI / Qwen 1.5B</span>
                <span class="tag">Solana DEX Quant</span>
            </div>
        </section>

        <section class="projects-block">
            <h2>Dự Án Nổi Bật</h2>
            <div class="proj-grid">
                <div class="proj-card">
                    <h3>Hyper-Nexus Edge AI</h3>
                    <p>Hệ điều hành trợ lý ảo tự hành chạy trực tiếp trên chip Exynos 2100 với độ trễ phản hồi dưới 10ms.</p>
                </div>
                <div class="proj-card">
                    <h3>SMC Quant Scanner</h3>
                    <p>Bộ quét dòng tiền Smart Money, Order Block và mô hình xác suất Half-Kelly cho tài sản số.</p>
                </div>
            </div>
        </section>
    </div>
    <script src="app.js"></script>
</body>
</html>
    """.trimIndent()

    private fun buildPortfolioCss(): String = """
body { background: #080B11; color: #E2E8F0; font-family: -apple-system, sans-serif; line-height: 1.6; padding: 2rem 1rem; }
.portfolio-container { max-width: 700px; margin: 0 auto; }
.hero-profile { text-align: center; margin-bottom: 3rem; }
.avatar-ring { font-size: 4rem; margin-bottom: 1rem; display: inline-block; padding: 12px; background: rgba(0,229,255,0.1); border-radius: 50%; }
.role-badge { color: #00E5FF; font-weight: 700; font-size: 0.95rem; margin-bottom: 0.8rem; }
.bio { color: #94A3B8; font-size: 1rem; }
.skills-block, .projects-block { margin-bottom: 2.5rem; }
h2 { font-size: 1.3rem; margin-bottom: 1rem; border-left: 3px solid #00E5FF; padding-left: 10px; }
.tags { display: flex; flex-wrap: wrap; gap: 8px; }
.tag { background: #131A29; border: 1px solid #1E293B; padding: 6px 12px; border-radius: 6px; font-size: 0.85rem; font-weight: 600; }
.proj-grid { display: grid; gap: 1rem; }
.proj-card { background: #0E1420; border: 1px solid #1E293B; border-radius: 10px; padding: 1.2rem; }
.proj-card h3 { color: #14F195; margin-bottom: 6px; font-size: 1.1rem; }
    """.trimIndent()

    private fun buildPortfolioJs(): String = """
document.addEventListener('DOMContentLoaded', () => {
    console.log('Portfolio initialized successfully.');
});
    """.trimIndent()

    // =========================================================================
    // TEMPLATE 5: WEBGL 3D EXPERIENCE (HTML / CSS / JS / 120 FPS CANVAS 3D)
    // =========================================================================
    private fun build3DExperienceHtml(title: String): String = """
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>$title</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="hud-layer">
        <h1>📐 TRẢI NGHIỆM 3D CANVAS 120 FPS</h1>
        <p>Tương tác xoay vật thể bằng chuột hoặc chạm ngón tay trên màn hình</p>
        <div id="fps-counter">● 120 FPS MALI</div>
    </div>
    <canvas id="glCanvas"></canvas>
    <script src="app.js"></script>
</body>
</html>
    """.trimIndent()

    private fun build3DExperienceCss(): String = """
* { margin: 0; padding: 0; box-sizing: border-box; }
body { background: #05070A; overflow: hidden; height: 100vh; position: relative; font-family: sans-serif; }
.hud-layer { position: absolute; top: 20px; left: 20px; z-index: 10; color: #FFF; pointer-events: none; }
h1 { font-size: 1.1rem; color: #00E5FF; }
p { font-size: 0.8rem; color: #94A3B8; }
#fps-counter { margin-top: 8px; font-weight: 800; color: #14F195; font-size: 0.85rem; }
canvas { display: block; width: 100vw; height: 100vh; }
    """.trimIndent()

    private fun build3DExperienceJs(): String = """
document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('glCanvas');
    const ctx = canvas.getContext('2d');
    function resize() {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
    }
    window.addEventListener('resize', resize);
    resize();

    // 8 đỉnh khối lập phương 3D
    let nodes = [
        [-1, -1, -1], [-1, -1, 1], [-1, 1, -1], [-1, 1, 1],
        [1, -1, -1], [1, -1, 1], [1, 1, -1], [1, 1, 1]
    ];
    let edges = [
        [0, 1], [1, 3], [3, 2], [2, 0],
        [4, 5], [5, 7], [7, 6], [6, 4],
        [0, 4], [1, 5], [2, 6], [3, 7]
    ];

    let rotX = 0, rotY = 0;
    let isDragging = false, lastX = 0, lastY = 0;

    window.addEventListener('pointerdown', (e) => {
        isDragging = true; lastX = e.clientX; lastY = e.clientY;
    });
    window.addEventListener('pointermove', (e) => {
        if (!isDragging) return;
        rotY += (e.clientX - lastX) * 0.01;
        rotX += (e.clientY - lastY) * 0.01;
        lastX = e.clientX; lastY = e.clientY;
    });
    window.addEventListener('pointerup', () => isDragging = false);

    function loop() {
        if (!isDragging) { rotX += 0.01; rotY += 0.015; }
        ctx.clearRect(0, 0, canvas.width, canvas.height);

        const cx = canvas.width / 2;
        const cy = canvas.height / 2;
        const scale = Math.min(cx, cy) * 0.5;

        let projected = nodes.map(node => {
            let [x, y, z] = node;
            // Xoay Y
            let x1 = x * Math.cos(rotY) + z * Math.sin(rotY);
            let z1 = -x * Math.sin(rotY) + z * Math.cos(rotY);
            // Xoay X
            let y2 = y * Math.cos(rotX) - z1 * Math.sin(rotX);
            let z2 = y * Math.sin(rotX) + z1 * Math.cos(rotX);

            let fov = 3.5 / (3.5 + z2);
            return [cx + x1 * scale * fov, cy + y2 * scale * fov];
        });

        // Vẽ cạnh khối lập phương Neon
        ctx.strokeStyle = '#00E5FF';
        ctx.lineWidth = 2.5;
        edges.forEach(([i, j]) => {
            ctx.beginPath();
            ctx.moveTo(projected[i][0], projected[i][1]);
            ctx.lineTo(projected[j][0], projected[j][1]);
            ctx.stroke();
        });

        requestAnimationFrame(loop);
    }
    requestAnimationFrame(loop);
});
    """.trimIndent()

    // =========================================================================
    // TEMPLATE 6: RETRO WEB GAME (HTML5 CANVAS 120 FPS RUNNER)
    // =========================================================================
    private fun buildRetroGameHtml(title: String): String = """
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>$title</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="game-wrapper">
        <header class="game-header">
            <h2>CYBER RUNNER 120 FPS</h2>
            <div class="score-display">Điểm: <span id="score">0</span></div>
        </header>
        <canvas id="gameCanvas" width="400" height="600"></canvas>
        <div class="touch-controls">
            <button type="button" id="btn-jump">🚀 NHẢY QUA CHƯỚNG NGẠI</button>
        </div>
    </div>
    <script src="app.js"></script>
</body>
</html>
    """.trimIndent()

    private fun buildRetroGameCss(): String = """
* { margin: 0; padding: 0; box-sizing: border-box; }
body { background: #04060A; color: #FFF; font-family: sans-serif; display: flex; justify-content: center; align-items: center; min-height: 100vh; }
.game-wrapper { text-align: center; }
.game-header { display: flex; justify-content: space-between; width: 400px; margin-bottom: 8px; font-weight: 800; color: #00E5FF; }
canvas { background: #0B101C; border: 2px solid #00E5FF; border-radius: 8px; box-shadow: 0 0 20px rgba(0,229,255,0.2); }
.touch-controls { margin-top: 12px; }
#btn-jump { width: 400px; padding: 14px; background: #14F195; color: #000; font-weight: 900; font-size: 1.1rem; border: none; border-radius: 8px; cursor: pointer; }
    """.trimIndent()

    private fun buildRetroGameJs(): String = """
document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');
    let playerY = 480, velocityY = 0, gravity = 0.6, isJumping = false;
    let score = 0;
    let obstacles = [{ x: 450, w: 30, h: 40 }];

    function jump() {
        if (!isJumping) {
            velocityY = -12;
            isJumping = true;
        }
    }

    window.addEventListener('keydown', (e) => { if (e.code === 'Space') jump(); });
    document.getElementById('btn-jump')?.addEventListener('click', jump);

    function update() {
        playerY += velocityY;
        velocityY += gravity;
        if (playerY >= 480) { playerY = 480; isJumping = false; velocityY = 0; }

        obstacles.forEach(o => o.x -= 4);
        if (obstacles[0].x < -30) {
            obstacles.shift();
            obstacles.push({ x: 450 + Math.random() * 100, w: 25, h: 35 + Math.random() * 20 });
            score += 10;
            document.getElementById('score').textContent = score;
        }

        // Vẽ
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        // Sàn đất
        ctx.fillStyle = '#1E293B';
        ctx.fillRect(0, 510, 400, 90);

        // Nhân vật Cyber Robot
        ctx.fillStyle = '#00E5FF';
        ctx.fillRect(60, playerY, 30, 30);

        // Chướng ngại vật
        ctx.fillStyle = '#F43F5E';
        obstacles.forEach(o => ctx.fillRect(o.x, 510 - o.h, o.w, o.h));

        requestAnimationFrame(update);
    }
    requestAnimationFrame(update);
});
    """.trimIndent()

    private fun buildWebManifest(title: String, template: WebProjectTemplate): String = """
{
  "short_name": "NitWeb",
  "name": "$title",
  "icons": [],
  "start_url": "./index.html",
  "background_color": "#090C12",
  "theme_color": "#00E5FF",
  "display": "standalone",
  "orientation": "portrait"
}
    """.trimIndent()
}
