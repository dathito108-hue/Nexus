package com.hypernexus.nit.evolution

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log

class ContextMemoryManager(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val TAG = "ContextMemoryManager"
        private const val DATABASE_NAME = "hyper_nexus_memory.db"
        private const val DATABASE_VERSION = 1

        private const val TABLE_EPISODIC = "episodic_memory"
        private const val COL_ID = "id"
        private const val COL_TIMESTAMP = "timestamp"
        private const val COL_ROLE = "role"
        private const val COL_CONTENT = "content"
        private const val COL_SUMMARY_TAG = "summary_tag"

        // Giới hạn KV-cache trượt: Tối đa 2.048 tokens (tương đương ~10 câu hội thoại gần nhất)
        const val MAX_SLIDING_WINDOW_TURNS = 10
    }

    override fun onCreate(db: SQLiteDatabase) {
        val createQuery = """
            CREATE TABLE $TABLE_EPISODIC (
                $COL_ID INTEGER PRIMARY KEY AUTOINCREMENT,
                $COL_TIMESTAMP INTEGER,
                $COL_ROLE TEXT,
                $COL_CONTENT TEXT,
                $COL_SUMMARY_TAG TEXT
            )
        """.trimIndent()
        db.execSQL(createQuery)
        Log.d(TAG, "Đã khởi tạo cơ sở dữ liệu Bộ nhớ Dài hạn SQLite cục bộ.")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_EPISODIC")
        onCreate(db)
    }

    /**
     * Lưu một lượt tương tác (User / Assistant) vào bộ nhớ dài hạn
     */
    fun saveInteraction(role: String, content: String, tag: String = "GENERAL") {
        try {
            val db = writableDatabase
            val values = ContentValues().apply {
                put(COL_TIMESTAMP, System.currentTimeMillis())
                put(COL_ROLE, role)
                put(COL_CONTENT, content)
                put(COL_SUMMARY_TAG, tag)
            }
            db.insert(TABLE_EPISODIC, null, values)
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi lưu bộ nhớ tương tác: ${e.message}")
        }
    }

    /**
     * Lấy ngữ cảnh trượt (Sliding Window Context): Chỉ lấy tối đa 10 lượt gần nhất để nạp vào KV-cache
     * Đảm bảo RAM KV-Cache luôn bị chặn trần ở mức < 150MB trên máy S21 FE!
     */
    fun getRecentSlidingWindowContext(): List<Pair<String, String>> {
        val result = mutableListOf<Pair<String, String>>()
        try {
            val db = readableDatabase
            val cursor = db.query(
                TABLE_EPISODIC,
                arrayOf(COL_ROLE, COL_CONTENT),
                null,
                null,
                null,
                null,
                "$COL_ID DESC",
                MAX_SLIDING_WINDOW_TURNS.toString()
            )

            while (cursor.moveToNext()) {
                val role = cursor.getString(cursor.getColumnIndexOrThrow(COL_ROLE))
                val content = cursor.getString(cursor.getColumnIndexOrThrow(COL_CONTENT))
                result.add(Pair(role, content))
            }
            cursor.close()
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi đọc ngữ cảnh trượt: ${e.message}")
        }
        return result.reversed() // Đảo lại theo thứ tự thời gian từ cũ đến mới
    }

    /**
     * Dọn dẹp các mẩu tin quá 30 ngày để tối ưu dung lượng ổ cứng UFS
     */
    fun pruneOldMemories() {
        try {
            val thirtyDaysAgo = System.currentTimeMillis() - (30L * 24 * 60 * 60 * 1000)
            val db = writableDatabase
            val deletedRows = db.delete(TABLE_EPISODIC, "$COL_TIMESTAMP < ?", arrayOf(thirtyDaysAgo.toString()))
            Log.d(TAG, "Đã nén và dọn dẹp $deletedRows bản ghi cũ khỏi bộ nhớ SQLite.")
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi dọn dẹp bộ nhớ: ${e.message}")
        }
    }
}
