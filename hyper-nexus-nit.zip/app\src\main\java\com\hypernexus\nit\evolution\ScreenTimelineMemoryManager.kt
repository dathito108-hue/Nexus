package com.hypernexus.nit.evolution

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.util.Log
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * HỆ THỐNG KÝ ỨC MÀN HÌNH NGƯỢC DÒNG THỜI GIAN (SCREEN TIMELINE REWIND)
 * Sử dụng SQLite FTS4 (Full-Text Search) nội bộ trên Samsung Galaxy S21 FE.
 * Không gửi bất kỳ byte dữ liệu nào ra ngoài máy. Tự động mã hóa và giới hạn kích thước < 20MB.
 */
class ScreenTimelineMemoryManager(context: Context) : SQLiteOpenHelper(context, DATABASE_NAME, null, DATABASE_VERSION) {

    companion object {
        private const val TAG = "ScreenTimelineManager"
        private const val DATABASE_NAME = "nit_screen_timeline.db"
        private const val DATABASE_VERSION = 1
        private const val TABLE_NAME = "screen_timeline_fts"
        private const val MAX_RECORDS = 5000 // Giữ tối đa 5000 mục (~15MB RAM/Flash)
    }

    data class TimelineMemoryItem(
        val id: Long,
        val packageName: String,
        val appLabel: String,
        val textSnippet: String,
        val timestamp: Long,
        val formattedTime: String
    )

    private var lastRecordedHash: Int = 0
    private var lastRecordedTime: Long = 0

    override fun onCreate(db: SQLiteDatabase) {
        // Bảng tìm kiếm toàn văn FTS4 siêu tốc
        val createFtsTable = """
            CREATE VIRTUAL TABLE IF NOT EXISTS $TABLE_NAME USING fts4(
                package_name,
                app_label,
                text_content,
                timestamp_ms,
                date_str
            )
        """.trimIndent()
        db.execSQL(createFtsTable)
        Log.d(TAG, "Đã khởi tạo bảng ảo SQLite FTS4 cho Ký Ức Màn Hình.")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        db.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        onCreate(db)
    }

    /**
     * Ghi nhận tức thời nội dung văn bản đang hiển thị trên màn hình
     * Có cơ chế Debounce và lọc trùng băm (Hash deduplication)
     */
    fun recordScreenContent(packageName: String, appLabel: String, rawContent: String) {
        val cleanContent = rawContent.trim()
        if (cleanContent.length < 20) return // Bỏ qua màn hình rỗng hoặc quá ít chữ

        val now = System.currentTimeMillis()
        val contentHash = cleanContent.hashCode()

        // Debounce: Nếu nội dung giống hệt hoặc chưa đủ 3.5 giây trôi qua thì bỏ qua
        if (contentHash == lastRecordedHash || (now - lastRecordedTime < 3500)) {
            return
        }

        // Bỏ qua các ứng dụng hệ thống nhạy cảm (Cài đặt bảo mật, Khóa máy)
        if (packageName.contains("settings.security") || packageName.contains("keyguard")) {
            return
        }

        lastRecordedHash = contentHash
        lastRecordedTime = now

        try {
            val db = writableDatabase
            val timeFormatter = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault())
            val dateStr = timeFormatter.format(Date(now))

            val values = ContentValues().apply {
                put("package_name", packageName)
                put("app_label", appLabel)
                put("text_content", cleanContent)
                put("timestamp_ms", now)
                put("date_str", dateStr)
            }

            db.insert(TABLE_NAME, null, values)

            // Vòng quay bộ nhớ: Giới hạn tối đa MAX_RECORDS
            pruneMemoryRingBuffer(db)

        } catch (e: Exception) {
            Log.e(TAG, "Lỗi lưu trữ ký ức màn hình: ${e.message}")
        }
    }

    /**
     * TÌM KIẾM NGƯỢC DÒNG THỜI GIAN THEO TỪ KHÓA BẰNG TOÁN TỬ FTS MATCH
     */
    fun searchTimelineMemory(query: String, limit: Int = 5): List<TimelineMemoryItem> {
        val results = mutableListOf<TimelineMemoryItem>()
        if (query.isBlank()) return results

        try {
            val db = readableDatabase
            // Làm sạch truy vấn FTS (chống ký tự đặc biệt làm gãy cú pháp FTS)
            val cleanQuery = query.replace("'", "").replace("\"", "").trim()
            val ftsQuery = cleanQuery.split(" ")
                .filter { it.isNotBlank() }
                .joinToString(" AND ") { "$it*" } // Tìm kiếm tiền tố

            val sql = """
                SELECT docid, package_name, app_label, text_content, timestamp_ms, date_str
                FROM $TABLE_NAME
                WHERE text_content MATCH ?
                ORDER BY timestamp_ms DESC
                LIMIT ?
            """.trimIndent()

            val cursor = db.rawQuery(sql, arrayOf(ftsQuery, limit.toString()))
            if (cursor.moveToFirst()) {
                do {
                    val id = cursor.getLong(0)
                    val pkg = cursor.getString(1)
                    val label = cursor.getString(2)
                    val fullText = cursor.getString(3)
                    val timestamp = cursor.getLong(4)
                    val dateStr = cursor.getString(5)

                    // Trích xuất đoạn trích văn bản ngắn xung quanh từ khóa
                    val snippet = extractSnippet(fullText, cleanQuery)

                    results.add(
                        TimelineMemoryItem(
                            id = id,
                            packageName = pkg,
                            appLabel = label,
                            textSnippet = snippet,
                            timestamp = timestamp,
                            formattedTime = dateStr
                        )
                    )
                } while (cursor.moveToNext())
            }
            cursor.close()
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi tìm kiếm FTS: ${e.message}")
        }

        return results
    }

    /**
     * Trích đoạn văn bản chứa từ khóa tìm kiếm (Snippet highlighter)
     */
    private fun extractSnippet(fullText: String, keyword: String): String {
        val lowerText = fullText.lowercase(Locale.getDefault())
        val lowerKey = keyword.lowercase(Locale.getDefault())
        val index = lowerText.indexOf(lowerKey)

        if (index == -1) {
            return if (fullText.length > 250) fullText.take(250) + "..." else fullText
        }

        val start = (index - 60).coerceAtLeast(0)
        val end = (index + keyword.length + 120).coerceAtMost(fullText.length)
        var snippet = fullText.substring(start, end).trim()
        if (start > 0) snippet = "...$snippet"
        if (end < fullText.length) snippet = "$snippet..."
        return snippet
    }

    /**
     * Xóa các mục cũ nhất khi vượt quá giới hạn MAX_RECORDS
     */
    private fun pruneMemoryRingBuffer(db: SQLiteDatabase) {
        try {
            val countCursor = db.rawQuery("SELECT count(*) FROM $TABLE_NAME", null)
            if (countCursor.moveToFirst()) {
                val totalCount = countCursor.getInt(0)
                if (totalCount > MAX_RECORDS) {
                    val excess = totalCount - MAX_RECORDS
                    db.execSQL("DELETE FROM $TABLE_NAME WHERE docid IN (SELECT docid FROM $TABLE_NAME ORDER BY timestamp_ms ASC LIMIT $excess)")
                    Log.d(TAG, "Đã dọn dẹp $excess bản ghi ký ức cũ để duy trì ngân sách bộ nhớ.")
                }
            }
            countCursor.close()
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi prune ring buffer: ${e.message}")
        }
    }
}
