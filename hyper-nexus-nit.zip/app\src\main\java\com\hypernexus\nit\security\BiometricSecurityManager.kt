package com.hypernexus.nit.security

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

object BiometricSecurityManager {

    /**
     * Kiểm tra xem máy S21 FE có sẵn vân tay / nhận diện khuôn mặt hay không
     */
    fun isBiometricAvailable(context: Context): Boolean {
        val biometricManager = BiometricManager.from(context)
        return biometricManager.canAuthenticate(
            BiometricManager.Authenticators.BIOMETRIC_STRONG or BiometricManager.Authenticators.BIOMETRIC_WEAK
        ) == BiometricManager.BIOMETRIC_SUCCESS
    }

    /**
     * Yêu cầu người dùng chạm vân tay trước khi AI tự động ký giao dịch Solana DEX
     */
    fun promptBiometricForTrade(
        activity: FragmentActivity,
        tradeDetails: String,
        onSuccess: () -> Unit,
        onError: (String) -> Unit
    ) {
        val executor = ContextCompat.getMainExecutor(activity)
        val prompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                super.onAuthenticationSucceeded(result)
                onSuccess()
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                super.onAuthenticationError(errorCode, errString)
                onError(errString.toString())
            }

            override fun onAuthenticationFailed() {
                super.onAuthenticationFailed()
                onError("Vân tay không khớp. Giao dịch bị hủy bỏ vì an toàn.")
            }
        })

        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle("🔒 XÁC THỰC LỆNH GIAO DỊCH SOLANA")
            .setSubtitle(tradeDetails)
            .setDescription("Nít cần chữ ký sinh trắc học của bạn trên Samsung Knox để gửi lệnh lên blockchain.")
            .setNegativeButtonText("Hủy bỏ")
            .build()

        prompt.authenticate(promptInfo)
    }
}
