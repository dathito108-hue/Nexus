package com.hypernexus.nit.web

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.Context
import android.graphics.Color
import android.graphics.drawable.ColorDrawable
import android.os.Bundle
import android.view.ViewGroup
import android.view.Window
import android.webkit.ConsoleMessage
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Button
import android.widget.FrameLayout
import android.widget.TextView
import com.hypernexus.nit.R

/**
 * HỘP THOẠI XEM TRƯỚC WEB SANDBOX TƯƠNG TÁC 120 FPS (WEB LIVE PREVIEW STUDIO)
 * Tích hợp WebView tăng tốc GPU Mali-G78, chuyển đổi khung nhìn Responsive di động (375px)
 * và thu nhận log console JavaScript trực tiếp on-device.
 */
class WebPreviewDialog(
    context: Context,
    private val project: WebDevelopmentEngine.WebProject,
    private val serverUrl: String
) : Dialog(context) {

    private lateinit var wvSandbox: WebView
    private lateinit var tvTitle: TextView
    private lateinit var tvUrl: TextView
    private lateinit var tvConsole: TextView
    private lateinit var flContainer: FrameLayout
    private lateinit var btnModeMobile: Button
    private lateinit var btnModeFull: Button
    private lateinit var btnRefresh: Button
    private lateinit var btnClose: Button

    private val consoleLogs = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestWindowFeature(Window.FEATURE_NO_TITLE)
        setContentView(R.layout.dialog_web_preview)
        window?.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
        window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)

        initViews()
        setupWebView()
        setupListeners()
    }

    private fun initViews() {
        wvSandbox = findViewById(R.id.wv_sandbox_preview)
        tvTitle = findViewById(R.id.tv_preview_title)
        tvUrl = findViewById(R.id.tv_preview_url)
        tvConsole = findViewById(R.id.tv_console_output)
        flContainer = findViewById(R.id.fl_webview_container)
        btnModeMobile = findViewById(R.id.btn_mode_mobile)
        btnModeFull = findViewById(R.id.btn_mode_full)
        btnRefresh = findViewById(R.id.btn_preview_refresh)
        btnClose = findViewById(R.id.btn_close_preview)

        tvTitle.text = "🌐 ${project.title} (${project.template.code})"
        tvUrl.text = serverUrl
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val settings = wvSandbox.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.cacheMode = WebSettings.LOAD_NO_CACHE

        wvSandbox.setBackgroundColor(Color.parseColor("#090C12"))

        wvSandbox.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                appendConsoleLog("✅ [Page Loaded]: $url")
            }
        }

        wvSandbox.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                if (consoleMessage != null) {
                    val level = consoleMessage.messageLevel()
                    val line = "[JS ${level.name} L${consoleMessage.lineNumber()}]: ${consoleMessage.message()}"
                    appendConsoleLog(line)
                }
                return true
            }
        }

        wvSandbox.loadUrl(serverUrl)
    }

    private fun setupListeners() {
        btnRefresh.setOnClickListener {
            wvSandbox.reload()
            appendConsoleLog("🔄 Làm mới trang web...")
        }

        btnClose.setOnClickListener {
            dismiss()
        }

        btnModeMobile.setOnClickListener {
            // Chuyển sang kích thước điện thoại 375dp
            val density = context.resources.displayMetrics.density
            val widthPx = (375 * density).toInt()
            val params = wvSandbox.layoutParams
            params.width = widthPx
            wvSandbox.layoutParams = params

            btnModeMobile.setBackgroundColor(Color.parseColor("#00E5FF"))
            btnModeMobile.setTextColor(Color.parseColor("#000000"))
            btnModeFull.setBackgroundColor(Color.parseColor("#1E293B"))
            btnModeFull.setTextColor(Color.parseColor("#94A3B8"))
        }

        btnModeFull.setOnClickListener {
            // Chuyển sang tràn màn hình
            val params = wvSandbox.layoutParams
            params.width = ViewGroup.LayoutParams.MATCH_PARENT
            wvSandbox.layoutParams = params

            btnModeFull.setBackgroundColor(Color.parseColor("#00E5FF"))
            btnModeFull.setTextColor(Color.parseColor("#000000"))
            btnModeMobile.setBackgroundColor(Color.parseColor("#1E293B"))
            btnModeMobile.setTextColor(Color.parseColor("#00E5FF"))
        }
    }

    private fun appendConsoleLog(log: String) {
        consoleLogs.add(log)
        if (consoleLogs.size > 20) consoleLogs.removeAt(0)
        tvConsole.text = consoleLogs.joinToString("\n")
    }

    override fun dismiss() {
        wvSandbox.stopLoading()
        super.dismiss()
    }
}
