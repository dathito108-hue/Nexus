package com.hypernexus.nit.web

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import org.json.JSONObject
import java.net.URLEncoder
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

object WebSearchEngine {

    private const val TAG = "WebSearchEngine"
    private val client = OkHttpClient.Builder()
        .connectTimeout(6, TimeUnit.SECONDS)
        .readTimeout(6, TimeUnit.SECONDS)
        .build()

    data class SearchResult(
        val title: String,
        val snippet: String,
        val url: String
    )

    /**
     * TÌM KIẾM INTERNET THỜI GIAN THỰC (REAL-TIME WEB SEARCH)
     * Sử dụng kết hợp DuckDuckGo API và Wikipedia Tiếng Việt không tốn phí API key
     */
    suspend fun searchWeb(query: String, maxResults: Int = 3): List<SearchResult> = withContext(Dispatchers.IO) {
        val results = mutableListOf<SearchResult>()
        try {
            val encodedQuery = URLEncoder.encode(query, "UTF-8")

            // 1. Tìm kiếm qua DuckDuckGo HTML / Instant Answer Engine
            val ddgUrl = "https://html.duckduckgo.com/html/?q=$encodedQuery"
            val request = Request.Builder()
                .url(ddgUrl)
                .header("User-Agent", "Mozilla/5.0 (Linux; Android 14; SM-G990E) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36")
                .build()

            val response = client.newCall(request).execute()
            val html = response.body?.string() ?: ""

            // Bóc tách kết quả tìm kiếm từ HTML bằng Regex tối ưu
            val resultPattern = Pattern.compile("<a class=\"result__url\" href=\"(.*?)\".*?<a class=\"result__snippet.*?>(.*?)</a>", Pattern.DOTALL)
            val matcher = resultPattern.matcher(html)

            var count = 0
            while (matcher.find() && count < maxResults) {
                val rawUrl = matcher.group(1)?.trim() ?: ""
                val cleanSnippet = matcher.group(2)?.replace(Regex("<.*?>"), "")?.trim() ?: ""

                if (cleanSnippet.isNotEmpty()) {
                    results.add(SearchResult(
                        title = "Kết quả tìm kiếm #${count + 1}",
                        snippet = cleanSnippet,
                        url = rawUrl
                    ))
                    count++
                }
            }

            // 2. Dự phòng: Nếu không có kết quả từ DuckDuckGo, tìm kiếm qua Wikipedia tiếng Việt
            if (results.isEmpty()) {
                val wikiResults = searchWikipediaVi(query)
                results.addAll(wikiResults)
            }

            Log.d(TAG, "Đã tìm thấy ${results.size} kết quả Internet cho truy vấn: $query")
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi tìm kiếm Internet: ${e.message}")
        }
        return@withContext results
    }

    /**
     * TÌM KIẾM NGUỒN TRI THỨC BÁCH KHOA TOÀN THƯ WIKIPEDIA VIỆT NAM
     */
    private fun searchWikipediaVi(query: String): List<SearchResult> {
        val list = mutableListOf<SearchResult>()
        try {
            val encoded = URLEncoder.encode(query, "UTF-8")
            val wikiUrl = "https://vi.wikipedia.org/w/api.php?action=opensearch&search=$encoded&limit=2&namespace=0&format=json"
            val request = Request.Builder().url(wikiUrl).build()
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return list

            val jsonArray = JSONArray(body)
            if (jsonArray.length() >= 4) {
                val titles = jsonArray.getJSONArray(1)
                val snippets = jsonArray.getJSONArray(2)
                val urls = jsonArray.getJSONArray(3)

                for (i in 0 until titles.length()) {
                    list.add(SearchResult(
                        title = titles.getString(i),
                        snippet = snippets.getString(i),
                        url = urls.getString(i)
                    ))
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi tìm Wikipedia: ${e.message}")
        }
        return list
    }
}
