package com.hypernexus.nit.video

import android.content.Context
import android.content.Intent
import android.util.Log
import com.hypernexus.nit.accessibility.NitAccessibilityService
import com.hypernexus.nit.overlay.MicroRobotOverlayService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/**
 * ĐỘNG CƠ BIÊN TẬP VIDEO CAPCUT ĐỘC BẢN THEO MÔ TẢ TỰ DO CỦA NGƯỜI DÙNG
 * (PROMPT-DRIVEN DYNAMIC CAPCUT VIDEO EDITING ENGINE)
 * ─────────────────────────────────────────────────────────────────────────────
 * Không bị giới hạn vào các template hay preset cố định; tự động phân tích ngôn ngữ tự nhiên
 * bóc tách nhịp cắt (Pacing), tỷ lệ khung hình, chỉnh màu LUT, hiệu ứng thị giác,
 * phân lớp âm nhạc (BGM & SFX Foley), cân bằng âm lượng (Audio Ducking) và phụ đề,
 * sau đó điều khiển trực tiếp Accessibility Service trên Samsung Galaxy S21 FE.
 */
object DynamicCapCutSynthesisEngine {

    private const val TAG = "DynamicCapCutSynth"

    data class DynamicCapCutSpec(
        val userPrompt: String,
        val projectTitle: String,
        val targetAspectRatio: String,
        val cutPacingIntervalSeconds: Float,
        val colorFilterName: String,
        val visualEffectName: String,
        val transitionStyle: String,
        val bgmGenre: String,
        val primarySfx: String,
        val enableAudioDucking: Boolean,
        val bgmVolumePercent: Int,
        val subtitleStyle: String,
        val exportQuality: String
    )

    /**
     * KIỂM TRA XEM CÂU LỆNH CÓ PHẢI YÊU CẦU BIÊN TẬP VIDEO THEO MÔ TẢ TỰ DO KHÔNG
     */
    fun isCustomCapCutPrompt(prompt: String): Boolean {
        val lower = prompt.lowercase().trim()
        val isVideoRequest = lower.contains("capcut") || lower.contains("video") || lower.contains("clip") ||
                lower.contains("biên tập") || lower.contains("edit") || lower.contains("dựng")

        val hasCustomKeywords = lower.contains("mô tả") || lower.contains("theo ý") || lower.contains("tùy biến") ||
                lower.contains("vlog") || lower.contains("ẩm thực") || lower.contains("đồ ăn") || lower.contains("ấm cúng") ||
                lower.contains("nhạc") || lower.contains("lofi") || lower.contains("acoustic") || lower.contains("nhanh") ||
                lower.contains("chậm") || lower.contains("màu") || lower.contains("vintage") || lower.contains("cyberpunk") ||
                lower.contains("phụ đề") || lower.contains("zoom") || lower.contains("rung") || lower.contains("flash") ||
                lower.contains("chuyển cảnh") || lower.contains("hiệu ứng") || lower.contains("độc bản")

        return isVideoRequest && hasCustomKeywords
    }

    /**
     * PHÂN TÍCH NGỮ NGHĨA KHẨU LỆNH ĐỂ TRÍCH XUẤT THÔNG SỐ SẢN XUẤT VIDEO
     */
    fun parseCapCutSpecFromPrompt(prompt: String): DynamicCapCutSpec {
        val lower = prompt.lowercase().trim()

        // 1. Tỷ lệ khung hình
        val aspectRatio = when {
            lower.contains("16:9") || lower.contains("ngang") || lower.contains("youtube") -> "16:9"
            lower.contains("1:1") || lower.contains("vuông") || lower.contains("instagram") -> "1:1"
            else -> "9:16" // Mặc định chuẩn TikTok / Shorts / Reels
        }

        // 2. Nhịp điệu cắt dựng (Pacing)
        val cutInterval = when {
            lower.contains("nhanh") || lower.contains("dồn dập") || lower.contains("giật") || lower.contains("beat") -> 1.5f
            lower.contains("chậm") || lower.contains("thong thả") || lower.contains("chill") || lower.contains("điện ảnh") -> 4.5f
            else -> 3.0f
        }

        // 3. Chỉnh màu LUT / Tone màu
        val colorFilter = when {
            lower.contains("ấm") || lower.contains("vintage") || lower.contains("cổ điển") || lower.contains("film") || lower.contains("hoài niệm") -> {
                "Kodak Gold Ấm Áp Vintage"
            }
            lower.contains("lạnh") || lower.contains("cyberpunk") || lower.contains("neon") || lower.contains("tương lai") || lower.contains("tím") -> {
                "Lạnh Tương Phản Neon Cyberpunk"
            }
            lower.contains("cam xanh") || lower.contains("teal") || lower.contains("orange") || lower.contains("du lịch") -> {
                "Teal & Orange Hollywood Điện Ảnh"
            }
            lower.contains("đen trắng") || lower.contains("noir") || lower.contains("sang trọng") || lower.contains("tối giản") -> {
                "Monochrome Noir Tương Phản Tinh Tế"
            }
            lower.contains("rực rỡ") || lower.contains("tươi sáng") || lower.contains("bắt mắt") || lower.contains("tiktok") -> {
                "Tươi Sáng Rực Rỡ Vivid Pop"
            }
            else -> "Điện Ảnh Cân Bằng Chuẩn Hollywood"
        }

        // 4. Hiệu ứng thị giác & Chuyển cảnh
        val visualEffect = when {
            lower.contains("zoom") || lower.contains("phóng to") || lower.contains("thu phóng") -> "Thu Phóng Ống Kính Kỹ Thuật (Dynamic Zoom)"
            lower.contains("rung") || lower.contains("va đập") || lower.contains("nảy") || lower.contains("shake") -> "Rung Chấn Va Đập Mạnh (Shake Impact)"
            lower.contains("flash") || lower.contains("lóa") || lower.contains("sáng") -> "Lóa Sáng Flash & Nảy Đèn (Flash Bounce)"
            lower.contains("glitch") || lower.contains("nhiễu") || lower.contains("rè") -> "Nhiễu Sóng Điện Tử Glitch Tech"
            lower.contains("bụi") || lower.contains("xước") || lower.contains("hạt") -> "Hạt Bụi Cào Xước Film Grain"
            else -> "Mờ Nhòe Nghệ Thuật (Soft Focus Glow)"
        }

        val transition = when {
            lower.contains("mờ dần") || lower.contains("hòa tan") -> "Hòa Tan Mềm Mại (Dissolve)"
            lower.contains("lướt") || lower.contains("trượt") -> "Trượt Lướt Nhanh (Smooth Slide)"
            lower.contains("chớp") || lower.contains("lóa") -> "Flash Trắng Chuyển Cảnh"
            else -> "Cắt Nhảy Giật Theo Nhịp (Jump Cut Beat)"
        }

        // 5. Âm nhạc nền (BGM) & Foley SFX
        val bgmGenre = when {
            lower.contains("lofi") || lower.contains("chill") || lower.contains("thư giãn") -> "Lo-Fi Hip-Hop Chillout Thư Thái"
            lower.contains("acoustic") || lower.contains("guitar") || lower.contains("mộc") || lower.contains("ấm cúng") -> "Acoustic Guitar Mộc Mạc Dịu Êm"
            lower.contains("synthwave") || lower.contains("điện tử") || lower.contains("cyber") -> "Synthwave Cyber Electronic Tương Lai"
            lower.contains("trap") || lower.contains("rock") || lower.contains("game") || lower.contains("gaming") -> "Trap Rock Bass Heavy Căng Thẳng"
            lower.contains("phonk") || lower.contains("bass boost") || lower.contains("trend") -> "Phonk & EDM Bass Boost Sôi Động"
            lower.contains("piano") || lower.contains("sang") -> "Piano Cổ Điển Tinh Tế Sang Trọng"
            else -> "Cinematic Ambient Đa Tầng Cảm Xúc"
        }

        val sfx = when {
            lower.contains("ting") || lower.contains("chuông") -> "Ting Chuông Điểm Nhấn (Bell Ting)"
            lower.contains("whoosh") || lower.contains("gió") || lower.contains("vút") -> "Whoosh Vút Gió Chuyển Cảnh"
            lower.contains("bass") || lower.contains("nổ") || lower.contains("thud") -> "Bass Drop Rung Màng Loa"
            lower.contains("chụp ảnh") || lower.contains("tách") -> "Tách Bấm Máy Ảnh (Camera Shutter)"
            lower.contains("glitch") -> "Glitch Rè Công Nghệ"
            else -> "Whoosh Vút Gió Mềm Mại"
        }

        // 6. Phụ đề & Âm lượng Ducking
        val subtitleStyle = when {
            lower.contains("vàng") -> "Chữ Vàng Nghệ Thuật Viền Đen Nổi Bật"
            lower.contains("neon") || lower.contains("xanh") -> "Chữ Neon Cyan Phát Sáng Hiện Đại"
            lower.contains("trắng") -> "Chữ Trắng Tối Giản Nền Bán Trong Suốt"
            else -> "Phụ Đề Tự Động Màu Vàng Viền Đen Chuẩn Xu Hướng"
        }

        val title = extractCapCutTitle(prompt)

        return DynamicCapCutSpec(
            userPrompt = prompt,
            projectTitle = title,
            targetAspectRatio = aspectRatio,
            cutPacingIntervalSeconds = cutInterval,
            colorFilterName = colorFilter,
            visualEffectName = visualEffect,
            transitionStyle = transition,
            bgmGenre = bgmGenre,
            primarySfx = sfx,
            enableAudioDucking = true,
            bgmVolumePercent = 25,
            subtitleStyle = subtitleStyle,
            exportQuality = "1080P_60FPS"
        )
    }

    private fun extractCapCutTitle(prompt: String): String {
        val clean = prompt.replace("edit video", "", ignoreCase = true)
            .replace("làm video", "", ignoreCase = true)
            .replace("chỉnh sửa video", "", ignoreCase = true)
            .replace("dựng clip", "", ignoreCase = true)
            .replace("capcut", "", ignoreCase = true)
            .trim()

        return if (clean.length in 4..35) {
            clean.replaceFirstChar { it.uppercase() }
        } else {
            "Dự Án CapCut Độc Bản"
        }
    }

    /**
     * THỰC THI CHUỖI TỰ ĐỘNG HÓA SẢN XUẤT CAPCUT ĐỘC BẢN QUA ACCESSIBILITY SERVICE
     */
    suspend fun executeDynamicProduction(
        context: Context,
        spec: DynamicCapCutSpec,
        onStepProgress: ((stepNumber: Int, stage: String, message: String) -> Unit)? = null
    ): String = withContext(Dispatchers.Main) {
        val service = NitAccessibilityService.instance
        if (service == null) {
            return@withContext "⚠️ Vui lòng cấp quyền Trợ năng (Accessibility) để Nít có thể tự động biên tập trên CapCut!"
        }

        // Mở ứng dụng CapCut
        val pm = context.packageManager
        val launchIntent = pm.getLaunchIntentForPackage(CapCutProAutomationEngine.CAPCUT_PACKAGE)
        if (launchIntent == null) {
            return@withContext "Không tìm thấy ứng dụng CapCut trên thiết bị."
        }
        launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(launchIntent)
        MicroRobotOverlayService.updateState(MicroRobotOverlayService.RobotState.ACTION)

        val dm = context.resources.displayMetrics
        val w = dm.widthPixels.toFloat()
        val h = dm.heightPixels.toFloat()

        val logs = mutableListOf<String>()
        fun recordStep(num: Int, stage: String, msg: String) {
            logs.add("• [$stage]: $msg")
            onStepProgress?.invoke(num, stage, msg)
        }

        recordStep(1, "KHỞI ĐỘNG STUDIO", "Mở CapCut và thiết lập không gian biên tập cho \"${spec.projectTitle}\"...")
        delay(2200)

        // 1. Mở dự án mới & Nạp footage
        recordStep(2, "NẠP DỮ LIỆU", "Tạo dự án mới và đưa phân đoạn video vào Timeline...")
        clickOrFallback(service, listOf("Dự án mới", "New project"), w * 0.50f, h * 0.28f)
        delay(1800)
        service.performClick(w * 0.20f, h * 0.22f)
        delay(600)
        clickOrFallback(service, listOf("Thêm", "Add"), w * 0.85f, h * 0.95f)
        delay(2200)

        // 2. Định dạng Tỷ lệ khung hình theo yêu cầu
        recordStep(3, "TỶ LỆ KHUNG HÌNH", "Thiết lập khung hình chuẩn ${spec.targetAspectRatio}...")
        clickOrFallback(service, listOf("Tỷ lệ", "Ratio"), w * 0.75f, h * 0.95f)
        delay(800)
        when (spec.targetAspectRatio) {
            "9:16" -> clickOrFallback(service, listOf("9:16"), w * 0.30f, h * 0.88f)
            "16:9" -> clickOrFallback(service, listOf("16:9"), w * 0.50f, h * 0.88f)
            "1:1" -> clickOrFallback(service, listOf("1:1"), w * 0.70f, h * 0.88f)
        }
        delay(1000)

        // 3. Cắt nhịp điệu (Pacing & Trimming)
        recordStep(4, "CẮT THEO NHỊP ĐIỆU", "Tự động phân tách và đồng bộ nhịp cắt mỗi ${spec.cutPacingIntervalSeconds}s...")
        service.performClick(w * 0.15f, h * 0.95f) // Nút Tách (Split)
        delay(800)
        service.performSwipe(w * 0.70f, h * 0.65f, w * 0.40f, h * 0.65f, 300) // Cuộn timeline
        delay(800)
        service.performClick(w * 0.15f, h * 0.95f) // Tách nhịp tiếp theo
        delay(1000)

        // 4. Áp dụng bảng màu LUT theo mô tả
        recordStep(5, "CHỈNH MÀU LUT", "Áp dụng bảng màu \"${spec.colorFilterName}\"...")
        service.performSwipe(w * 0.85f, h * 0.95f, w * 0.25f, h * 0.95f, 250)
        delay(800)
        clickOrFallback(service, listOf("Bộ lọc", "Filters", "Màu sắc"), w * 0.50f, h * 0.95f)
        delay(1200)
        service.performClick(w * 0.35f, h * 0.82f)
        delay(800)
        service.performClick(w * 0.85f, h * 0.88f)
        delay(1000)

        // 5. Chèn hiệu ứng thị giác bóc tách từ mô tả
        recordStep(6, "HIỆU ỨNG THỊ GIÁC", "Chèn hiệu ứng \"${spec.visualEffectName}\" & chuyển cảnh \"${spec.transitionStyle}\"...")
        clickOrFallback(service, listOf("Hiệu ứng", "Effects"), w * 0.40f, h * 0.95f)
        delay(1000)
        clickOrFallback(service, listOf("Hiệu ứng video", "Video effects"), w * 0.25f, h * 0.85f)
        delay(1200)
        service.performClick(w * 0.25f, h * 0.70f)
        delay(1000)
        service.performClick(w * 0.90f, h * 0.60f)
        delay(1000)

        // 6. Ghép âm nhạc BGM & SFX Foley
        recordStep(7, "ÂM THANH ĐA TẦNG", "Ghép nhạc nền \"${spec.bgmGenre}\" và âm thanh \"${spec.primarySfx}\"...")
        service.performClick(w * 0.08f, h * 0.95f)
        delay(600)
        clickOrFallback(service, listOf("Âm thanh", "Audio"), w * 0.25f, h * 0.95f)
        delay(1000)
        clickOrFallback(service, listOf("Âm thanh", "Sounds", "Nhạc"), w * 0.15f, h * 0.95f)
        delay(1500)
        service.performClick(w * 0.85f, h * 0.35f)
        delay(1500)

        // 7. Cân bằng âm thanh (Audio Ducking)
        if (spec.enableAudioDucking) {
            recordStep(8, "AUDIO DUCKING", "Tự động hạ âm lượng BGM xuống ${spec.bgmVolumePercent}% khi có lời nói...")
            service.performClick(w * 0.50f, h * 0.65f)
            delay(800)
            service.performClick(w * 0.40f, h * 0.95f)
            delay(800)
            service.performSwipe(w * 0.80f, h * 0.85f, w * 0.35f, h * 0.85f, 250)
            delay(1000)
        }

        // 8. Chèn phụ đề theo phong cách bóc tách
        recordStep(9, "PHỤ ĐỀ & TYPOGRAPHY", "Tạo phụ đề tự động kiểu \"${spec.subtitleStyle}\"...")
        service.performClick(w * 0.08f, h * 0.95f)
        delay(600)
        clickOrFallback(service, listOf("Văn bản", "Text"), w * 0.35f, h * 0.95f)
        delay(1000)
        clickOrFallback(service, listOf("Phụ đề tự động", "Auto captions"), w * 0.25f, h * 0.85f)
        delay(1200)
        clickOrFallback(service, listOf("Bắt đầu", "Start", "Tạo"), w * 0.50f, h * 0.92f)
        delay(2500)

        // 9. Xuất video chất lượng cao
        recordStep(10, "XUẤT BẢN HOÀN TẤT", "Thiết lập xuất bản ${spec.exportQuality} và kết xuất sản phẩm...")
        clickOrFallback(service, listOf("Xuất", "Export"), w * 0.90f, h * 0.06f)
        delay(2000)

        MicroRobotOverlayService.updateState(MicroRobotOverlayService.RobotState.IDLE)
        return@withContext """
            🎬 [KẾT QUẢ SẢN XUẤT CAPCUT ĐỘC BẢN THEO MÔ TẢ]:
            • Dự án: ${spec.projectTitle}
            • Yêu cầu: "${spec.userPrompt}"
            • Tỷ lệ: ${spec.targetAspectRatio} | Nhịp cắt: mỗi ${spec.cutPacingIntervalSeconds}s
            • Màu sắc LUT: ${spec.colorFilterName}
            • Hiệu ứng thị giác: ${spec.visualEffectName}
            • Chuyển cảnh: ${spec.transitionStyle}
            • Nhạc nền (BGM): ${spec.bgmGenre} (Ducking ${spec.bgmVolumePercent}%)
            • Foley SFX: ${spec.primarySfx}
            • Phụ đề: ${spec.subtitleStyle}
            • Xuất bản: ${spec.exportQuality}
            👉 Video đã được kết xuất hoàn tất trên CapCut của máy!
        """.trimIndent()
    }

    suspend fun executeFromPrompt(
        context: Context,
        prompt: String,
        onStepProgress: ((stepNumber: Int, stage: String, message: String) -> Unit)? = null
    ): String {
        val spec = parseCapCutSpecFromPrompt(prompt)
        return executeDynamicProduction(context, spec, onStepProgress)
    }

    private suspend fun clickOrFallback(
        service: NitAccessibilityService,
        textOptions: List<String>,
        fallbackX: Float,
        fallbackY: Float
    ) {
        val clicked = service.clickNodeByText(textOptions)
        if (!clicked) {
            service.performClick(fallbackX, fallbackY)
        }
    }
}
