package com.hypernexus.nit.router

import android.content.Context
import android.util.Log
import com.hypernexus.nit.engine.LlamaEngine
import com.hypernexus.nit.planner.CognitiveTaskReasoner
import com.hypernexus.nit.planner.TaskPlanningManager
import com.hypernexus.nit.planner.AutonomousExecutionEngine
import org.json.JSONArray
import org.json.JSONObject

/**
 * BỘ ĐIỀU PHỐI NGỮ NGHĨA LAI & TỰ GỌI CÔNG CỤ (HYBRID SEMANTIC DISPATCHER & AGENTIC TOOL CALLING)
 * Hỗ trợ bóc tách đa ý định (Multi-Intent Decomposition) cho các câu lệnh ghép phức tạp,
 * và tích hợp cơ chế LLM JSON Tool Calling cho mô hình ngôn ngữ Qwen 1.5B (GGUF).
 */
object HybridSemanticDispatcher {

    private const val TAG = "HybridSemanticDispatcher"

    // Các từ liên kết tách mệnh đề ý định trong tiếng Việt
    private val CONJUNCTIONS = listOf(
        " và ", " rồi ", " sau đó ", " đồng thời ",
        " kèm theo ", " với lại ", "; ", "\n"
    )

    /**
     * PHÂN RÃ ĐA Ý ĐỊNH TỪ CÂU LỆNH GHÉP (MULTI-INTENT DECOMPOSITION)
     * Ví dụ: "Dựng 3D cốc nước và lập trình game đua xe rồi lên lịch sáng mai nhắc tao"
     * -> ["Dựng 3D cốc nước", "lập trình game đua xe", "lên lịch sáng mai nhắc tao"]
     */
    fun decomposeMultiIntents(rawInput: String): List<String> {
        val trimmed = rawInput.trim()
        if (trimmed.isEmpty()) return emptyList()

        var parts = listOf(trimmed)
        for (conj in CONJUNCTIONS) {
            val newParts = mutableListOf<String>()
            for (part in parts) {
                if (part.contains(conj, ignoreCase = true)) {
                    val splitItems = part.split(Regex(PatternQuote(conj), RegexOption.IGNORE_CASE))
                    splitItems.forEach { item ->
                        val clean = item.trim()
                        if (clean.length >= 3) {
                            newParts.add(clean)
                        }
                    }
                } else {
                    newParts.add(part)
                }
            }
            parts = newParts
        }

        // Lọc lại các phân đoạn hợp lệ
        val validIntents = parts.map { it.trim() }.filter { it.length >= 4 }
        return if (validIntents.size > 1) validIntents else listOf(trimmed)
    }

    private fun PatternQuote(s: String): String = java.util.regex.Pattern.quote(s)

    /**
     * THỰC THI TRUY VẤN TOOL CALLING QUA LLM JSON SCHEMA
     * Khi System 1 không khớp chắc chắn, LLM nhận diện công cụ cần gọi và xuất JSON schema.
     */
    suspend fun executeLlmToolCalling(context: Context, rawInput: String): String? {
        val schemaPrompt = """
            <|im_start|>system
            Bạn là Nít, trí tuệ nhân tạo tự hành 100% On-Device trên Samsung Galaxy S21 FE.
            Nếu người dùng yêu cầu thực hiện hành động kỹ thuật, hãy trả về DUY NHẤT một khối JSON chứa danh sách công cụ cần gọi theo định dạng:
            {"tools": [{"tool": "TÊN_CÔNG_CỤ", "params": {"key": "value"}}]}

            Danh sách công cụ khả dụng:
            1. "generate_3d_model": Dựng mô hình 3D tham số (.STL). Params: {"prompt": "mô tả hình học"}
            2. "develop_web_game": Lập trình game web 120 FPS độc bản. Params: {"prompt": "thể loại game"}
            3. "develop_web_app": Lập trình trang web HTML5/CSS3. Params: {"prompt": "mô tả website"}
            4. "edit_video_capcut": Biên tập video CapCut Pro độc bản. Params: {"prompt": "chủ đề và nhịp cắt"}
            5. "quant_market_analyze": Phân tích tài chính thể chế SMC. Params: {"asset": "BTC|SOL|XAU|ETH"}
            6. "control_smart_home": Điều khiển nhà thông minh LAN. Params: {"device": "LIGHT|AC|FAN", "action": "turn_on|turn_off"}
            7. "search_screen_memory": Tìm ký ức màn hình FTS4. Params: {"query": "từ khóa"}
            8. "schedule_autonomous_plan": Lập kế hoạch & hẹn giờ. Params: {"goal": "mục tiêu"}

            Nếu là câu hỏi trò chuyện thông thường không cần công cụ, chỉ cần trả lời tự nhiên ngắn gọn.<|im_end|>
            <|im_start|>user
            $rawInput<|im_end|>
            <|im_start|>assistant
        """.trimIndent()

        val response = LlamaEngine.generateResponse(schemaPrompt, maxTokens = 250, temperature = 0.3f)
        Log.d(TAG, "Phản hồi từ LLM Tool Caller: $response")

        // Kiểm tra xem phản hồi có chứa khối JSON tools không
        val jsonStart = response.indexOf("{\"tools\"")
        if (jsonStart == -1) return null

        val jsonEnd = response.lastIndexOf("}")
        if (jsonEnd <= jsonStart) return null

        val jsonSubstring = response.substring(jsonStart, jsonEnd + 1)
        return try {
            val rootObj = JSONObject(jsonSubstring)
            val toolsArray = rootObj.getJSONArray("tools")
            if (toolsArray.length() == 0) return null

            val sb = StringBuilder("⚡ [AGENTIC TOOL CALLING EXECUTED]:\n")
            for (i in 0 until toolsArray.length()) {
                val toolObj = toolsArray.getJSONObject(i)
                val toolName = toolObj.getString("tool")
                val paramsObj = toolObj.optJSONObject("params") ?: JSONObject()

                val result = executeToolByName(context, toolName, paramsObj)
                sb.append("• Công cụ $toolName: $result\n")
            }
            sb.toString().trim()
        } catch (e: Exception) {
            Log.w(TAG, "Lỗi phân tích JSON Tool Calling: ${e.message}")
            null
        }
    }

    private suspend fun executeToolByName(context: Context, toolName: String, params: JSONObject): String {
        return when (toolName) {
            "generate_3d_model" -> {
                val prompt = params.optString("prompt", "bánh răng cơ khí")
                val mesh = com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.synthesize3DMeshFromPrompt(prompt)
                val file = com.hypernexus.nit.engine.Procedural3DGenerator.exportToBinaryStlFile(context, mesh, "nit_tool_${System.currentTimeMillis() % 1000}.stl")
                "Đã dựng mô hình 3D \"${mesh.customTitle}\" (${mesh.triangleCount} tam giác) và xuất Binary STL tại ${file.name}"
            }
            "develop_web_game" -> {
                val prompt = params.optString("prompt", "game né chướng ngại vật 120 FPS")
                val project = com.hypernexus.nit.web.DynamicGameSynthesisEngine.synthesizeGameFromPrompt(context, prompt)
                com.hypernexus.nit.web.LocalWebSandboxServer.startServer(project)
                "Đã lập trình game \"${project.title}\" và khởi chạy Live Sandbox tại ${com.hypernexus.nit.web.LocalWebSandboxServer.getServerUrl()}"
            }
            "develop_web_app" -> {
                val prompt = params.optString("prompt", "landing page")
                val template = com.hypernexus.nit.web.WebDevelopmentEngine.matchTemplateFromCommand(prompt)
                val project = com.hypernexus.nit.web.WebDevelopmentEngine.generateProject(template)
                com.hypernexus.nit.web.LocalWebSandboxServer.startServer(project)
                "Đã lập trình web \"${project.title}\" tại ${com.hypernexus.nit.web.LocalWebSandboxServer.getServerUrl()}"
            }
            "edit_video_capcut" -> {
                val prompt = params.optString("prompt", "video phong cách điện ảnh")
                com.hypernexus.nit.video.DynamicCapCutSynthesisEngine.executeFromPrompt(context, prompt)
            }
            "quant_market_analyze" -> {
                val asset = params.optString("asset", "BTC").uppercase()
                val dossier = com.hypernexus.nit.finance.InstitutionalMarketAnalyzer.analyzeInstitutionalMarket(asset)
                dossier.formatExecutiveMemo()
            }
            "control_smart_home" -> {
                val deviceStr = params.optString("device", "LIGHT").uppercase()
                val action = params.optString("action", "turn_on")
                val dev = when (deviceStr) {
                    "AC", "AIR_CONDITIONER" -> com.hypernexus.nit.smarthome.SmartHomeLocalBridge.DeviceType.AIR_CONDITIONER
                    "FAN" -> com.hypernexus.nit.smarthome.SmartHomeLocalBridge.DeviceType.FAN
                    else -> com.hypernexus.nit.smarthome.SmartHomeLocalBridge.DeviceType.LIGHT
                }
                com.hypernexus.nit.smarthome.SmartHomeLocalBridge.controlDevice(dev, action)
            }
            "search_screen_memory" -> {
                val query = params.optString("query", "")
                val tm = com.hypernexus.nit.evolution.ScreenTimelineMemoryManager(context)
                val list = tm.searchTimelineMemory(query, limit = 2)
                if (list.isNotEmpty()) "Tìm thấy: \"${list[0].textSnippet}\" trên ${list[0].appLabel}" else "Không tìm thấy trong FTS4."
            }
            "schedule_autonomous_plan" -> {
                val goal = params.optString("goal", "nhiệm vụ tự hành")
                val plan = CognitiveTaskReasoner.reasonAndCreatePlan(goal)
                TaskPlanningManager.schedulePlan(context, plan)
                "Đã lên lịch kế hoạch \"${plan.title}\" gồm ${plan.steps.size} bước tự hành."
            }
            else -> "Đã nhận diện công cụ $toolName."
        }
    }
}
