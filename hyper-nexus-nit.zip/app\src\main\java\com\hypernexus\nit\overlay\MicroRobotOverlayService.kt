package com.hypernexus.nit.overlay

import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast
import com.hypernexus.nit.R
import com.hypernexus.nit.accessibility.NitAccessibilityService
import com.hypernexus.nit.engine.LlamaEngine
import com.hypernexus.nit.finance.SolanaDexDataManager
import com.hypernexus.nit.router.SystemRouter
import com.hypernexus.nit.voice.VoiceInteractionEngine
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MicroRobotOverlayService : Service() {

    enum class RobotState(val ledColor: Int, val description: String) {
        SLEEP(Color.parseColor("#44FFFFFF"), "Ngủ sâu (0% GPU)"),
        LISTENING(Color.parseColor("#00E5FF"), "Đang nghe..."),
        THINKING(Color.parseColor("#FFD600"), "Đang suy luận..."),
        ACTION(Color.parseColor("#00E676"), "Hoàn thành tác vụ!"),
        SWARM_WIFI(Color.parseColor("#D500F9"), "Kết nối Wi-Fi Mesh")
    }

    companion object {
        var instance: MicroRobotOverlayService? = null
        fun updateState(state: RobotState) {
            instance?.setRobotState(state)
        }
    }

    private var windowManager: WindowManager? = null
    private var overlayView: View? = null
    private var hudView: View? = null
    private var isHudVisible = false
    private var eyeLedView: View? = null
    private var floatingAnimator: ObjectAnimator? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val serviceScope = CoroutineScope(Dispatchers.Main)
    private lateinit var systemRouter: SystemRouter
    private var voiceEngine: VoiceInteractionEngine? = null

    private var initialX = 0
    private var initialY = 0
    private var initialTouchX = 0f
    private var initialTouchY = 0f

    private var gestureDriver: com.hypernexus.nit.gesture.FrontCameraGestureDriver? = null
    private var isGestureActive = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        instance = this
        systemRouter = SystemRouter(this)
        voiceEngine = VoiceInteractionEngine(this)
        windowManager = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        createFloatingRobot()
    }

    private fun createFloatingRobot() {
        val inflater = LayoutInflater.from(this)
        overlayView = inflater.inflate(R.layout.overlay_micro_robot, null)
        eyeLedView = overlayView?.findViewById(R.id.robot_eye_led)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val density = resources.displayMetrics.density
        val widthPx = (35 * density).toInt()
        val heightPx = (40 * density).toInt()

        val params = WindowManager.LayoutParams(
            widthPx,
            heightPx,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 80
            y = 250
        }

        startFloatingAnimation()

        overlayView?.setOnTouchListener { view, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = initialX + (event.rawX - initialTouchX).toInt()
                    params.y = initialY + (event.rawY - initialTouchY).toInt()
                    windowManager?.updateViewLayout(overlayView, params)
                    true
                }
                MotionEvent.ACTION_UP -> {
                    val displayMetrics = resources.displayMetrics
                    val screenWidth = displayMetrics.widthPixels
                    val targetX = if (params.x < screenWidth / 2) 10 else (screenWidth - widthPx - 10)
                    params.x = targetX
                    windowManager?.updateViewLayout(overlayView, params)

                    val moveDist = Math.hypot((event.rawX - initialTouchX).toDouble(), (event.rawY - initialTouchY).toDouble())
                    if (moveDist < 10) {
                        toggleQuickHud(params.x, params.y)
                    }
                    view.performClick()
                    true
                }
                else -> false
            }
        }

        windowManager?.addView(overlayView, params)
        setRobotState(RobotState.SLEEP)
    }

    private fun startFloatingAnimation() {
        val root = overlayView?.findViewById<View>(R.id.robot_body) ?: return
        val pvhY = PropertyValuesHolder.ofFloat(View.TRANSLATION_Y, -2.5f, 2.5f)
        val pvhAlpha = PropertyValuesHolder.ofFloat(View.ALPHA, 0.75f, 1.0f)

        floatingAnimator = ObjectAnimator.ofPropertyValuesHolder(root, pvhY, pvhAlpha).apply {
            duration = 1200
            repeatMode = ValueAnimator.REVERSE
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    private fun toggleQuickHud(robotX: Int, robotY: Int) {
        if (isHudVisible) {
            closeQuickHud()
        } else {
            openQuickHud(robotX, robotY)
        }
    }

    private fun openQuickHud(robotX: Int, robotY: Int) {
        val inflater = LayoutInflater.from(this)
        hudView = inflater.inflate(R.layout.overlay_robot_hud, null)

        val layoutFlag = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        val density = resources.displayMetrics.density
        val displayMetrics = resources.displayMetrics
        val screenWidth = displayMetrics.widthPixels

        val hudParams = WindowManager.LayoutParams(
            (230 * density).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutFlag,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = if (robotX < screenWidth / 2) robotX + (40 * density).toInt() else robotX - (235 * density).toInt()
            y = (robotY - 50).coerceAtLeast(100)
        }

        // 1. Phân tích Solana DEX Quant Pro (SOL/USDC)
        hudView?.findViewById<Button>(R.id.btn_hud_solana_dex)?.setOnClickListener {
            closeQuickHud()
            setRobotState(RobotState.THINKING)
            Toast.makeText(this, "Nít: Đang quét dữ liệu On-Chain Raydium/Orca...", Toast.LENGTH_SHORT).show()
            serviceScope.launch {
                val result = SolanaDexDataManager.analyzeSolanaDexToken("SOL")
                voiceEngine?.speak(result)
            }
        }

        // 2. Phân tích Vàng Thế Giới (XAU/USD)
        hudView?.findViewById<Button>(R.id.btn_hud_gold)?.setOnClickListener {
            closeQuickHud()
            setRobotState(RobotState.THINKING)
            Toast.makeText(this, "Nít: Đang phân tích kỹ thuật thị trường Vàng...", Toast.LENGTH_SHORT).show()
            serviceScope.launch {
                val result = SolanaDexDataManager.analyzeWorldGold()
                voiceEngine?.speak(result)
            }
        }

        // 3. Tự động hóa CapCut Pro Studio
        hudView?.findViewById<Button>(R.id.btn_hud_capcut)?.setOnClickListener {
            closeQuickHud()
            setRobotState(RobotState.ACTION)
            Toast.makeText(this, "Nít: Đang kích hoạt CapCut Pro Studio...", Toast.LENGTH_SHORT).show()
            serviceScope.launch {
                com.hypernexus.nit.video.CapCutProAutomationEngine.executeProEditingPreset(
                    this@MicroRobotOverlayService,
                    com.hypernexus.nit.video.CapCutProAutomationEngine.EditingPreset.FULL_STUDIO_PIPELINE
                )
                voiceEngine?.speak("Đã hoàn tất quy trình biên tập CapCut Pro Studio.")
            }
        }

        // 3.1 Tìm kiếm Internet Live
        hudView?.findViewById<Button>(R.id.btn_hud_web_search)?.setOnClickListener {
            closeQuickHud()
            setRobotState(RobotState.THINKING)
            Toast.makeText(this, "Nít: Đang tìm kiếm tin tức trên Internet...", Toast.LENGTH_SHORT).show()
            serviceScope.launch {
                val searchResult = com.hypernexus.nit.web.WebSearchEngine.searchWeb("tin tức công nghệ AI mới nhất")
                val text = if (searchResult.isNotEmpty()) {
                    "Tìm thấy tin tức: " + searchResult[0].snippet
                } else "Đã hoàn thành tìm kiếm Internet."
                voiceEngine?.speak(text)
            }
        }

        // 3.2 Quét bảo mật RugCheck Solana
        hudView?.findViewById<Button>(R.id.btn_hud_rugcheck)?.setOnClickListener {
            closeQuickHud()
            setRobotState(RobotState.THINKING)
            Toast.makeText(this, "Nít: Đang quét bảo mật On-Chain Solana...", Toast.LENGTH_SHORT).show()
            serviceScope.launch {
                val audit = com.hypernexus.nit.finance.SolanaSafetyAuditor.auditTokenSecurity(com.hypernexus.nit.finance.SolanaDexDataManager.SOL_MINT)
                val text = "Kiểm toán Solana: ${audit.safetyScore} điểm, ${audit.riskLevel}. ${audit.summaryNote}"
                voiceEngine?.speak(text)
            }
        }

        // 3.3 Thị giác màn hình & Chart
        hudView?.findViewById<Button>(R.id.btn_hud_vision)?.setOnClickListener {
            closeQuickHud()
            setRobotState(RobotState.THINKING)
            Toast.makeText(this, "Nít: Đang phân tích thị giác màn hình...", Toast.LENGTH_SHORT).show()
            val service = NitAccessibilityService.instance
            val rootText = service?.rootInActiveWindow?.text?.toString() ?: ""
            val transfer = com.hypernexus.nit.vision.ScreenVisionCoPilot.parseBankTransferFromText(rootText)
            val reply = if (transfer != null) {
                "Phát hiện giao dịch ${transfer.bankName}: STK ${transfer.accountNumber}, số tiền ${transfer.amount} VND."
            } else {
                "Screen Vision đã quét màn hình: Sẵn sàng soi biểu đồ hoặc nhận diện hóa đơn."
            }
            voiceEngine?.speak(reply)
        }

        // 3.4 Cử chỉ không chạm Camera trước
        hudView?.findViewById<Button>(R.id.btn_hud_gesture)?.setOnClickListener {
            closeQuickHud()
            if (!isGestureActive) {
                gestureDriver = com.hypernexus.nit.gesture.FrontCameraGestureDriver(this).apply {
                    start { gesture ->
                        mainHandler.post {
                            Toast.makeText(this@MicroRobotOverlayService, "🖐️ Cử chỉ: $gesture", Toast.LENGTH_SHORT).show()
                            when (gesture) {
                                com.hypernexus.nit.gesture.AirGestureEngine.RecognizedGesture.SWIPE_UP -> {
                                    NitAccessibilityService.instance?.performSwipe(540f, 1600f, 540f, 600f, 250)
                                }
                                com.hypernexus.nit.gesture.AirGestureEngine.RecognizedGesture.SWIPE_DOWN -> {
                                    NitAccessibilityService.instance?.performSwipe(540f, 600f, 540f, 1600f, 250)
                                }
                                else -> {}
                            }
                        }
                    }
                }
                isGestureActive = true
                Toast.makeText(this, "Nít: Đã bật cử chỉ không chạm qua Camera trước!", Toast.LENGTH_SHORT).show()
            } else {
                gestureDriver?.stop()
                gestureDriver = null
                isGestureActive = false
                Toast.makeText(this, "Nít: Đã tắt cử chỉ không chạm.", Toast.LENGTH_SHORT).show()
            }
        }

        // 3.5 Ký ức màn hình Rewind
        hudView?.findViewById<Button>(R.id.btn_hud_rewind)?.setOnClickListener {
            closeQuickHud()
            setRobotState(RobotState.THINKING)
            Toast.makeText(this, "Nít: Đang truy xuất ký ức màn hình FTS4...", Toast.LENGTH_SHORT).show()
            serviceScope.launch {
                val tm = NitAccessibilityService.instance?.getTimelineManager() ?: com.hypernexus.nit.evolution.ScreenTimelineMemoryManager(this@MicroRobotOverlayService)
                val memories = tm.searchTimelineMemory("", limit = 2)
                val reply = if (memories.isNotEmpty()) {
                    "Ký ức gần nhất: Lúc ${memories[0].formattedTime} trên ${memories[0].appLabel}: ${memories[0].textSnippet.take(100)}..."
                } else {
                    "Ký ức màn hình: Chưa ghi nhận nội dung gần đây. Nít đang tiếp tục quan sát màn hình ngầm."
                }
                voiceEngine?.speak(reply)
            }
        }

        // 3.6 Kế hoạch & Lịch trình tự hành
        hudView?.findViewById<Button>(R.id.btn_hud_planner)?.setOnClickListener {
            closeQuickHud()
            setRobotState(RobotState.THINKING)
            Toast.makeText(this, "Nít: Đang kiểm tra kế hoạch tự hành...", Toast.LENGTH_SHORT).show()
            serviceScope.launch {
                val db = com.hypernexus.nit.planner.PlanDatabaseHelper(this@MicroRobotOverlayService)
                val activePlans = db.getAllActivePlans().filter { it.status == com.hypernexus.nit.planner.PlanStatus.ACTIVE || it.status == com.hypernexus.nit.planner.PlanStatus.RUNNING }
                if (activePlans.isNotEmpty()) {
                    val p = activePlans.first()
                    val msg = "Kế hoạch đang chờ: ${p.title}, gồm ${p.steps.size} bước tự hành."
                    Toast.makeText(this@MicroRobotOverlayService, msg, Toast.LENGTH_LONG).show()
                    voiceEngine?.speak(msg)
                } else {
                    val defaultPlan = com.hypernexus.nit.planner.CognitiveTaskReasoner.reasonAndCreatePlan("quét giá sol và vàng thế giới")
                    com.hypernexus.nit.planner.TaskPlanningManager.schedulePlan(this@MicroRobotOverlayService, defaultPlan)
                    val msg = "Đã lên lịch kế hoạch mới: ${defaultPlan.title} (${defaultPlan.steps.size} bước)."
                    Toast.makeText(this@MicroRobotOverlayService, msg, Toast.LENGTH_SHORT).show()
                    voiceEngine?.speak(msg)
                }
            }
        }

        // 3.7 Xưởng 3D & Máy In (Binary STL)
        hudView?.findViewById<Button>(R.id.btn_hud_3d_slicer)?.setOnClickListener {
            closeQuickHud()
            setRobotState(RobotState.THINKING)
            Toast.makeText(this, "Nít: Đang phân tích Slicer & xuất Binary STL...", Toast.LENGTH_SHORT).show()
            serviceScope.launch {
                val mesh = com.hypernexus.nit.engine.Procedural3DGenerator.buildMeshData(com.hypernexus.nit.engine.Procedural3DGenerator.MeshType.SPUR_GEAR)
                val analysis = com.hypernexus.nit.engine.Procedural3DGenerator.analyzeMeshFor3DPrinting(mesh)
                val file = com.hypernexus.nit.engine.Procedural3DGenerator.exportToBinaryStlFile(this@MicroRobotOverlayService, mesh, "nit_spur_gear_binary.stl")
                val speech = "Mô hình bánh răng có thể tích ${"%.1f".format(analysis.volumeCm3)} xăng ti mét khối, cần ${"%.0f".format(analysis.weightGramsPla)} gam nhựa PLA. Đã xuất file Binary STL tại ${file.name}."
                Toast.makeText(this@MicroRobotOverlayService, "Đã xuất STL: ${file.name}", Toast.LENGTH_SHORT).show()
                voiceEngine?.speak(speech)
            }
        }

        // 3.8 Báo cáo thị trường tổ chức (SMC & Quant Risk)
        hudView?.findViewById<Button>(R.id.btn_hud_institutional)?.setOnClickListener {
            closeQuickHud()
            setRobotState(RobotState.THINKING)
            Toast.makeText(this, "Nít: Đang tổng hợp báo cáo tổ chức SMC & Quant...", Toast.LENGTH_SHORT).show()
            serviceScope.launch {
                val dossier = com.hypernexus.nit.finance.InstitutionalMarketAnalyzer.analyzeInstitutionalMarket("BTC")
                val voiceBriefing = dossier.formatVoiceBriefing()
                Toast.makeText(this@MicroRobotOverlayService, "Báo cáo: ${dossier.bias.vietnamese} (${dossier.compositeScore}/100)", Toast.LENGTH_LONG).show()
                voiceEngine?.speak(voiceBriefing)
            }
        }

        // 3.9 Xưởng Lập Trình Web (HTML5/JS Sandbox)
        hudView?.findViewById<Button>(R.id.btn_hud_web_studio)?.setOnClickListener {
            closeQuickHud()
            setRobotState(RobotState.ACTION)
            Toast.makeText(this, "Nít: Đang lập trình web & khởi động Live Sandbox 120Hz...", Toast.LENGTH_SHORT).show()
            serviceScope.launch {
                val template = com.hypernexus.nit.web.WebDevelopmentEngine.WebProjectTemplate.LANDING_PAGE_SAAS
                val project = com.hypernexus.nit.web.WebDevelopmentEngine.generateProject(template)
                val validation = com.hypernexus.nit.web.WebDevelopmentEngine.validateWebCode(project)
                com.hypernexus.nit.web.WebDevelopmentEngine.exportProjectToDisk(this@MicroRobotOverlayService, project)
                com.hypernexus.nit.web.LocalWebSandboxServer.startServer(project)
                val url = com.hypernexus.nit.web.LocalWebSandboxServer.getServerUrl()
                val msg = "Đã tạo web ${project.title} (${validation.qualityScore}/100 W3C). Máy chủ: $url"
                Toast.makeText(this@MicroRobotOverlayService, msg, Toast.LENGTH_LONG).show()
                voiceEngine?.speak("Đã lập trình xong trang web và mở máy chủ sandbox cục bộ.")
            }
        }

        // 3.10 Lập trình Game Web 120 FPS
        hudView?.findViewById<Button>(R.id.btn_hud_web_game)?.setOnClickListener {
            closeQuickHud()
            setRobotState(RobotState.ACTION)
            Toast.makeText(this, "Nít: Đang lập trình game Arcade 120 FPS...", Toast.LENGTH_SHORT).show()
            serviceScope.launch {
                val genre = com.hypernexus.nit.web.WebGameDevelopmentEngine.WebGameGenre.CYBER_SPACE_SHOOTER
                val project = com.hypernexus.nit.web.WebGameDevelopmentEngine.generateGameProject(genre)
                val validation = com.hypernexus.nit.web.WebGameDevelopmentEngine.validateGameCode(project)
                com.hypernexus.nit.web.WebDevelopmentEngine.exportProjectToDisk(this@MicroRobotOverlayService, project)
                com.hypernexus.nit.web.LocalWebSandboxServer.startServer(project)
                val url = com.hypernexus.nit.web.LocalWebSandboxServer.getServerUrl()
                val msg = "Đã tạo game ${genre.displayName} (${validation.qualityScore}/100, 120 FPS). Máy chủ: $url"
                Toast.makeText(this@MicroRobotOverlayService, msg, Toast.LENGTH_LONG).show()
                voiceEngine?.speak("Đã lập trình xong game ${genre.displayName} 120 FPS.")
            }
        }

        // 4. Ra lệnh giọng nói
        hudView?.findViewById<Button>(R.id.btn_hud_voice)?.setOnClickListener {
            closeQuickHud()
            setRobotState(RobotState.LISTENING)
            voiceEngine?.startListeningToUser()
        }

        // 5. Ngủ sâu (Giải phóng RAM)
        hudView?.findViewById<Button>(R.id.btn_hud_sleep)?.setOnClickListener {
            closeQuickHud()
            LlamaEngine.unloadModel()
            setRobotState(RobotState.SLEEP)
            Toast.makeText(this, "Nít: Đã kích hoạt chế độ ngủ sâu, RAM được giải phóng!", Toast.LENGTH_SHORT).show()
        }

        windowManager?.addView(hudView, hudParams)
        isHudVisible = true
    }

    private fun closeQuickHud() {
        hudView?.let {
            windowManager?.removeView(it)
            hudView = null
        }
        isHudVisible = false
    }

    fun setRobotState(state: RobotState) {
        mainHandler.post {
            eyeLedView?.setBackgroundColor(state.ledColor)
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        closeQuickHud()
        gestureDriver?.stop()
        gestureDriver = null
        floatingAnimator?.cancel()
        overlayView?.let { windowManager?.removeView(it) }
        voiceEngine?.destroy()
        instance = null
    }
}
