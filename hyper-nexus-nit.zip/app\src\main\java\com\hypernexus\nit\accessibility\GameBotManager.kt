package com.hypernexus.nit.accessibility

import android.os.Handler
import android.os.Looper
import kotlin.random.Random

object GameBotManager {

    private val mainHandler = Handler(Looper.getMainLooper())
    private var isBotRunning = false

    /**
     * Tự động combo chiêu thức trong game với độ trễ ngẫu nhiên (Anti-detection)
     * Thao tác chạm: Skill 1 -> Skill 2 -> Đánh thường -> Né đòn
     */
    fun startAutoCombatCombo(onStop: (() -> Unit)? = null) {
        val service = NitAccessibilityService.instance ?: return
        isBotRunning = true

        val dm = service.resources.displayMetrics
        val width = dm.widthPixels.toFloat()
        val height = dm.heightPixels.toFloat()

        // Tọa độ các nút kỹ năng chuẩn trong game MOBA / RPG di động
        val skill1X = width * 0.82f
        val skill1Y = height * 0.88f

        val skill2X = width * 0.88f
        val skill2Y = height * 0.78f

        val attackX = width * 0.90f
        val attackY = height * 0.88f

        fun executeNextStep(step: Int) {
            if (!isBotRunning) {
                onStop?.invoke()
                return
            }

            when (step) {
                0 -> {
                    // Bấm Chiêu 1
                    service.performClick(skill1X, skill1Y) {
                        mainHandler.postDelayed({ executeNextStep(1) }, 150L + Random.nextLong(20, 50))
                    }
                }
                1 -> {
                    // Bấm Chiêu 2
                    service.performClick(skill2X, skill2Y) {
                        mainHandler.postDelayed({ executeNextStep(2) }, 180L + Random.nextLong(20, 50))
                    }
                }
                2 -> {
                    // Đánh thường 3 lần liên tiếp
                    service.performClick(attackX, attackY) {
                        mainHandler.postDelayed({ executeNextStep(3) }, 250L)
                    }
                }
                3 -> {
                    // Né đòn (Vuốt ngược hướng)
                    service.performSwipe(width * 0.2f, height * 0.7f, width * 0.1f, height * 0.7f, 150)
                    mainHandler.postDelayed({ executeNextStep(0) }, 1200L)
                }
            }
        }

        executeNextStep(0)
    }

    fun stopBot() {
        isBotRunning = false
    }
}
