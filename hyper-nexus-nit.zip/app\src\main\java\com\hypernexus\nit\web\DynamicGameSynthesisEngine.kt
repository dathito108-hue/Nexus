package com.hypernexus.nit.web

import android.content.Context
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.util.UUID
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * ĐỘNG CƠ SINH GAME WEB THEO YÊU CẦU NGƯỜI DÙNG (PROMPT-DRIVEN DYNAMIC GAME SYNTHESIS ENGINE)
 * Không bị bó buộc vào các mẫu cố định; tự động phân tích ngôn ngữ tự nhiên tiếng Việt,
 * bóc tách cơ chế (Mechanics), luật chơi (Rules), điều khiển (Controls), đối tượng tương tác,
 * đồ họa Canvas 2D/3D thủ tục và tổng hợp mã nguồn JavaScript ES2024 độc bản chạy ở 120 FPS.
 */
object DynamicGameSynthesisEngine {

    private const val TAG = "DynamicGameSynth"

    enum class GameArchetype(val code: String, val displayName: String) {
        CAR_HIGHWAY_RUNNER("CAR_HIGHWAY_RUNNER", "Đua Xe Tránh Chướng Ngại Vật & Thu Thập Xăng"),
        EAT_AND_GROW_EVOLUTION("EAT_AND_GROW_EVOLUTION", "Sinh Tồn Cá Lớn Nuốt Cá Bé / Hấp Thụ Năng Lượng"),
        COSMIC_DODGE_AND_COLLECT("COSMIC_DODGE_AND_COLLECT", "Né Thiên Thạch, Nhặt Ngọc & Lá Chắn Năng Lượng"),
        ARENA_TWIN_STICK_SURVIVAL("ARENA_TWIN_STICK_SURVIVAL", "Đấu Trường Sinh Tồn 360 Độ Bắn Quái Bao Vây"),
        GRAVITY_RUNNER_OBSTACLES("GRAVITY_RUNNER_OBSTACLES", "Nhảy Vượt Chướng Ngại Vật Trọng Lực 2D"),
        TARGET_REFLEX_TAPPER("TARGET_REFLEX_TAPPER", "Phản Xạ Bắn Mục Tiêu Nhanh Tốc Độ Cao")
    }

    data class ParsedGameSpec(
        val userPrompt: String,
        val archetype: GameArchetype,
        val gameTitle: String,
        val playerLabel: String,
        val playerColor: String,
        val hazardLabel: String,
        val hazardColor: String,
        val collectibleLabel: String,
        val collectibleColor: String,
        val hasShieldPowerup: Boolean,
        val hasShootingMechanic: Boolean,
        val hasNitroBoost: Boolean,
        val backgroundStyle: String,
        val winConditionDesc: String
    )

    /**
     * KIỂM TRA XEM KHẨU LỆNH CÓ PHẢI YÊU CẦU LẬP TRÌNH GAME THEO MÔ TẢ ĐỘNG HAY KHÔNG
     */
    fun isCustomGamePrompt(prompt: String): Boolean {
        val lower = prompt.lowercase().trim()
        val hasCustomKeywords = lower.contains("mô tả") || lower.contains("theo ý") || lower.contains("tùy biến") ||
                lower.contains("cá") || lower.contains("nuốt") || lower.contains("đua xe") || lower.contains("ô tô") ||
                lower.contains("xe tải") || lower.contains("xăng") || lower.contains("đấu trường") ||
                lower.contains("sinh tồn") || lower.contains("zombie") || lower.contains("quái vật") ||
                lower.contains("bao vây") || lower.contains("thiên thạch") || lower.contains("phản xạ") ||
                lower.contains("mục tiêu") || lower.contains("khiên") || lower.contains("lá chắn") ||
                lower.contains("nitro") || lower.contains("tăng tốc") || lower.contains("độc bản")
        val isGameRequest = lower.contains("game") || lower.contains("trò chơi")
        return isGameRequest && hasCustomKeywords
    }

    /**
     * PHÂN TÍCH NGỮ NGHĨA KHẨU LỆNH NGƯỜI DÙNG ĐỂ TRÍCH XUẤT CƠ CHẾ GAME
     */
    fun parseGameSpecFromPrompt(prompt: String): ParsedGameSpec {
        val lower = prompt.lowercase().trim()

        // 1. Phân loại Archetype theo từ khóa hành động trong câu lệnh
        val archetype = when {
            lower.contains("xe") || lower.contains("đua xe") || lower.contains("ô tô") || lower.contains("giao thông") || lower.contains("đường cao tốc") -> {
                GameArchetype.CAR_HIGHWAY_RUNNER
            }
            lower.contains("cá") || lower.contains("nuốt") || lower.contains("ăn") || lower.contains("lớn") || lower.contains("bé") || lower.contains("tiến hóa") || lower.contains("hấp thụ") -> {
                GameArchetype.EAT_AND_GROW_EVOLUTION
            }
            lower.contains("đấu trường") || lower.contains("sinh tồn") || lower.contains("quái vật") || lower.contains("bao vây") || lower.contains("zombie") || lower.contains("quái") -> {
                GameArchetype.ARENA_TWIN_STICK_SURVIVAL
            }
            lower.contains("nhảy") || lower.contains("flappy") || lower.contains("trọng lực") || lower.contains("chạy bộ") || lower.contains("ninja") -> {
                GameArchetype.GRAVITY_RUNNER_OBSTACLES
            }
            lower.contains("đập") || lower.contains("chém") || lower.contains("bấm nhanh") || lower.contains("phản xạ") || lower.contains("mục tiêu") -> {
                GameArchetype.TARGET_REFLEX_TAPPER
            }
            else -> GameArchetype.COSMIC_DODGE_AND_COLLECT
        }

        // 2. Bóc tách cơ chế phụ trợ
        val hasShield = lower.contains("khiên") || lower.contains("bảo vệ") || lower.contains("bất tử") || lower.contains("hào quang")
        val hasShooting = lower.contains("bắn") || lower.contains("đạn") || lower.contains("súng") || lower.contains("laser") || lower.contains("tiêu diệt")
        val hasNitro = lower.contains("tăng tốc") || lower.contains("nitro") || lower.contains("turbo") || lower.contains("nhanh hơn")

        // 3. Bóc tách màu sắc & thẩm mỹ
        val playerColor = when {
            lower.contains("đỏ") -> "#FF0055"
            lower.contains("xanh lá") -> "#14F195"
            lower.contains("vàng") -> "#FFD700"
            lower.contains("tím") -> "#A855F7"
            else -> "#00E5FF" // Neon Cyan mặc định
        }

        val title = extractGameTitle(prompt, archetype)

        val playerLabel = when (archetype) {
            GameArchetype.CAR_HIGHWAY_RUNNER -> "Cyber Sports Car"
            GameArchetype.EAT_AND_GROW_EVOLUTION -> "Neon Cyber Fish"
            GameArchetype.ARENA_TWIN_STICK_SURVIVAL -> "Arena Mech Survivor"
            GameArchetype.GRAVITY_RUNNER_OBSTACLES -> "Quantum Jumper"
            GameArchetype.TARGET_REFLEX_TAPPER -> "Laser Crosshair"
            GameArchetype.COSMIC_DODGE_AND_COLLECT -> "Space Explorer Pod"
        }

        val hazardLabel = when (archetype) {
            GameArchetype.CAR_HIGHWAY_RUNNER -> "Xe Tải & Chướng Ngại Vật"
            GameArchetype.EAT_AND_GROW_EVOLUTION -> "Kẻ Săn Mồi Cỡ Lớn"
            GameArchetype.ARENA_TWIN_STICK_SURVIVAL -> "Bầy Quái Vật Đột Biến"
            GameArchetype.GRAVITY_RUNNER_OBSTACLES -> "Cột Chông Gai Laser"
            GameArchetype.TARGET_REFLEX_TAPPER -> "Bom Nổ Đỏ"
            GameArchetype.COSMIC_DODGE_AND_COLLECT -> "Thiên Thạch & Bão Năng Lượng"
        }

        val collectibleLabel = when (archetype) {
            GameArchetype.CAR_HIGHWAY_RUNNER -> "Bình Nhiên Liệu Nitro"
            GameArchetype.EAT_AND_GROW_EVOLUTION -> "Con Mồi Nhỏ Hơn"
            GameArchetype.ARENA_TWIN_STICK_SURVIVAL -> "Hộp Tiếp Tế Đạn Dược"
            GameArchetype.GRAVITY_RUNNER_OBSTACLES -> "Lõi Năng Lượng Vàng"
            GameArchetype.TARGET_REFLEX_TAPPER -> "Mục Tiêu Điểm Thưởng"
            GameArchetype.COSMIC_DODGE_AND_COLLECT -> "Tinh Thể Vàng & Khiên"
        }

        return ParsedGameSpec(
            userPrompt = prompt,
            archetype = archetype,
            gameTitle = title,
            playerLabel = playerLabel,
            playerColor = playerColor,
            hazardLabel = hazardLabel,
            hazardColor = "#FF3366",
            collectibleLabel = collectibleLabel,
            collectibleColor = "#FFD700",
            hasShieldPowerup = hasShield,
            hasShootingMechanic = hasShooting,
            hasNitroBoost = hasNitro,
            backgroundStyle = "#070A12",
            winConditionDesc = "Sống sót và đạt điểm kỷ lục High Score"
        )
    }

    /**
     * TỔNG HỢP TOÀN BỘ MÃ NGUỒN GAME ĐA TỆP DỰA TRÊN THÔNG SỐ BÓC TÁCH
     */
    fun synthesizeGameFromPrompt(
        context: Context? = null,
        prompt: String
    ): WebDevelopmentEngine.WebProject {
        val spec = parseGameSpecFromPrompt(prompt)
        val projectName = "nit_custom_game_${System.currentTimeMillis() % 100000}"

        val files = mutableMapOf<String, WebDevelopmentEngine.WebFile>()

        files["index.html"] = WebDevelopmentEngine.WebFile(
            "index.html",
            buildDynamicGameHtml(spec),
            "text/html"
        )

        files["style.css"] = WebDevelopmentEngine.WebFile(
            "style.css",
            buildDynamicGameCss(spec),
            "text/css"
        )

        files["app.js"] = WebDevelopmentEngine.WebFile(
            "app.js",
            buildDynamicGameJs(spec),
            "application/javascript"
        )

        files["manifest.json"] = WebDevelopmentEngine.WebFile(
            "manifest.json",
            """
            {
              "short_name": "NitCustomGame",
              "name": "${spec.gameTitle}",
              "start_url": "./index.html",
              "background_color": "${spec.backgroundStyle}",
              "theme_color": "${spec.playerColor}",
              "display": "standalone",
              "orientation": "landscape"
            }
            """.trimIndent(),
            "application/json"
        )

        val project = WebDevelopmentEngine.WebProject(
            name = projectName,
            title = spec.gameTitle,
            template = WebDevelopmentEngine.WebProjectTemplate.RETRO_WEB_GAME,
            files = files
        )

        return project
    }

    private fun extractGameTitle(prompt: String, archetype: GameArchetype): String {
        val cleaned = prompt.replace("lập trình", "", ignoreCase = true)
            .replace("tạo game", "", ignoreCase = true)
            .replace("code game", "", ignoreCase = true)
            .replace("làm game", "", ignoreCase = true)
            .replace("game web", "", ignoreCase = true)
            .trim()

        return if (cleaned.length in 4..35) {
            cleaned.replaceFirstChar { it.uppercase() }
        } else {
            archetype.displayName
        }
    }

    // =========================================================================
    // MÃ HTML ĐỘNG ĐƯỢC CẤU HÌNH THEO SPEC
    // =========================================================================
    private fun buildDynamicGameHtml(spec: ParsedGameSpec): String = """
<!DOCTYPE html>
<html lang="vi">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>${spec.gameTitle}</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <div id="game-stage">
        <!-- TOP HUD -->
        <header class="hud-header">
            <div class="hud-group">
                <span class="hud-title">${spec.gameTitle.uppercase()}</span>
                <span> | ĐIỂM: <strong id="score-el">0</strong></span>
                <span> | CAO NHẤT: <strong id="hiscore-el">0</strong></span>
            </div>
            <div class="hud-group">
                <span id="player-status-badge">MÁU: 100%</span>
                <span id="fps-badge">● 120 FPS MALI</span>
            </div>
        </header>

        <!-- GAME CANVAS 120 FPS -->
        <canvas id="gameCanvas" width="900" height="600"></canvas>

        <!-- DYNAMIC ON-SCREEN TOUCH JOYSTICK / ACTION BUTTONS -->
        <div class="touch-layer" id="touch-controls">
            <div class="touch-left-dpad">
                <button type="button" id="touch-left" class="t-btn">◀</button>
                <button type="button" id="touch-right" class="t-btn">▶</button>
            </div>
            <div class="touch-right-actions">
                ${if (spec.hasShieldPowerup) "<button type=\"button\" id=\"touch-shield\" class=\"t-btn t-shield\">🛡️</button>" else ""}
                ${if (spec.hasShootingMechanic) "<button type=\"button\" id=\"touch-fire\" class=\"t-btn t-fire\">🔥</button>" else ""}
                ${if (spec.hasNitroBoost) "<button type=\"button\" id=\"touch-boost\" class=\"t-btn t-boost\">⚡</button>" else ""}
                <button type="button" id="touch-action" class="t-btn t-main">🕹️</button>
            </div>
        </div>

        <!-- GAME OVER MODAL -->
        <div id="gameover-modal" class="modal-overlay hidden">
            <div class="modal-box">
                <h2>KẾT THÚC LƯỢT CHƠI</h2>
                <p>Điểm số của bạn: <span id="final-score" class="score-highlight">0</span></p>
                <p class="prompt-hint">Yêu cầu đã lập trình: "${spec.userPrompt}"</p>
                <button type="button" id="btn-restart" class="btn-play-again">Chơi Lại Ngay (Space / Chạm)</button>
            </div>
        </div>
    </div>
    <script src="app.js"></script>
</body>
</html>
    """.trimIndent()

    // =========================================================================
    // CSS ĐỘNG
    // =========================================================================
    private fun buildDynamicGameCss(spec: ParsedGameSpec): String = """
:root {
    --player-color: ${spec.playerColor};
    --hazard-color: ${spec.hazardColor};
    --collectible-color: ${spec.collectibleColor};
    --bg-dark: ${spec.backgroundStyle};
}
* { margin: 0; padding: 0; box-sizing: border-box; user-select: none; -webkit-user-select: none; }
body {
    background: #020408;
    color: #FFF;
    font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
    overflow: hidden;
    width: 100vw;
    height: 100vh;
    display: flex;
    justify-content: center;
    align-items: center;
    touch-action: none;
}
#game-stage {
    position: relative;
    width: 100%;
    height: 100%;
    max-width: 900px;
    max-height: 600px;
    display: flex;
    justify-content: center;
    align-items: center;
}
canvas {
    background: var(--bg-dark);
    border: 2px solid var(--player-color);
    border-radius: 10px;
    box-shadow: 0 0 30px rgba(0, 229, 255, 0.2);
    display: block;
    width: 100%;
    height: 100%;
    object-fit: contain;
}
.hud-header {
    position: absolute; top: 12px; left: 16px; right: 16px;
    display: flex; justify-content: space-between; align-items: center;
    pointer-events: none; font-size: 0.9rem; font-weight: 800;
    text-shadow: 0 0 8px rgba(0,0,0,0.9); z-index: 20;
}
.hud-title { color: var(--player-color); }
#fps-badge { color: #14F195; }
#player-status-badge { color: #FF3366; margin-right: 12px; }

/* VIRTUAL TOUCH CONTROLS */
.touch-layer {
    position: absolute; bottom: 16px; left: 16px; right: 16px;
    display: flex; justify-content: space-between; pointer-events: none; z-index: 30;
}
.touch-left-dpad, .touch-right-actions { display: flex; gap: 10px; align-items: center; }
.t-btn {
    pointer-events: auto; width: 62px; height: 62px; border-radius: 50%;
    background: rgba(15, 23, 42, 0.7); border: 2px solid var(--player-color);
    color: #FFF; font-size: 1.25rem; font-weight: 900;
    display: flex; justify-content: center; align-items: center;
    box-shadow: 0 0 14px rgba(0, 229, 255, 0.25);
    touch-action: none;
}
.t-btn:active { background: var(--player-color); color: #000; transform: scale(0.92); }
.t-fire { border-color: #FF0055; }
.t-shield { border-color: #14F195; }
.t-boost { border-color: #FFD700; }
.t-main { background: rgba(0, 229, 255, 0.25); width: 68px; height: 68px; }

/* MODAL OVERLAY */
.modal-overlay {
    position: absolute; inset: 0; background: rgba(0,0,0,0.85);
    display: flex; justify-content: center; align-items: center; z-index: 50;
    backdrop-filter: blur(8px);
}
.modal-overlay.hidden { display: none; }
.modal-box {
    background: #0E1320; border: 2px solid var(--player-color); border-radius: 14px;
    padding: 2.2rem; text-align: center; max-width: 450px;
    box-shadow: 0 0 35px rgba(0, 229, 255, 0.3);
}
.modal-box h2 { color: #FF0055; font-size: 2rem; font-weight: 900; margin-bottom: 0.8rem; }
.score-highlight { color: #FFD700; font-size: 1.6rem; font-weight: 900; }
.prompt-hint { color: #94A3B8; font-size: 0.85rem; margin: 1rem 0; font-style: italic; }
.btn-play-again {
    background: var(--player-color); color: #000; border: none; padding: 12px 24px;
    border-radius: 8px; font-size: 1rem; font-weight: 800; cursor: pointer;
}
    """.trimIndent()

    // =========================================================================
    // JAVASCRIPT GAME ENGINE ĐỘNG ĐƯỢC TỔNG HỢP RIÊNG BIỆT THEO ARCHETYPE
    // =========================================================================
    private fun buildDynamicGameJs(spec: ParsedGameSpec): String = """
/**
 * DYNAMIC PROMPT-DRIVEN WEB GAME ENGINE - HYPER NEXUS
 * Prompt: "${spec.userPrompt.replace("\"", "\\\"")}"
 * Archetype: ${spec.archetype.code}
 */
document.addEventListener('DOMContentLoaded', () => {
    const canvas = document.getElementById('gameCanvas');
    const ctx = canvas.getContext('2d');

    // 1. WEB AUDIO API SYNTHESIZER
    let audioCtx = null;
    function getAudio() {
        if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
        return audioCtx;
    }
    function playSynthSound(freq, endFreq, dur = 0.15, type = 'sine', gainVal = 0.25) {
        try {
            const ac = getAudio();
            if (!ac) return;
            const osc = ac.createOscillator();
            const gain = ac.createGain();
            osc.type = type;
            osc.frequency.setValueAtTime(freq, ac.currentTime);
            if (endFreq) osc.frequency.exponentialRampToValueAtTime(Math.max(10, endFreq), ac.currentTime + dur);
            gain.gain.setValueAtTime(gainVal, ac.currentTime);
            gain.gain.linearRampToValueAtTime(0.01, ac.currentTime + dur);
            osc.connect(gain);
            gain.connect(ac.destination);
            osc.start();
            osc.stop(ac.currentTime + dur);
        } catch(e) {}
    }

    // 2. STATE & SPEC CONFIG
    let score = 0;
    let highScore = parseInt(localStorage.getItem('nit_custom_hiscore_${spec.archetype.code.lowercase()}') || '0');
    document.getElementById('hiscore-el').textContent = highScore;

    let isGameOver = false;
    let shieldActive = ${if (spec.hasShieldPowerup) "true" else "false"};
    let shieldDuration = 0;

    // 3. INPUT HANDLER (TOUCH + KEYBOARD)
    const keys = {};
    window.addEventListener('keydown', e => { keys[e.code] = true; });
    window.addEventListener('keyup', e => { keys[e.code] = false; });

    function bindTouch(id, code) {
        const el = document.getElementById(id);
        if (!el) return;
        el.addEventListener('pointerdown', e => { e.preventDefault(); keys[code] = true; });
        el.addEventListener('pointerup', e => { e.preventDefault(); keys[code] = false; });
        el.addEventListener('pointercancel', e => { e.preventDefault(); keys[code] = false; });
    }
    bindTouch('touch-left', 'ArrowLeft');
    bindTouch('touch-right', 'ArrowRight');
    bindTouch('touch-action', 'Space');
    bindTouch('touch-shield', 'KeyS');
    bindTouch('touch-fire', 'KeyF');
    bindTouch('touch-boost', 'ShiftLeft');

    // 4. ARCHETYPE SPECIFIC LOGIC
    ${buildArchetypeSpecificJsLogic(spec)}

    // 5. GAME OVER & RESTART
    function triggerGameOver() {
        if (isGameOver) return;
        isGameOver = true;
        playSynthSound(220, 40, 0.45, 'triangle', 0.4);
        if (score > highScore) {
            highScore = score;
            localStorage.setItem('nit_custom_hiscore_${spec.archetype.code.lowercase()}', highScore.toString());
            document.getElementById('hiscore-el').textContent = highScore;
        }
        document.getElementById('final-score').textContent = score;
        document.getElementById('gameover-modal').classList.remove('hidden');
    }

    document.getElementById('btn-restart')?.addEventListener('click', restartGame);
    window.addEventListener('keydown', e => {
        if (isGameOver && (e.code === 'Space' || e.code === 'Enter')) restartGame();
    });

    function restartGame() {
        document.getElementById('gameover-modal').classList.add('hidden');
        score = 0;
        document.getElementById('score-el').textContent = '0';
        isGameOver = false;
        resetArchetypeEntities();
        lastTime = performance.now();
        requestAnimationFrame(gameLoop);
    }

    // 6. 120 FPS DELTA-TIME GAME LOOP
    let lastTime = performance.now();
    let frameCount = 0, lastFpsTime = performance.now();

    function gameLoop(now) {
        const dt = Math.min((now - lastTime) / 1000, 0.1);
        lastTime = now;

        // Telemetry FPS counter
        frameCount++;
        if (now - lastFpsTime >= 500) {
            const fps = Math.round((frameCount * 1000) / (now - lastFpsTime));
            document.getElementById('fps-badge').textContent = '● ' + fps + ' FPS MALI';
            frameCount = 0;
            lastFpsTime = now;
        }

        if (!isGameOver) {
            update(dt);
            render();
            requestAnimationFrame(gameLoop);
        }
    }

    requestAnimationFrame(gameLoop);
});
    """.trimIndent()

    private fun buildArchetypeSpecificJsLogic(spec: ParsedGameSpec): String {
        return when (spec.archetype) {
            GameArchetype.CAR_HIGHWAY_RUNNER -> """
    // --- CAR HIGHWAY RUNNER ---
    let player = { x: 420, y: 480, w: 46, h: 70, speed: 450 };
    let traffic = [];
    let fuelItems = [];
    let roadOffsetY = 0;
    let spawnTimer = 0;

    function resetArchetypeEntities() {
        player.x = 420;
        player.y = 480;
        traffic = [];
        fuelItems = [];
    }

    function update(dt) {
        // Highway speed
        const speedMultiplier = (keys['ShiftLeft'] || keys['ArrowUp']) ? 1.6 : 1.0;
        roadOffsetY = (roadOffsetY + 380 * speedMultiplier * dt) % 60;

        // Player lateral movement
        if (keys['ArrowLeft'] || keys['KeyA']) player.x -= player.speed * dt;
        if (keys['ArrowRight'] || keys['KeyD']) player.x += player.speed * dt;
        player.x = Math.max(160, Math.min(700, player.x));

        // Spawn traffic cars
        spawnTimer += dt;
        if (spawnTimer > (1.0 / speedMultiplier)) {
            spawnTimer = 0;
            const lanes = [220, 360, 500, 640];
            const laneX = lanes[Math.floor(Math.random() * lanes.length)];
            traffic.push({ x: laneX - 22, y: -80, w: 44, h: 68, vy: (160 + Math.random() * 90) * speedMultiplier });

            if (Math.random() > 0.4) {
                const fLane = lanes[Math.floor(Math.random() * lanes.length)];
                fuelItems.push({ x: fLane, y: -120, r: 14, vy: 260 * speedMultiplier });
            }
        }

        // Update traffic
        traffic.forEach(t => { t.y += t.vy * dt; });
        fuelItems.forEach(f => { f.y += f.vy * dt; });

        // Collect fuel
        fuelItems.forEach((f, idx) => {
            if (Math.hypot(player.x + player.w/2 - f.x, player.y + player.h/2 - f.y) < player.w/2 + f.r) {
                playSynthSound(600, 950, 0.12, 'sine');
                score += 50;
                document.getElementById('score-el').textContent = score;
                fuelItems.splice(idx, 1);
            }
        });

        // Collision with traffic cars
        traffic.forEach(t => {
            if (player.x < t.x + t.w && player.x + player.w > t.x &&
                player.y < t.y + t.h && player.y + player.h > t.y) {
                triggerGameOver();
            }
        });

        traffic = traffic.filter(t => t.y < 680);
        fuelItems = fuelItems.filter(f => f.y < 680);
        score += Math.round(dt * 15 * speedMultiplier);
        document.getElementById('score-el').textContent = score;
    }

    function render() {
        ctx.clearRect(0, 0, 900, 600);

        // Road Surface
        ctx.fillStyle = '#111827';
        ctx.fillRect(140, 0, 620, 600);

        // Grass / Borders
        ctx.fillStyle = '#064E3B';
        ctx.fillRect(0, 0, 140, 600);
        ctx.fillRect(760, 0, 140, 600);

        // Road Lane Dash Markings
        ctx.strokeStyle = '#F8FAFC';
        ctx.lineWidth = 4;
        ctx.setLineDash([30, 30]);
        ctx.lineDashOffset = -roadOffsetY;
        [290, 450, 610].forEach(lx => {
            ctx.beginPath();
            ctx.moveTo(lx, 0);
            ctx.lineTo(lx, 600);
            ctx.stroke();
        });
        ctx.setLineDash([]); // Reset

        // Fuel Collectibles (Gold Jerry Cans)
        fuelItems.forEach(f => {
            ctx.fillStyle = '${spec.collectibleColor}';
            ctx.shadowColor = '${spec.collectibleColor}';
            ctx.shadowBlur = 10;
            ctx.beginPath();
            ctx.arc(f.x, f.y, f.r, 0, Math.PI * 2);
            ctx.fill();
        });

        // Traffic Obstacles
        traffic.forEach(t => {
            ctx.fillStyle = '${spec.hazardColor}';
            ctx.shadowColor = '${spec.hazardColor}';
            ctx.shadowBlur = 12;
            ctx.fillRect(t.x, t.y, t.w, t.h);
        });

        // Player Sports Car
        ctx.fillStyle = '${spec.playerColor}';
        ctx.shadowColor = '${spec.playerColor}';
        ctx.shadowBlur = 16;
        ctx.fillRect(player.x, player.y, player.w, player.h);

        // Car Headlights
        ctx.fillStyle = '#FFFE';
        ctx.fillRect(player.x + 4, player.y - 12, 10, 12);
        ctx.fillRect(player.x + player.w - 14, player.y - 12, 10, 12);
        ctx.shadowBlur = 0;
    }
            """.trimIndent()

            GameArchetype.EAT_AND_GROW_EVOLUTION -> """
    // --- EAT AND GROW (CÁ LỚN NUỐT CÁ BÉ) ---
    let player = { x: 450, y: 300, r: 18, speed: 320 };
    let fishes = [];
    let spawnTimer = 0;

    function resetArchetypeEntities() {
        player.x = 450;
        player.y = 300;
        player.r = 18;
        fishes = [];
    }

    function update(dt) {
        // Player moves toward pointer or arrow keys
        if (keys['ArrowLeft'] || keys['KeyA']) player.x -= player.speed * dt;
        if (keys['ArrowRight'] || keys['KeyD']) player.x += player.speed * dt;
        if (keys['ArrowUp'] || keys['KeyW']) player.y -= player.speed * dt;
        if (keys['ArrowDown'] || keys['KeyS']) player.y += player.speed * dt;
        player.x = Math.max(player.r, Math.min(900 - player.r, player.x));
        player.y = Math.max(player.r, Math.min(600 - player.r, player.y));

        // Spawn other fishes (smaller prey or bigger predators)
        spawnTimer += dt;
        if (spawnTimer > 0.45) {
            spawnTimer = 0;
            const fromLeft = Math.random() > 0.5;
            const sizeVariance = (Math.random() - 0.42); // Can be smaller or bigger
            const radius = Math.max(8, Math.min(65, player.r + sizeVariance * 28));
            fishes.push({
                x: fromLeft ? -40 : 940,
                y: Math.random() * 560 + 20,
                r: radius,
                vx: (fromLeft ? 1 : -1) * (110 + Math.random() * 120),
                color: radius < player.r ? '${spec.collectibleColor}' : '${spec.hazardColor}'
            });
        }

        fishes.forEach(f => { f.x += f.vx * dt; });

        // Check eating & collisions
        fishes.forEach((f, idx) => {
            const dist = Math.hypot(player.x - f.x, player.y - f.y);
            if (dist < player.r + f.r) {
                if (player.r >= f.r) {
                    // Eat smaller
                    playSynthSound(440, 880, 0.1, 'sine');
                    player.r = Math.min(85, player.r + f.r * 0.12);
                    score += Math.round(f.r * 5);
                    document.getElementById('score-el').textContent = score;
                    fishes.splice(idx, 1);
                } else {
                    // Eaten by bigger
                    triggerGameOver();
                }
            }
        });

        fishes = fishes.filter(f => f.x > -60 && f.x < 960);
    }

    function render() {
        ctx.clearRect(0, 0, 900, 600);

        // Water particles / bubbles
        ctx.fillStyle = '#0F2038';
        ctx.fillRect(0, 0, 900, 600);

        // Other Fishes
        fishes.forEach(f => {
            ctx.fillStyle = f.color;
            ctx.shadowColor = f.color;
            ctx.shadowBlur = 8;
            ctx.beginPath();
            ctx.arc(f.x, f.y, f.r, 0, Math.PI * 2);
            ctx.fill();
        });

        // Player Fish
        ctx.fillStyle = '${spec.playerColor}';
        ctx.shadowColor = '${spec.playerColor}';
        ctx.shadowBlur = 18;
        ctx.beginPath();
        ctx.arc(player.x, player.y, player.r, 0, Math.PI * 2);
        ctx.fill();

        // Eye indicator
        ctx.fillStyle = '#000';
        ctx.beginPath();
        ctx.arc(player.x + player.r * 0.35, player.y - player.r * 0.15, Math.max(3, player.r * 0.2), 0, Math.PI * 2);
        ctx.fill();
        ctx.shadowBlur = 0;
    }
            """.trimIndent()

            GameArchetype.ARENA_TWIN_STICK_SURVIVAL -> """
    // --- ARENA TWIN-STICK SURVIVAL ---
    let player = { x: 450, y: 300, r: 16, hp: 100, speed: 280 };
    let bullets = [];
    let monsters = [];
    let spawnTimer = 0;
    let shootTimer = 0;

    function resetArchetypeEntities() {
        player.x = 450;
        player.y = 300;
        player.hp = 100;
        bullets = [];
        monsters = [];
    }

    function update(dt) {
        if (keys['ArrowLeft'] || keys['KeyA']) player.x -= player.speed * dt;
        if (keys['ArrowRight'] || keys['KeyD']) player.x += player.speed * dt;
        if (keys['ArrowUp'] || keys['KeyW']) player.y -= player.speed * dt;
        if (keys['ArrowDown'] || keys['KeyS']) player.y += player.speed * dt;
        player.x = Math.max(20, Math.min(880, player.x));
        player.y = Math.max(20, Math.min(580, player.y));

        // Auto-fire or space fire toward nearest monster
        shootTimer -= dt;
        if ((keys['Space'] || keys['KeyF'] || true) && shootTimer <= 0 && monsters.length > 0) {
            let nearest = monsters[0];
            let minDist = 9999;
            monsters.forEach(m => {
                const d = Math.hypot(m.x - player.x, m.y - player.y);
                if (d < minDist) { minDist = d; nearest = m; }
            });
            if (minDist < 450) {
                const angle = Math.atan2(nearest.y - player.y, nearest.x - player.x);
                bullets.push({ x: player.x, y: player.y, vx: Math.cos(angle) * 650, vy: Math.sin(angle) * 650 });
                playSynthSound(900, 300, 0.08, 'sawtooth', 0.15);
                shootTimer = 0.22;
            }
        }

        // Spawn monsters from borders
        spawnTimer += dt;
        if (spawnTimer > 0.6) {
            spawnTimer = 0;
            const side = Math.floor(Math.random() * 4);
            let mx = 0, my = 0;
            if (side === 0) { mx = Math.random() * 900; my = -20; }
            else if (side === 1) { mx = 920; my = Math.random() * 600; }
            else if (side === 2) { mx = Math.random() * 900; my = 620; }
            else { mx = -20; my = Math.random() * 600; }
            monsters.push({ x: mx, y: my, r: 14, speed: 110 + Math.random() * 80, hp: 2 });
        }

        // Update bullets
        bullets.forEach(b => { b.x += b.vx * dt; b.y += b.vy * dt; });
        bullets = bullets.filter(b => b.x > 0 && b.x < 900 && b.y > 0 && b.y < 600);

        // Move monsters toward player
        monsters.forEach(m => {
            const angle = Math.atan2(player.y - m.y, player.x - m.x);
            m.x += Math.cos(angle) * m.speed * dt;
            m.y += Math.sin(angle) * m.speed * dt;

            // Attack player
            if (Math.hypot(m.x - player.x, m.y - player.y) < m.r + player.r) {
                player.hp -= 20 * dt;
                document.getElementById('player-status-badge').textContent = 'MÁU: ' + Math.max(0, Math.round(player.hp)) + '%';
                if (player.hp <= 0) triggerGameOver();
            }
        });

        // Bullet - Monster collision
        bullets.forEach((b, bIdx) => {
            monsters.forEach((m, mIdx) => {
                if (Math.hypot(b.x - m.x, b.y - m.y) < m.r + 5) {
                    m.hp--;
                    b.x = -999;
                    if (m.hp <= 0) {
                        playSynthSound(120, 30, 0.15, 'triangle');
                        score += 35;
                        document.getElementById('score-el').textContent = score;
                        monsters.splice(mIdx, 1);
                    }
                }
            });
        });
    }

    function render() {
        ctx.clearRect(0, 0, 900, 600);

        // Arena Grid
        ctx.strokeStyle = '#1E293B';
        ctx.lineWidth = 1;
        for (let x = 0; x < 900; x += 60) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, 600); ctx.stroke(); }
        for (let y = 0; y < 600; y += 60) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(900, y); ctx.stroke(); }

        // Bullets
        ctx.fillStyle = '#00E5FF';
        bullets.forEach(b => {
            ctx.beginPath(); ctx.arc(b.x, b.y, 4, 0, Math.PI * 2); ctx.fill();
        });

        // Monsters
        monsters.forEach(m => {
            ctx.fillStyle = '${spec.hazardColor}';
            ctx.beginPath(); ctx.arc(m.x, m.y, m.r, 0, Math.PI * 2); ctx.fill();
        });

        // Player
        ctx.fillStyle = '${spec.playerColor}';
        ctx.shadowColor = '${spec.playerColor}';
        ctx.shadowBlur = 12;
        ctx.beginPath(); ctx.arc(player.x, player.y, player.r, 0, Math.PI * 2); ctx.fill();
        ctx.shadowBlur = 0;
    }
            """.trimIndent()

            else -> """
    // --- COSMIC DODGE & COLLECT (DEFAULT FULL-CUSTOM DYNAMIC) ---
    let player = { x: 420, y: 500, w: 42, h: 42, speed: 400 };
    let meteors = [];
    let crystals = [];
    let spawnTimer = 0;

    function resetArchetypeEntities() {
        player.x = 420;
        player.y = 500;
        meteors = [];
        crystals = [];
    }

    function update(dt) {
        if (keys['ArrowLeft'] || keys['KeyA']) player.x -= player.speed * dt;
        if (keys['ArrowRight'] || keys['KeyD']) player.x += player.speed * dt;
        if (keys['ArrowUp'] || keys['KeyW']) player.y -= player.speed * dt;
        if (keys['ArrowDown'] || keys['KeyS']) player.y += player.speed * dt;
        player.x = Math.max(10, Math.min(850, player.x));
        player.y = Math.max(10, Math.min(550, player.y));

        // Shield powerup toggle
        if (keys['KeyS']) {
            shieldActive = true;
            shieldDuration = 4.0;
            keys['KeyS'] = false;
        }
        if (shieldDuration > 0) {
            shieldDuration -= dt;
            if (shieldDuration <= 0) shieldActive = false;
        }

        // Spawn Falling Objects
        spawnTimer += dt;
        if (spawnTimer > 0.4) {
            spawnTimer = 0;
            meteors.push({
                x: Math.random() * 860,
                y: -30,
                r: 16 + Math.random() * 16,
                vy: 180 + Math.random() * 160
            });
            if (Math.random() > 0.3) {
                crystals.push({
                    x: Math.random() * 860,
                    y: -30,
                    r: 10,
                    vy: 150 + Math.random() * 100
                });
            }
        }

        meteors.forEach(m => { m.y += m.vy * dt; });
        crystals.forEach(c => { c.y += c.vy * dt; });

        // Collect Crystals
        crystals.forEach((c, idx) => {
            if (Math.hypot(player.x + 21 - c.x, player.y + 21 - c.y) < 21 + c.r) {
                playSynthSound(580, 1100, 0.12, 'sine');
                score += 25;
                document.getElementById('score-el').textContent = score;
                crystals.splice(idx, 1);
            }
        });

        // Collide with Meteors
        meteors.forEach(m => {
            if (Math.hypot(player.x + 21 - m.x, player.y + 21 - m.y) < 21 + m.r) {
                if (shieldActive) {
                    playSynthSound(200, 50, 0.1, 'square');
                    m.y = 999;
                } else {
                    triggerGameOver();
                }
            }
        });

        meteors = meteors.filter(m => m.y < 650);
        crystals = crystals.filter(c => c.y < 650);
    }

    function render() {
        ctx.clearRect(0, 0, 900, 600);

        // Crystals (Gold/Diamond)
        crystals.forEach(c => {
            ctx.fillStyle = '${spec.collectibleColor}';
            ctx.shadowColor = '${spec.collectibleColor}';
            ctx.shadowBlur = 10;
            ctx.beginPath(); ctx.arc(c.x, c.y, c.r, 0, Math.PI * 2); ctx.fill();
        });

        // Meteors
        meteors.forEach(m => {
            ctx.fillStyle = '${spec.hazardColor}';
            ctx.shadowColor = '${spec.hazardColor}';
            ctx.shadowBlur = 12;
            ctx.beginPath(); ctx.arc(m.x, m.y, m.r, 0, Math.PI * 2); ctx.fill();
        });

        // Player
        ctx.fillStyle = '${spec.playerColor}';
        ctx.shadowColor = '${spec.playerColor}';
        ctx.shadowBlur = 16;
        ctx.fillRect(player.x, player.y, player.w, player.h);

        // Active Shield Glow
        if (shieldActive) {
            ctx.strokeStyle = '#14F195';
            ctx.lineWidth = 3;
            ctx.beginPath();
            ctx.arc(player.x + 21, player.y + 21, 32, 0, Math.PI * 2);
            ctx.stroke();
        }
        ctx.shadowBlur = 0;
    }
            """.trimIndent()
        }
    }
}
