package com.hypernexus.nit.planner

import java.util.UUID

/**
 * MÔ HÌNH DỮ LIỆU KẾ HOẠCH & NHIỆM VỤ TỰ HÀNH (AUTONOMOUS TASK PLANNER MODEL)
 */

enum class TriggerType {
    IMMEDIATE,            // Thực thi ngay lập tức
    EXACT_TIME,           // Hẹn giờ kích hoạt chính xác theo AlarmManager
    PERIODIC,             // Lặp lại định kỳ (mỗi N phút/giờ)
    MARKET_CONDITION,     // Kích hoạt khi chỉ số thị trường thỏa mãn (RSI, Giá)
    DEVICE_CONDITION      // Kích hoạt khi thiết bị cắm sạc, pin đầy, v.v.
}

enum class ActionType {
    SOLANA_QUANT_ANALYZE, // Quét thanh khoản & phân tích nến Solana TA-Lib
    TOKEN_SWAP,           // Hoán đổi token DEX qua Jupiter
    RUGCHECK_AUDIT,       // Quét kiểm toán an toàn hợp đồng On-chain
    WEB_SEARCH,           // Tra cứu internet thời gian thực
    GENERATE_3D_MODEL,    // Dựng mô hình 3D tham số
    EXPORT_3D_PRINT,      // Xuất file máy in 3D (.STL / .OBJ)
    SLICER_ANALYZE,       // Phân tích thể tích & khối lượng gram nhựa in 3D
    CAPCUT_MACRO,         // Tự động mở CapCut & chạy chuỗi cắt video
    GAME_BOT,             // Kích hoạt bot hỗ trợ game tự động
    SMART_HOME_CONTROL,   // Điều khiển thiết bị nhà thông minh
    VOICE_NOTIFY,         // Thông báo giọng nói TTS thích ứng
    SCREEN_REWIND_QUERY,  // Truy vấn ký ức màn hình SQLite FTS4
    WEB_DEVELOP,          // Lập trình & sinh mã nguồn web đa file (HTML5/CSS3/JS/Canvas)
    WEB_HOST_LOCAL        // Khởi chạy máy chủ HTTP Sandbox cục bộ & live preview
}

enum class StepStatus {
    PENDING,                // Đang chờ thực thi
    CONDITION_WAIT,         // Đang chờ thỏa mãn điều kiện
    EXECUTING,              // Đang thực thi
    RETRYING,               // Đang thử lại với Exponential Backoff
    HEALED_WITH_FALLBACK,   // Đã tự chữa lành & hoàn thành bằng phương án dự phòng
    SUCCESS,                // Thành công
    SKIPPED,                // Bỏ qua
    FAILED                  // Thất bại
}

enum class PlanStatus {
    ACTIVE,    // Đang lên lịch / đang theo dõi
    RUNNING,   // Đang chạy các bước
    COMPLETED, // Đã hoàn thành toàn bộ
    CANCELLED, // Đã hủy bởi người dùng
    FAILED     // Gặp lỗi gián đoạn
}

data class PlanStep(
    val stepId: Int,
    val title: String,
    val actionType: ActionType,
    val params: Map<String, String> = emptyMap(),
    val condition: String? = null,
    val dependsOnStepIds: List<Int> = emptyList(), // Các bước tiên quyết cho Parallel DAG
    var status: StepStatus = StepStatus.PENDING,
    var output: String? = null,
    var retryCount: Int = 0,
    var healingReport: String? = null // Ghi chú quá trình tự chữa lành (nếu có)
)

data class TaskPlan(
    val planId: String = UUID.randomUUID().toString(),
    val title: String,
    val rawGoal: String,
    val triggerType: TriggerType,
    val triggerTimeMs: Long = 0L,
    val repeatIntervalMs: Long = 0L,
    val triggerCondition: String? = null,
    val steps: MutableList<PlanStep> = mutableListOf(),
    var status: PlanStatus = PlanStatus.ACTIVE,
    val createdAtMs: Long = System.currentTimeMillis()
)

/**
 * TRẠNG THÁI TIẾN TRÌNH TÁC TỬ PHẢN ỨNG (REACTIVE AGENT EXECUTION STATE FOR 120 FPS UI)
 */
sealed class AgentExecutionState {
    object Idle : AgentExecutionState()
    data class Parsing(val rawInput: String) : AgentExecutionState()
    data class Thinking(val intent: String) : AgentExecutionState()
    data class ExecutingStep(val stepId: Int, val title: String, val totalSteps: Int) : AgentExecutionState()
    data class Healing(val stepId: Int, val title: String, val reason: String, val strategy: String) : AgentExecutionState()
    data class Completed(val planTitle: String, val summary: String) : AgentExecutionState()
    data class Failed(val planTitle: String, val error: String) : AgentExecutionState()
}
