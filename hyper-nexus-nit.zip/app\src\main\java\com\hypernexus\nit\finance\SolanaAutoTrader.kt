package com.hypernexus.nit.finance

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object SolanaAutoTrader {

    private const val TAG = "SolanaAutoTrader"
    private val client = OkHttpClient.Builder()
        .connectTimeout(8, TimeUnit.SECONDS)
        .readTimeout(8, TimeUnit.SECONDS)
        .build()

    private const val JUPITER_QUOTE_API = "https://quote-api.jup.ag/v6/quote"
    private const val JUPITER_SWAP_API = "https://quote-api.jup.ag/v6/swap"

    data class SwapQuote(
        val inputMint: String,
        val outputMint: String,
        val inAmount: Double,
        val outAmount: Double,
        val priceImpactPct: Double,
        val routePlan: String,
        val rawQuoteResponse: String
    )

    /**
     * LẤY BÁO GIÁ SWAP TỐI ƯU TỪ JUPITER TRÊN MẠNG SOLANA (REAL ON-CHAIN ROUTING)
     */
    suspend fun getBestSwapQuote(
        inSol: Double,
        targetMint: String,
        slippageBps: Int = 50
    ): SwapQuote? = withContext(Dispatchers.IO) {
        try {
            val lamports = (inSol * 1_000_000_000).toLong()
            val url = "$JUPITER_QUOTE_API?inputMint=${SolanaDexDataManager.SOL_MINT}&outputMint=$targetMint&amount=$lamports&slippageBps=$slippageBps"

            val request = Request.Builder().url(url).build()
            val response = client.newCall(request).execute()
            val body = response.body?.string() ?: return@withContext null

            val json = JSONObject(body)
            val outAmountRaw = json.optLong("outAmount", 0L)
            val priceImpact = json.optDouble("priceImpactPct", 0.0)

            val routes = json.optJSONArray("routePlan")
            val dexName = if (routes != null && routes.length() > 0) {
                routes.getJSONObject(0).getJSONObject("swapInfo").optString("label", "Raydium")
            } else "Orca/Raydium"

            return@withContext SwapQuote(
                inputMint = SolanaDexDataManager.SOL_MINT,
                outputMint = targetMint,
                inAmount = inSol,
                outAmount = outAmountRaw.toDouble(),
                priceImpactPct = priceImpact,
                routePlan = dexName,
                rawQuoteResponse = body
            )
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi lấy báo giá Jupiter Swap: ${e.message}")
            return@withContext null
        }
    }

    /**
     * TẠO GIAO DỊCH SWAP SOLANA THẬT 100% QUA JUPITER V6 SWAP API
     * Gửi payload JSON tới Jupiter API để nhận chuỗi byte transaction đã serialize (Base64)
     */
    suspend fun executeAutoSwap(quote: SwapQuote, userPublicKey: String): String = withContext(Dispatchers.IO) {
        try {
            Log.d(TAG, "Gửi yêu cầu tạo Transaction Swap thật tới Jupiter v6 cho ví: $userPublicKey")

            val payload = JSONObject().apply {
                put("userPublicKey", userPublicKey)
                put("quoteResponse", JSONObject(quote.rawQuoteResponse))
                put("wrapAndUnwrapSol", true)
                put("prioritizationFeeLamports", "auto")
            }

            val requestBody = payload.toString().toRequestBody("application/json".toMediaTypeOrNull())
            val request = Request.Builder()
                .url(JUPITER_SWAP_API)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: return@withContext "Không nhận được giao dịch từ Jupiter API."

            val json = JSONObject(responseBody)
            val swapTxBase64 = json.optString("swapTransaction", "")

            if (swapTxBase64.isNotEmpty()) {
                Log.d(TAG, "Nhận Transaction wire format thật (${swapTxBase64.length} chars) thành công!")
                return@withContext """
                    ✅ TẠO GIAO DỊCH SWAP SOLANA THẬT THÀNH CÔNG:
                    • Hoán đổi: ${quote.inAmount} SOL -> Token ${quote.outputMint.take(6)}...
                    • Sàn thực thi: ${quote.routePlan} (Jupiter v6)
                    • Trượt giá: ${"%.2f".format(quote.priceImpactPct)}%
                    • Transaction Payload: ${swapTxBase64.take(16)}... (Sẵn sàng phát lên mạng Solana RPC)
                """.trimIndent()
            } else {
                return@withContext "Lỗi tạo giao dịch Jupiter: ${json.optString("error", "Không xác định")}"
            }
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi thực thi Swap thật: ${e.message}")
            return@withContext "Lỗi giao dịch Swap: ${e.message}"
        }
    }
}
