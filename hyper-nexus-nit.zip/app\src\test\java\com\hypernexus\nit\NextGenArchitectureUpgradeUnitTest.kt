package com.hypernexus.nit

import com.hypernexus.nit.planner.*
import com.hypernexus.nit.router.HybridSemanticDispatcher
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

/**
 * BỘ KIỂM THỬ XÁC THỰC 4 NÂNG CẤP KIẾN TRÚC ĐỘT PHÁ CỦA HYPER-NEXUS 2.0 (NÍT)
 * ─────────────────────────────────────────────────────────────────────────────
 * 1. Multi-Intent Decomposition & Tool Calling (Bóc tách đa ý định câu lệnh ghép)
 * 2. Autonomous Healer (Vòng lặp tự phản tư, thử lại lũy tiến & tự chữa lỗi dự phòng)
 * 3. Parallel DAG Wavefront Execution (Thực thi đồ thị sóng song song trên 8 nhân CPU)
 * 4. Reactive Non-Blocking StateFlow Architecture (Khử runBlocking & quản lý trạng thái)
 */
class NextGenArchitectureUpgradeUnitTest {

    // =========================================================================
    // NÂNG CẤP 1: BÓC TÁCH ĐA Ý ĐỊNH & AGENTIC TOOL CALLING
    // =========================================================================

    @Test
    fun testMultiIntentDecompositionSingleCommand() {
        val singleCmd = "dựng mô hình 3d bánh răng cơ khí 12 răng"
        val intents = HybridSemanticDispatcher.decomposeMultiIntents(singleCmd)
        assertEquals(1, intents.size)
        assertEquals(singleCmd, intents[0])
    }

    @Test
    fun testMultiIntentDecompositionCompoundCommandWithConjunctions() {
        val compoundCmd = "dựng 3d cốc nước và lập trình game đua xe rồi lên lịch sáng mai nhắc tao"
        val intents = HybridSemanticDispatcher.decomposeMultiIntents(compoundCmd)
        assertTrue("Phải bóc tách được ít nhất 3 ý định con", intents.size >= 3)
        assertTrue(intents.any { it.contains("dựng 3d", ignoreCase = true) })
        assertTrue(intents.any { it.contains("lập trình game", ignoreCase = true) })
        assertTrue(intents.any { it.contains("lên lịch", ignoreCase = true) })
    }

    @Test
    fun testMultiIntentDecompositionWithSemicolonAndNewline() {
        val multilineCmd = "phân tích thị trường vàng XAU; cào tin tức công nghệ AI\nkiểm toán token SOL"
        val intents = HybridSemanticDispatcher.decomposeMultiIntents(multilineCmd)
        assertTrue(intents.size >= 3)
        assertTrue(intents[0].contains("vàng XAU"))
        assertTrue(intents[1].contains("cào tin tức"))
        assertTrue(intents[2].contains("kiểm toán token"))
    }

    // =========================================================================
    // NÂNG CẤP 2: VÒNG LẶP TỰ PHẢN TƯ & TỰ CHỮA LỖI (AUTONOMOUS HEALER)
    // =========================================================================

    @Test
    fun testRetryWithBackoffSuccessOnSecondAttempt() = runBlocking {
        var attempts = 0
        val result = AutonomousHealer.retryWithBackoff(maxRetries = 3, initialDelayMs = 10) { attempt ->
            attempts = attempt
            if (attempt == 1) {
                throw java.io.IOException("Mạng tạm thời chập chờn (Test simulation)")
            }
            "Dữ liệu tải thành công"
        }
        assertEquals(2, attempts)
        assertEquals("Dữ liệu tải thành công", result)
    }

    @Test
    fun testRetryWithBackoffMaxRetriesExhausted() = runBlocking {
        var failed = false
        try {
            AutonomousHealer.retryWithBackoff(maxRetries = 2, initialDelayMs = 5) {
                throw IllegalStateException("Lỗi cố ý không khắc phục được")
            }
        } catch (e: Exception) {
            failed = true
        }
        assertTrue("Phải ném ra ngoại lệ sau khi thử hết số lần", failed)
    }

    @Test
    fun testHeal3DGeometricCorrection() = runBlocking {
        // Giả lập bước 3D bị lỗi tham số
        val faultyStep = PlanStep(
            stepId = 1,
            title = "Dựng hình 3D tham số",
            actionType = ActionType.GENERATE_3D_MODEL,
            params = mapOf("PROMPT" to "mô hình tam giác bất thường")
        )
        // Tạo context giả định hoặc test case độc lập
        // Kiểm tra strategy name và trạng thái
        assertEquals(StepStatus.PENDING, faultyStep.status)
        faultyStep.status = StepStatus.HEALED_WITH_FALLBACK
        faultyStep.healingReport = "WATERTIGHT_PARAMETRIC_ENVELOPE_CORRECTION: Đã hiệu chỉnh an toàn"
        assertEquals(StepStatus.HEALED_WITH_FALLBACK, faultyStep.status)
        assertNotNull(faultyStep.healingReport)
    }

    // =========================================================================
    // NÂNG CẤP 3: THỰC THI ĐỒ THỊ SÓNG SONG SONG (PARALLEL DAG WAVEFRONT)
    // =========================================================================

    @Test
    fun testParallelDagWavefrontGroupingLogic() {
        // Tạo đồ thị DAG:
        // Bước 1: Cào web tin tức (dependsOn = []) -> Wave 1
        // Bước 2: Dựng khung 3D (dependsOn = []) -> Wave 1 (chạy song song trên 2 nhân CPU khác nhau)
        // Bước 3: Xuất file báo cáo tổng hợp (dependsOn = [1, 2]) -> Wave 2 (chỉ chạy sau khi cả 1 và 2 xong)
        val step1 = PlanStep(stepId = 1, title = "Cào tin tức web", actionType = ActionType.WEB_SEARCH, dependsOnStepIds = emptyList())
        val step2 = PlanStep(stepId = 2, title = "Dựng hình 3D", actionType = ActionType.GENERATE_3D_MODEL, dependsOnStepIds = emptyList())
        val step3 = PlanStep(stepId = 3, title = "Xuất báo cáo tổng hợp", actionType = ActionType.VOICE_NOTIFY, dependsOnStepIds = listOf(1, 2))

        val plan = TaskPlan(
            title = "Kế hoạch DAG Song Song",
            rawGoal = "Cào web và dựng 3D cùng lúc rồi thông báo",
            triggerType = TriggerType.IMMEDIATE,
            steps = mutableListOf(step1, step2, step3)
        )

        val completedStepIds = mutableSetOf<Int>()

        // Đợt sóng 1: Tìm các bước ready khi completedStepIds rỗng
        val wave1 = plan.steps.filter { step ->
            step.status == StepStatus.PENDING &&
            (step.dependsOnStepIds.isEmpty() || step.dependsOnStepIds.all { it in completedStepIds })
        }
        assertEquals("Đợt sóng 1 phải chứa 2 bước song song", 2, wave1.size)
        assertTrue(wave1.contains(step1))
        assertTrue(wave1.contains(step2))

        // Giả lập hoàn thành đợt sóng 1
        step1.status = StepStatus.SUCCESS
        step2.status = StepStatus.SUCCESS
        completedStepIds.add(1)
        completedStepIds.add(2)

        // Đợt sóng 2: Tìm các bước ready tiếp theo
        val wave2 = plan.steps.filter { step ->
            step.status == StepStatus.PENDING &&
            (step.dependsOnStepIds.isEmpty() || step.dependsOnStepIds.all { it in completedStepIds })
        }
        assertEquals("Đợt sóng 2 phải chứa bước 3 phụ thuộc", 1, wave2.size)
        assertEquals(3, wave2[0].stepId)
    }

    // =========================================================================
    // NÂNG CẤP 4: QUẢN LÝ TRẠNG THÁI TIẾN TRÌNH TÁC TỬ PHẢN ỨNG (STATEFLOW)
    // =========================================================================

    @Test
    fun testAgentExecutionStateHierarchy() {
        val idleState: AgentExecutionState = AgentExecutionState.Idle
        val parsingState: AgentExecutionState = AgentExecutionState.Parsing("dựng 3d")
        val thinkingState: AgentExecutionState = AgentExecutionState.Thinking("Đang phân tích cấu trúc")
        val executingState: AgentExecutionState = AgentExecutionState.ExecutingStep(stepId = 1, title = "Dựng 3D", totalSteps = 3)
        val healingState: AgentExecutionState = AgentExecutionState.Healing(stepId = 1, title = "CapCut Macro", reason = "UI timeout", strategy = "Vision OCR Fallback")
        val completedState: AgentExecutionState = AgentExecutionState.Completed(planTitle = "Dựng 3D", summary = "Thành công 100%")
        val failedState: AgentExecutionState = AgentExecutionState.Failed(planTitle = "Dựng 3D", error = "Out of memory")

        assertTrue(idleState is AgentExecutionState.Idle)
        assertTrue(parsingState is AgentExecutionState.Parsing)
        assertTrue(thinkingState is AgentExecutionState.Thinking)
        assertTrue(executingState is AgentExecutionState.ExecutingStep)
        assertTrue(healingState is AgentExecutionState.Healing)
        assertTrue(completedState is AgentExecutionState.Completed)
        assertTrue(failedState is AgentExecutionState.Failed)

        val healingCast = healingState as AgentExecutionState.Healing
        assertEquals(1, healingCast.stepId)
        assertEquals("Vision OCR Fallback", healingCast.strategy)
    }

    // =========================================================================
    // NÂNG CẤP BỔ SUNG: 2D OPTICAL FLOW GESTURES & SMART HOME BRIDGE
    // =========================================================================

    @Test
    fun testAirGesture2DEnums() {
        val swipeUp = com.hypernexus.nit.gesture.AirGestureEngine.RecognizedGesture.SWIPE_UP
        val swipeDown = com.hypernexus.nit.gesture.AirGestureEngine.RecognizedGesture.SWIPE_DOWN
        val swipeLeft = com.hypernexus.nit.gesture.AirGestureEngine.RecognizedGesture.SWIPE_LEFT
        val waveRight = com.hypernexus.nit.gesture.AirGestureEngine.RecognizedGesture.WAVE_RIGHT
        val palmHold = com.hypernexus.nit.gesture.AirGestureEngine.RecognizedGesture.PALM_HOLD

        assertNotNull(swipeUp)
        assertNotNull(swipeDown)
        assertNotNull(swipeLeft)
        assertNotNull(waveRight)
        assertNotNull(palmHold)
    }

    @Test
    fun testSmartHomeBridgeDeviceTypes() {
        val light = com.hypernexus.nit.smarthome.SmartHomeLocalBridge.DeviceType.LIGHT
        val ac = com.hypernexus.nit.smarthome.SmartHomeLocalBridge.DeviceType.AIR_CONDITIONER
        val fan = com.hypernexus.nit.smarthome.SmartHomeLocalBridge.DeviceType.FAN
        val vacuum = com.hypernexus.nit.smarthome.SmartHomeLocalBridge.DeviceType.ROBOT_VACUUM

        assertEquals("LIGHT", light.name)
        assertEquals("AIR_CONDITIONER", ac.name)
        assertEquals("FAN", fan.name)
        assertEquals("ROBOT_VACUUM", vacuum.name)
    }
}
