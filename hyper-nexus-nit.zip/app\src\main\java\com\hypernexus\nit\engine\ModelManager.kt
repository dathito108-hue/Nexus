package com.hypernexus.nit.engine

import android.content.Context
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL

object ModelManager {

    private const val TAG = "ModelManager"
    const val DEFAULT_MODEL_NAME = "Qwen2.5-1.5B-Instruct-Q4_K_M.gguf"
    
    // Direct link to Qwen 2.5 1.5B Q4_K_M GGUF on Hugging Face
    private const val MODEL_DOWNLOAD_URL = 
        "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF/resolve/main/qwen2.5-1.5b-instruct-q4_k_m.gguf"

    fun getModelFile(context: Context): File {
        return File(context.filesDir, DEFAULT_MODEL_NAME)
    }

    fun isModelReady(context: Context): Boolean {
        val file = getModelFile(context)
        return file.exists() && file.length() > 100 * 1024 * 1024 // > 100MB
    }

    suspend fun downloadModel(
        context: Context,
        onProgress: (Int) -> Unit
    ): Boolean = withContext(Dispatchers.IO) {
        val targetFile = getModelFile(context)
        if (isModelReady(context)) {
            Log.d(TAG, "Mô hình đã có sẵn trên máy: ${targetFile.absolutePath}")
            onProgress(100)
            return@withContext true
        }

        try {
            val url = URL(MODEL_DOWNLOAD_URL)
            val connection = url.openConnection() as HttpURLConnection
            connection.connect()

            val fileLength = connection.contentLength
            val input = connection.inputStream
            val output = FileOutputStream(targetFile)

            val data = ByteArray(8192)
            var total: Long = 0
            var count: Int

            while (input.read(data).also { count = it } != -1) {
                total += count
                if (fileLength > 0) {
                    val progress = ((total * 100) / fileLength).toInt()
                    onProgress(progress)
                }
                output.write(data, 0, count)
            }

            output.flush()
            output.close()
            input.close()
            Log.d(TAG, "Tải mô hình hoàn tất: ${targetFile.length()} bytes")
            return@withContext true
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi tải mô hình: ${e.message}")
            if (targetFile.exists()) targetFile.delete()
            return@withContext false
        }
    }
}
