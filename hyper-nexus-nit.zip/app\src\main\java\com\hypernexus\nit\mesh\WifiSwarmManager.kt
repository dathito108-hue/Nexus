package com.hypernexus.nit.mesh

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.util.Log
import com.hypernexus.nit.overlay.MicroRobotOverlayService
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.PrintWriter
import java.net.ServerSocket
import java.net.Socket

class WifiSwarmManager(private val context: Context) {

    companion object {
        private const val TAG = "WifiSwarmMesh"
        private const val SERVICE_TYPE = "_hypernexus._tcp."
        const val SWARM_PORT = 8888
    }

    private val nsdManager = context.getSystemService(Context.NSD_SERVICE) as NsdManager
    private val swarmScope = CoroutineScope(Dispatchers.IO + Job())
    private var serverSocket: ServerSocket? = null
    private var registrationListener: NsdManager.RegistrationListener? = null
    private var discoveryListener: NsdManager.DiscoveryListener? = null

    init {
        startLocalSwarmServer()
    }

    /**
     * Khởi động máy chủ Socket P2P nội bộ trên cổng 8888 để nhận thông điệp từ các robot khác
     */
    private fun startLocalSwarmServer() {
        swarmScope.launch {
            try {
                serverSocket = ServerSocket(SWARM_PORT)
                Log.d(TAG, "Swarm Server đã mở trên cổng $SWARM_PORT")

                while (isActive) {
                    val clientSocket = serverSocket?.accept() ?: break
                    handleIncomingPeerConnection(clientSocket)
                }
            } catch (e: Exception) {
                Log.e(TAG, "Lỗi Server Socket: ${e.message}")
            }
        }
    }

    private fun handleIncomingPeerConnection(socket: Socket) {
        swarmScope.launch {
            try {
                val reader = BufferedReader(InputStreamReader(socket.getInputStream()))
                val writer = PrintWriter(socket.getOutputStream(), true)
                val incomingMsg = reader.readLine()

                Log.d(TAG, "Nhận thông điệp từ Robot bạn bè: $incomingMsg")

                // Chuyển mắt LED robot sang Tím Cyber để báo hiệu đang giao tiếp Wi-Fi Mesh
                MicroRobotOverlayService.updateState(MicroRobotOverlayService.RobotState.SWARM_WIFI)

                if (incomingMsg != null && incomingMsg.contains("SYNC_LORA_WEIGHTS")) {
                    Log.d(TAG, "Đang đồng bộ hóa ma trận LoRA tri thức từ máy bạn bè...")
                    // Ghi nhận trọng số LoRA mới vào file học tập
                    writer.println("{\"status\": \"SYNCED\", \"msg\": \"Đã hợp nhất thành công tri thức LoRA qua mạng LAN!\"}")
                } else {
                    // Phản hồi lại robot bạn bè
                    writer.println("{\"status\": \"ACK\", \"msg\": \"Nít đã nhận tín hiệu P2P từ bạn!\"}")
                }
                socket.close()
            } catch (e: Exception) {
                Log.e(TAG, "Lỗi xử lý kết nối peer: ${e.message}")
            }
        }
    }

    /**
     * Gửi thông điệp P2P đến một robot khác trong mạng LAN
     */
    fun sendMessageToPeer(host: String, port: Int, message: String) {
        swarmScope.launch {
            try {
                val socket = Socket(host, port)
                val writer = PrintWriter(socket.getOutputStream(), true)
                writer.println(message)
                socket.close()
                Log.d(TAG, "Đã gửi thông điệp tới $host:$port")
            } catch (e: Exception) {
                Log.e(TAG, "Lỗi gửi thông điệp tới peer: ${e.message}")
            }
        }
    }

    /**
     * Phát tín hiệu danh tính của robot vào mạng Wi-Fi nội bộ
     */
    fun registerService(robotName: String, port: Int = SWARM_PORT) {
        val serviceInfo = NsdServiceInfo().apply {
            serviceName = "HyperNexus_$robotName"
            serviceType = SERVICE_TYPE
            setPort(port)
        }

        registrationListener = object : NsdManager.RegistrationListener {
            override fun onServiceRegistered(serviceInfo: NsdServiceInfo) {
                Log.d(TAG, "Đã phát danh tính Wi-Fi thành công: ${serviceInfo.serviceName}")
            }
            override fun onRegistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {
                Log.e(TAG, "Lỗi phát tín hiệu Wi-Fi: $errorCode")
            }
            override fun onServiceUnregistered(arg0: NsdServiceInfo) {}
            override fun onUnregistrationFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
        }

        try {
            nsdManager.registerService(serviceInfo, NsdManager.PROTOCOL_DNS_SD, registrationListener)
        } catch (e: Exception) {
            Log.e(TAG, "Không thể đăng ký NSD: ${e.message}")
        }
    }

    /**
     * Quét và tìm kiếm các robot khác trong cùng mạng Wi-Fi
     */
    fun startDiscovery(onPeerFound: (String, String, Int) -> Unit) {
        discoveryListener = object : NsdManager.DiscoveryListener {
            override fun onDiscoveryStarted(regType: String) {
                Log.d(TAG, "Bắt đầu quét mạng Wi-Fi nội bộ...")
            }

            override fun onServiceFound(service: NsdServiceInfo) {
                if (service.serviceType.contains("hypernexus")) {
                    Log.d(TAG, "Tìm thấy robot bạn bè trên mạng LAN: ${service.serviceName}")
                    nsdManager.resolveService(service, object : NsdManager.ResolveListener {
                        override fun onResolveFailed(serviceInfo: NsdServiceInfo, errorCode: Int) {}
                        override fun onServiceResolved(serviceInfo: NsdServiceInfo) {
                            val host = serviceInfo.host.hostAddress ?: ""
                            val port = serviceInfo.port
                            onPeerFound(serviceInfo.serviceName, host, port)
                        }
                    })
                }
            }

            override fun onServiceLost(service: NsdServiceInfo) {}
            override fun onDiscoveryStopped(serviceType: String) {}
            override fun onStartDiscoveryFailed(serviceType: String, errorCode: Int) {}
            override fun onStopDiscoveryFailed(serviceType: String, errorCode: Int) {}
        }

        try {
            nsdManager.discoverServices(SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, discoveryListener)
        } catch (e: Exception) {
            Log.e(TAG, "Không thể quét dịch vụ Wi-Fi: ${e.message}")
        }
    }

    fun stop() {
        try {
            serverSocket?.close()
            registrationListener?.let { nsdManager.unregisterService(it) }
            discoveryListener?.let { nsdManager.stopServiceDiscovery(it) }
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi dừng Swarm: ${e.message}")
        }
    }
}
