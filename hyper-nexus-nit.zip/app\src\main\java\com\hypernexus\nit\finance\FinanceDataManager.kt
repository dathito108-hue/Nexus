package com.hypernexus.nit.finance

import android.util.Log
import com.hypernexus.nit.engine.LlamaEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONArray
import java.util.concurrent.TimeUnit

object FinanceDataManager {

    private const val TAG = "FinanceDataManager"
    private val client = OkHttpClient.Builder()
        .connectTimeout(5, TimeUnit.SECONDS)
        .readTimeout(5, TimeUnit.SECONDS)
        .build()

    // Endpoint công khai của sàn Binance (Không cần API Key)
    private const val BINANCE_KLINES_URL = 
        "https://api.binance.com/api/v3/klines?symbol=BTCUSDT&interval=15m&limit=25"

    /**
     * Lấy giá nến Bitcoin thời gian thực và phân tích kỹ thuật bằng C++ TA-Lib
     */
    suspend fun analyzeLiveBitcoinRSI(): String = withContext(Dispatchers.IO) {
        try {
            val request = Request.Builder().url(BINANCE_KLINES_URL).build()
            val response = client.newCall(request).execute()
            val responseBody = response.body?.string() ?: return@withContext "Không nhận được dữ liệu từ sàn."

            val jsonArray = JSONArray(responseBody)
            val closePrices = DoubleArray(jsonArray.length())

            for (i in 0 until jsonArray.length()) {
                val candle = jsonArray.getJSONArray(i)
                // Cột thứ 4 trong mảng nến Binance là giá đóng cửa (Close price)
                closePrices[i] = candle.getString(4).toDouble()
            }

            val latestPrice = closePrices.last()

            // Gọi hàm C++ TA-Lib trên NDK để tính toán RSI chu kỳ 14
            val rsiArray = LlamaEngine.calculateRSI(closePrices, 14)
            val currentRSI = if (rsiArray.isNotEmpty()) rsiArray.last() else 50.0

            val signal = when {
                currentRSI >= 70.0 -> "⚠️ QUÁ MUA (Overbought): Áp lực bán tiềm ẩn, cân nhắc chốt lời hoặc đặt Stop-loss ngắn."
                currentRSI <= 30.0 -> "🚀 QUÁ BÁN (Oversold): Vùng gom hàng tiềm năng, kỳ vọng nhịp hồi phục kỹ thuật."
                else -> "⚖️ TRUNG LẬP: Xu hướng sideway tích lũy, khuyến nghị giữ lệnh theo cấu trúc sóng."
            }

            return@withContext """
                📊 [PHÂN TÍCH BITCOIN LIVE]:
                • Giá hiện tại: ${"%,.2f".format(latestPrice)}$ USDT
                • Chỉ số RSI (15m): ${"%.2f".format(currentRSI)}
                • Khuyến nghị: $signal
            """.trimIndent()

        } catch (e: Exception) {
            Log.e(TAG, "Lỗi lấy dữ liệu tài chính: ${e.message}")
            return@withContext "Lỗi kết nối sàn: ${e.message}. Vui lòng kiểm tra kết nối mạng."
        }
    }
}
