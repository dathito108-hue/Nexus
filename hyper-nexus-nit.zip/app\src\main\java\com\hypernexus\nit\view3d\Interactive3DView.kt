package com.hypernexus.nit.view3d

import android.content.Context
import android.opengl.GLSurfaceView
import android.util.AttributeSet
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import com.hypernexus.nit.engine.Procedural3DGenerator

/**
 * KHUNG NHÌN 3D TƯƠNG TÁC ĐA ĐIỂM CHUYÊN NGHIỆP TRÊN MÀN HÌNH 120Hz
 * Hỗ trợ xoay 360°, véo thu phóng, chạm đúp reset góc nhìn chuẩn CAD,
 * chuyển đổi 4 chế độ Shader kỹ thuật và phân tích thông số máy in 3D.
 */
class Interactive3DView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : GLSurfaceView(context, attrs) {

    val renderer = Model3DRenderer()

    private var previousX: Float = 0f
    private var previousY: Float = 0f
    private val scaleGestureDetector: ScaleGestureDetector
    private val gestureDetector: GestureDetector
    private var currentMesh: Procedural3DGenerator.MeshData? = null

    init {
        // Cấu hình OpenGL ES 2.0
        setEGLContextClientVersion(2)
        setRenderer(renderer)
        // 120 FPS VSYNC trên Samsung Galaxy S21 FE 5G
        renderMode = RENDERMODE_CONTINUOUSLY

        // Bộ nhận diện thu phóng 2 ngón (Pinch-to-zoom)
        scaleGestureDetector = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(detector: ScaleGestureDetector): Boolean {
                renderer.scaleFactor = (renderer.scaleFactor * detector.scaleFactor).coerceIn(0.35f, 4.0f)
                return true
            }
        })

        // Bộ nhận diện chạm đúp (Double tap to reset camera)
        gestureDetector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean {
                resetCamera()
                return true
            }
        })
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        gestureDetector.onTouchEvent(event)
        scaleGestureDetector.onTouchEvent(event)
        if (scaleGestureDetector.isInProgress) {
            return true
        }

        val x = event.x
        val y = event.y

        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                previousX = x
                previousY = y
            }
            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount == 1) {
                    val dx = x - previousX
                    val dy = y - previousY

                    renderer.angleY += dx * 0.45f
                    renderer.angleX += dy * 0.45f
                    renderer.angleX = renderer.angleX.coerceIn(-85f, 85f)
                }
                previousX = x
                previousY = y
            }
        }

        return true
    }

    /**
     * Nạp dữ liệu hình học MeshData vào GPU
     */
    fun setModelMesh(mesh: Procedural3DGenerator.MeshData) {
        currentMesh = mesh
        queueEvent {
            renderer.updateMeshData(mesh)
        }
    }

    /**
     * Reset góc camera về góc nhìn kỹ thuật chuẩn CAD
     */
    fun resetCamera() {
        renderer.angleX = 15f
        renderer.angleY = 25f
        renderer.scaleFactor = 1.0f
    }

    /**
     * Chuyển đổi qua lại giữa 4 chế độ Shader chuyên nghiệp
     */
    fun cycleRenderMode(): Model3DRenderer.RenderMode {
        val nextMode = when (renderer.activeRenderMode) {
            Model3DRenderer.RenderMode.PBR_METALLIC -> Model3DRenderer.RenderMode.NEON_WIREFRAME
            Model3DRenderer.RenderMode.NEON_WIREFRAME -> Model3DRenderer.RenderMode.NORMAL_MAP
            Model3DRenderer.RenderMode.NORMAL_MAP -> Model3DRenderer.RenderMode.SLICER_LAYERS
            Model3DRenderer.RenderMode.SLICER_LAYERS -> Model3DRenderer.RenderMode.PBR_METALLIC
        }
        renderer.activeRenderMode = nextMode
        return nextMode
    }

    /**
     * Bật/Tắt chế độ khung dây phát sáng (Tương thích ngược)
     */
    fun toggleWireframe(): Boolean {
        renderer.isWireframeMode = !renderer.isWireframeMode
        return renderer.isWireframeMode
    }

    /**
     * Bật/Tắt hiển thị lưới bàn in 3D
     */
    fun toggleGridFloor(): Boolean {
        renderer.showGridFloor = !renderer.showGridFloor
        return renderer.showGridFloor
    }

    /**
     * Phân tích thông số kỹ thuật in 3D cho mô hình đang hiển thị
     */
    fun getSlicerAnalysis(): Procedural3DGenerator.SlicerAnalysis? {
        val mesh = currentMesh ?: return null
        return Procedural3DGenerator.analyzeMeshFor3DPrinting(mesh)
    }
}
