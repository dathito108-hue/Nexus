package com.hypernexus.nit.planner

import android.content.Context
import android.util.Log
import com.hypernexus.nit.engine.Procedural3DGenerator
import com.hypernexus.nit.finance.SolanaDexDataManager
import com.hypernexus.nit.finance.SolanaSafetyAuditor
import com.hypernexus.nit.voice.VoiceInteractionEngine
import com.hypernexus.nit.web.WebSearchEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext

/**
 * LÕI THỰC THI TỰ HÀNH CÁC BƯỚC KẾ HOẠCH (AUTONOMOUS EXECUTION ENGINE PRO)
 * Hỗ trợ thực thi đồ thị sóng song song (Parallel Wave DAG) trên 8 nhân Exynos 2100,
 * tích hợp động cơ tự phản tư & tự chữa lỗi (Autonomous Healer),
 * và truyền phát trạng thái phản ứng thời gian thực (StateFlow) cho 120 FPS UI.
 */
object AutonomousExecutionEngine {

    private const val TAG = "AutonomousExecutionEngine"

    private val _executionState = MutableStateFlow<AgentExecutionState>(AgentExecutionState.Idle)
    val executionState = _executionState.asStateFlow()

    suspend fun executePlan(
        context: Context,
        plan: TaskPlan,
        onStepProgress: ((PlanStep) -> Unit)? = null
    ): String = withContext(Dispatchers.Default) {
        val dbHelper = PlanDatabaseHelper(context)
        plan.status = PlanStatus.RUNNING
        dbHelper.updatePlanStatus(plan.planId, PlanStatus.RUNNING)
        _executionState.value = AgentExecutionState.Thinking("Bắt đầu thực thi kế hoạch: ${plan.title}")

        val sb = StringBuilder("🚀 [TIẾN TRÌNH THỰC THI ĐỒ THỊ PARALLEL DAG: ${plan.title}]\n\n")
        var hasFatalFailure = false
        val completedStepIds = mutableSetOf<Int>()

        // Thuật toán thực thi theo từng đợt sóng (Parallel Wavefront Execution)
        while (completedStepIds.size < plan.steps.size && !hasFatalFailure) {
            // Tìm các bước chưa thực thi mà tất cả bước phụ thuộc đã hoàn thành
            val readySteps = plan.steps.filter { step ->
                step.status == StepStatus.PENDING &&
                (step.dependsOnStepIds.isEmpty() || step.dependsOnStepIds.all { it in completedStepIds })
            }

            if (readySteps.isEmpty()) {
                // Kiểm tra xem có bước nào còn PENDING không (Deadlock hoặc chu trình phụ thuộc)
                val remainingPending = plan.steps.filter { it.status == StepStatus.PENDING }
                if (remainingPending.isNotEmpty()) {
                    Log.w(TAG, "Phát hiện bước phụ thuộc còn lại, chuyển sang thực thi tuần tự an toàn: ${remainingPending.map { it.stepId }}")
                    // Chạy bước đầu tiên còn lại
                    val stepToRun = remainingPending.first()
                    val success = executeSingleStepWithHealing(context, stepToRun, dbHelper, plan, onStepProgress, sb)
                    if (success) {
                        completedStepIds.add(stepToRun.stepId)
                    } else {
                        hasFatalFailure = true
                    }
                    continue
                } else {
                    break
                }
            }

            Log.d(TAG, "⚡ Kích hoạt đợt sóng song song gồm ${readySteps.size} bước: ${readySteps.map { "[${it.stepId}]: ${it.title}" }}")

            // Thực thi song song trên 8 nhân CPU của Exynos 2100 qua Dispatchers.Default
            val stepResults = readySteps.map { step ->
                async(Dispatchers.Default) {
                    executeSingleStepWithHealing(context, step, dbHelper, plan, onStepProgress, sb)
                }
            }.awaitAll()

            // Cập nhật kết quả vào danh sách hoàn thành
            readySteps.forEachIndexed { idx, step ->
                val isSuccess = stepResults[idx]
                if (isSuccess) {
                    completedStepIds.add(step.stepId)
                } else {
                    hasFatalFailure = true
                }
            }
        }

        plan.status = if (hasFatalFailure) PlanStatus.FAILED else PlanStatus.COMPLETED
        dbHelper.updatePlanStatus(plan.planId, plan.status)

        val summary = sb.toString().trim()
        if (hasFatalFailure) {
            _executionState.value = AgentExecutionState.Failed(plan.title, summary)
        } else {
            _executionState.value = AgentExecutionState.Completed(plan.title, summary)
        }

        Log.d(TAG, summary)
        return@withContext summary
    }

    /**
     * THỰC THI 1 BƯỚC KÈM VÒNG LẶP TỰ CHỮA LỖI (AUTONOMOUS HEALING)
     */
    private suspend fun executeSingleStepWithHealing(
        context: Context,
        step: PlanStep,
        dbHelper: PlanDatabaseHelper,
        plan: TaskPlan,
        onStepProgress: ((PlanStep) -> Unit)?,
        sb: StringBuilder
    ): Boolean {
        step.status = StepStatus.EXECUTING
        dbHelper.updateStepStatus(plan.planId, step.stepId, StepStatus.EXECUTING)
        _executionState.value = AgentExecutionState.ExecutingStep(step.stepId, step.title, plan.steps.size)
        onStepProgress?.invoke(step)

        try {
            // Thử thực thi với Exponential Backoff tối đa 2 lần cho lỗi mạng tạm thời
            val stepOutput = AutonomousHealer.retryWithBackoff(maxRetries = 2, initialDelayMs = 250) {
                executeSingleStep(context, step)
            }
            step.status = StepStatus.SUCCESS
            step.output = stepOutput
            dbHelper.updateStepStatus(plan.planId, step.stepId, StepStatus.SUCCESS, stepOutput)
            onStepProgress?.invoke(step)

            synchronized(sb) {
                sb.append("✅ [Bước ${step.stepId}]: ${step.title}\n")
                sb.append("   • Kết quả: $stepOutput\n\n")
            }
            return true
        } catch (e: Exception) {
            Log.w(TAG, "Bước ${step.stepId} gặp sự cố: ${e.message}. Kích hoạt phản tư & tự chữa lỗi...")
            _executionState.value = AgentExecutionState.Healing(step.stepId, step.title, e.message ?: "Lỗi", "Kích hoạt Healer")

            // Kích hoạt AutonomousHealer tự phân tích & chữa lỗi
            val healing = AutonomousHealer.attemptHealStep(context, step, e)
            if (healing.success) {
                step.status = StepStatus.HEALED_WITH_FALLBACK
                step.output = healing.healedOutput
                step.healingReport = "${healing.strategyUsed}: ${healing.details}"
                dbHelper.updateStepStatus(plan.planId, step.stepId, StepStatus.HEALED_WITH_FALLBACK, step.output)
                onStepProgress?.invoke(step)

                synchronized(sb) {
                    sb.append("🩹 [Bước ${step.stepId} TỰ CHỮA LÀNH (${healing.strategyUsed})]: ${step.title}\n")
                    sb.append("   • Phương án dự phòng: ${healing.healedOutput}\n\n")
                }
                return true
            } else {
                step.status = StepStatus.FAILED
                step.output = "Lỗi nghiêm trọng: ${e.message}"
                dbHelper.updateStepStatus(plan.planId, step.stepId, StepStatus.FAILED, step.output)
                onStepProgress?.invoke(step)

                synchronized(sb) {
                    sb.append("❌ [Bước ${step.stepId}]: ${step.title} THẤT BẠI: ${e.message}\n\n")
                }
                return false
            }
        }
    }

    private suspend fun executeSingleStep(context: Context, step: PlanStep): String {
        return when (step.actionType) {
            ActionType.SOLANA_QUANT_ANALYZE -> {
                val token = step.params["TOKEN"] ?: "SOL"
                if (token == "GOLD" || token == "XAU") {
                    val dossier = com.hypernexus.nit.finance.InstitutionalMarketAnalyzer.analyzeInstitutionalMarket("XAU")
                    dossier.formatExecutiveMemo()
                } else if (token == "BTC" || token == "BITCOIN") {
                    val dossier = com.hypernexus.nit.finance.InstitutionalMarketAnalyzer.analyzeInstitutionalMarket("BTC")
                    dossier.formatExecutiveMemo()
                } else {
                    val dexResult = SolanaDexDataManager.analyzeSolanaDexToken(token)
                    val dossier = com.hypernexus.nit.finance.InstitutionalMarketAnalyzer.analyzeInstitutionalMarket(token)
                    "$dexResult\n\n🏛️ [PHÂN TÍCH TỔ CHỨC SMC & QUANT RISK]:\n• Đánh giá: ${dossier.bias.icon} ${dossier.bias.vietnamese} (${dossier.compositeScore}/100)\n• Cấu trúc: ${dossier.smcStructure.structureVerdict}\n• BOS: ${dossier.smcStructure.lastBOS}\n• VaR 95%: ${"%.2f".format(dossier.quantRisk.var95Pct)}% | Squeeze: ${if (dossier.quantRisk.isVolatilitySqueezing) "SQUEEZE ON" else "Squeeze OFF"}\n• Tỷ trọng tối ưu Kelly: ${"%.1f".format(dossier.quantRisk.optimalKellyFractionPct)}% NAV"
                }
            }

            ActionType.RUGCHECK_AUDIT -> {
                val mint = step.params["TOKEN_MINT"] ?: SolanaDexDataManager.SOL_MINT
                val audit = SolanaSafetyAuditor.auditTokenSecurity(mint)
                "Điểm an toàn: ${audit.safetyScore}/100 | Phân loại: ${audit.riskLevel} | ${audit.summaryNote}"
            }

            ActionType.TOKEN_SWAP -> {
                val token = step.params["TOKEN"] ?: "SOL"
                val amount = step.params["AMOUNT"]?.toDoubleOrNull() ?: 0.1
                val quote = com.hypernexus.nit.finance.SolanaAutoTrader.getBestSwapQuote(amount, "EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v")
                if (quote != null) {
                    "Lấy báo giá Jupiter thành công: Nhận ${"%,.2f".format(quote.outAmount)} USDC (Sàn ${quote.routePlan})"
                } else {
                    "Không thể kết nối máy chủ báo giá Jupiter."
                }
            }

            ActionType.WEB_SEARCH -> {
                val query = step.params["QUERY"] ?: "tin tức công nghệ AI"
                val results = WebSearchEngine.searchWeb(query)
                if (results.isNotEmpty()) {
                    "Tìm thấy ${results.size} tin tức. Nổi bật: ${results[0].title} (${results[0].url})"
                } else {
                    "Không tìm thấy kết quả tìm kiếm trực tuyến."
                }
            }

            ActionType.GENERATE_3D_MODEL -> {
                val customPrompt = step.params["CUSTOM_3D_PROMPT"] ?: step.params["PROMPT"]
                if (!customPrompt.isNullOrEmpty() && (step.params.containsKey("CUSTOM_3D_PROMPT") || com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.isCustom3DPrompt(customPrompt))) {
                    val mesh = com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.synthesize3DMeshFromPrompt(customPrompt)
                    "Đã dựng thành công mô hình 3D độc bản: \"${mesh.customTitle}\" (${mesh.triangleCount} tam giác, chuẩn 2-Manifold kín nước trong RAM <20ms)"
                } else {
                    val modelName = step.params["MODEL_TYPE"] ?: "CYBER_ROBOT"
                    val type = try {
                        Procedural3DGenerator.MeshType.valueOf(modelName)
                    } catch (e: Exception) {
                        Procedural3DGenerator.MeshType.CYBER_ROBOT
                    }
                    val mesh = Procedural3DGenerator.buildMeshData(type)
                    "Đã dựng thành công mô hình ${type.name} với ${mesh.triangleCount} tam giác trong RAM (<20ms)"
                }
            }

            ActionType.SLICER_ANALYZE -> {
                val customPrompt = step.params["CUSTOM_3D_PROMPT"] ?: step.params["PROMPT"]
                val mesh = if (!customPrompt.isNullOrEmpty() && (step.params.containsKey("CUSTOM_3D_PROMPT") || com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.isCustom3DPrompt(customPrompt))) {
                    com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.synthesize3DMeshFromPrompt(customPrompt)
                } else {
                    val modelName = step.params["MODEL_TYPE"] ?: "CYBER_ROBOT"
                    val type = try {
                        Procedural3DGenerator.MeshType.valueOf(modelName)
                    } catch (e: Exception) {
                        Procedural3DGenerator.MeshType.CYBER_ROBOT
                    }
                    Procedural3DGenerator.buildMeshData(type)
                }
                val analysis = Procedural3DGenerator.analyzeMeshFor3DPrinting(mesh)
                "Mô hình ${if (mesh.customTitle.isNotEmpty()) mesh.customTitle else mesh.type.name} -> Thể tích: ${"%.2f".format(analysis.volumeCm3)}cm³, Nhựa PLA: ${"%.1f".format(analysis.weightGramsPla)}g, Thời gian in: ${analysis.estimatedPrintTimeMinutes} phút, Kín nước: ${analysis.isWatertight}"
            }

            ActionType.EXPORT_3D_PRINT -> {
                val customPrompt = step.params["CUSTOM_3D_PROMPT"] ?: step.params["PROMPT"]
                val mesh = if (!customPrompt.isNullOrEmpty() && (step.params.containsKey("CUSTOM_3D_PROMPT") || com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.isCustom3DPrompt(customPrompt))) {
                    com.hypernexus.nit.engine.Dynamic3DSynthesisEngine.synthesize3DMeshFromPrompt(customPrompt)
                } else {
                    val modelName = step.params["MODEL_TYPE"] ?: "CYBER_ROBOT"
                    val type = try {
                        Procedural3DGenerator.MeshType.valueOf(modelName)
                    } catch (e: Exception) {
                        Procedural3DGenerator.MeshType.CYBER_ROBOT
                    }
                    Procedural3DGenerator.buildMeshData(type)
                }
                val file = Procedural3DGenerator.exportToBinaryStlFile(context, mesh, "nit_auto_${System.currentTimeMillis() % 10000}_binary.stl")
                "Đã xuất Binary STL độc bản: ${file.name} (${file.length()} bytes) tại ${file.absolutePath}"
            }

            ActionType.CAPCUT_MACRO -> {
                val customPrompt = step.params["CUSTOM_CAPCUT_PROMPT"] ?: step.params["PROMPT"]
                if (!customPrompt.isNullOrEmpty() && (step.params.containsKey("CUSTOM_CAPCUT_PROMPT") || com.hypernexus.nit.video.DynamicCapCutSynthesisEngine.isCustomCapCutPrompt(customPrompt))) {
                    com.hypernexus.nit.video.DynamicCapCutSynthesisEngine.executeFromPrompt(context, customPrompt)
                } else {
                    val themeName = step.params["THEME"]
                    if (!themeName.isNullOrEmpty()) {
                        val theme = com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.matchThemeFromCommand(themeName)
                        val config = com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.buildDefaultConfigForTheme(theme)
                        com.hypernexus.nit.video.CapCutThemeAndEffectsStudio.executeThemeAndAudioProduction(context, config)
                    } else {
                        val cmd = step.params["COMMAND"] ?: step.params["PRESET"] ?: "FULL_STUDIO_PIPELINE"
                        val preset = com.hypernexus.nit.video.CapCutProAutomationEngine.matchPresetFromCommand(cmd)
                        com.hypernexus.nit.video.CapCutProAutomationEngine.executeProEditingPreset(context, preset)
                    }
                }
            }

            ActionType.GAME_BOT -> {
                com.hypernexus.nit.accessibility.GameBotManager.startAutoCombatCombo()
                "Đã kích hoạt chuỗi combo chiêu Game Bot với jitter chống phát hiện."
            }

            ActionType.SMART_HOME_CONTROL -> {
                val deviceStr = step.params["DEVICE"]?.uppercase() ?: "LIGHT"
                val state = step.params["STATE"]?.lowercase() ?: "turn_on"
                val action = if (state.contains("off") || state.contains("tắt")) "turn_off" else "turn_on"
                val deviceType = when {
                    deviceStr.contains("AC") || deviceStr.contains("AIR") -> com.hypernexus.nit.smarthome.SmartHomeLocalBridge.DeviceType.AIR_CONDITIONER
                    deviceStr.contains("FAN") || deviceStr.contains("QUẠT") -> com.hypernexus.nit.smarthome.SmartHomeLocalBridge.DeviceType.FAN
                    deviceStr.contains("VACUUM") || deviceStr.contains("HÚT BỤI") -> com.hypernexus.nit.smarthome.SmartHomeLocalBridge.DeviceType.ROBOT_VACUUM
                    else -> com.hypernexus.nit.smarthome.SmartHomeLocalBridge.DeviceType.LIGHT
                }
                val res = com.hypernexus.nit.smarthome.SmartHomeLocalBridge.controlDevice(deviceType, action)
                "Smart Home Wi-Fi LAN: $res"
            }

            ActionType.VOICE_NOTIFY -> {
                val msg = step.params["MESSAGE"] ?: "Nhiệm vụ tự hành đã hoàn thành."
                VoiceInteractionEngine(context).speak(msg)
                "Đã phát âm thông báo giọng nói TTS: \"$msg\""
            }

            ActionType.SCREEN_REWIND_QUERY -> {
                val q = step.params["QUERY"] ?: ""
                val tm = com.hypernexus.nit.accessibility.NitAccessibilityService.instance?.getTimelineManager()
                    ?: com.hypernexus.nit.evolution.ScreenTimelineMemoryManager(context)
                val list = tm.searchTimelineMemory(q, limit = 2)
                if (list.isNotEmpty()) {
                    "Tìm thấy mốc ký ức lúc ${list[0].formattedTime} trên ${list[0].appLabel}: \"${list[0].textSnippet}\""
                } else {
                    "Chưa tìm thấy đoạn ký ức phù hợp trong SQLite FTS4."
                }
            }

            ActionType.WEB_DEVELOP -> {
                val customPrompt = step.params["CUSTOM_GAME_PROMPT"] ?: step.params["PROMPT"]
                if (!customPrompt.isNullOrEmpty() && (step.params.containsKey("CUSTOM_GAME_PROMPT") || com.hypernexus.nit.web.DynamicGameSynthesisEngine.isCustomGamePrompt(customPrompt))) {
                    val project = com.hypernexus.nit.web.DynamicGameSynthesisEngine.synthesizeGameFromPrompt(context, customPrompt)
                    val gameVal = com.hypernexus.nit.web.WebGameDevelopmentEngine.validateGameCode(project)
                    val exportRes = com.hypernexus.nit.web.WebDevelopmentEngine.exportProjectToDisk(context, project, createZip = true)
                    "Đã lập trình game web độc bản theo mô tả: \"${project.title}\" (${gameVal.totalLines} dòng, 120 FPS Delta-Time: ${gameVal.hasGameLoopDeltaTime}, Web Audio Synth: ${gameVal.hasWebAudioSynth}, Điểm: ${gameVal.qualityScore}/100). Đóng gói ZIP: ${exportRes.zipFilePath ?: "Hoàn tất"}"
                } else {
                    val gameGenreStr = step.params["GAME_GENRE"]
                    if (!gameGenreStr.isNullOrEmpty()) {
                        val genre = try {
                            com.hypernexus.nit.web.WebGameDevelopmentEngine.WebGameGenre.valueOf(gameGenreStr)
                        } catch (e: Exception) {
                            com.hypernexus.nit.web.WebGameDevelopmentEngine.WebGameGenre.CYBER_SPACE_SHOOTER
                        }
                        val title = step.params["TITLE"] ?: genre.displayName
                        val project = com.hypernexus.nit.web.WebGameDevelopmentEngine.generateGameProject(genre, title)
                        val gameVal = com.hypernexus.nit.web.WebGameDevelopmentEngine.validateGameCode(project)
                        val exportRes = com.hypernexus.nit.web.WebDevelopmentEngine.exportProjectToDisk(context, project, createZip = true)
                        "Đã lập trình game web: ${genre.displayName} (${gameVal.totalLines} dòng, 120 FPS Delta-Time: ${gameVal.hasGameLoopDeltaTime}, Web Audio Synth: ${gameVal.hasWebAudioSynth}, Điểm: ${gameVal.qualityScore}/100). Đóng gói ZIP: ${exportRes.zipFilePath ?: "Hoàn tất"}"
                    } else {
                        val templateStr = step.params["TEMPLATE"] ?: "LANDING_PAGE_SAAS"
                        val template = try {
                            com.hypernexus.nit.web.WebDevelopmentEngine.WebProjectTemplate.valueOf(templateStr)
                        } catch (e: Exception) {
                            com.hypernexus.nit.web.WebDevelopmentEngine.WebProjectTemplate.LANDING_PAGE_SAAS
                        }
                        val title = step.params["TITLE"] ?: template.displayName
                        val project = com.hypernexus.nit.web.WebDevelopmentEngine.generateProject(template, title)
                        val validation = com.hypernexus.nit.web.WebDevelopmentEngine.validateWebCode(project)
                        val exportRes = com.hypernexus.nit.web.WebDevelopmentEngine.exportProjectToDisk(context, project, createZip = true)
                        "Đã sinh ${project.files.size} file web (${validation.totalLines} dòng, ${validation.totalBytes} bytes, Điểm W3C: ${validation.qualityScore}/100). Đóng gói ZIP: ${exportRes.zipFilePath ?: "Hoàn tất"}"
                    }
                }
            }

            ActionType.WEB_HOST_LOCAL -> {
                val customPrompt = step.params["CUSTOM_GAME_PROMPT"] ?: step.params["PROMPT"]
                val gameGenreStr = step.params["GAME_GENRE"]
                val project = if (!customPrompt.isNullOrEmpty()) {
                    com.hypernexus.nit.web.DynamicGameSynthesisEngine.synthesizeGameFromPrompt(context, customPrompt)
                } else if (!gameGenreStr.isNullOrEmpty()) {
                    val genre = try {
                        com.hypernexus.nit.web.WebGameDevelopmentEngine.WebGameGenre.valueOf(gameGenreStr)
                    } catch (e: Exception) {
                        com.hypernexus.nit.web.WebGameDevelopmentEngine.WebGameGenre.CYBER_SPACE_SHOOTER
                    }
                    com.hypernexus.nit.web.WebGameDevelopmentEngine.generateGameProject(genre)
                } else {
                    val templateStr = step.params["TEMPLATE"] ?: "LANDING_PAGE_SAAS"
                    val template = try {
                        com.hypernexus.nit.web.WebDevelopmentEngine.WebProjectTemplate.valueOf(templateStr)
                    } catch (e: Exception) {
                        com.hypernexus.nit.web.WebDevelopmentEngine.WebProjectTemplate.LANDING_PAGE_SAAS
                    }
                    com.hypernexus.nit.web.WebDevelopmentEngine.generateProject(template)
                }
                val started = com.hypernexus.nit.web.LocalWebSandboxServer.startServer(project)
                if (started) {
                    "Máy chủ Web Sandbox đang chạy tại: ${com.hypernexus.nit.web.LocalWebSandboxServer.getServerUrl()}"
                } else {
                    "Không thể khởi chạy máy chủ Web Sandbox cục bộ."
                }
            }
        }
    }
}
