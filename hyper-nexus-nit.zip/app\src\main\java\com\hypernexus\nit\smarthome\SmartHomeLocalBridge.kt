package com.hypernexus.nit.smarthome

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object SmartHomeLocalBridge {

    private const val TAG = "SmartHomeLocalBridge"
    private val client = OkHttpClient.Builder()
        .connectTimeout(3, TimeUnit.SECONDS)
        .readTimeout(3, TimeUnit.SECONDS)
        .build()

    // Địa chỉ IP mặc định của Home Assistant hoặc gateway MQTT trong mạng LAN
    private var localBridgeHost = "http://192.168.1.100:8123"

    enum class DeviceType {
        LIGHT,
        AIR_CONDITIONER,
        FAN,
        ROBOT_VACUUM
    }

    fun configureBridgeHost(host: String) {
        localBridgeHost = host.trimEnd('/')
    }

    /**
     * GỬI LỆNH ĐIỀU KHIỂN NHÀ THÔNG MINH TRỰC TIẾP QUA WI-FI NỘI BỘ (0% QUA ĐÁM MÂY)
     */
    suspend fun controlDevice(
        device: DeviceType,
        action: String, // "turn_on", "turn_off", "set_temp"
        params: Map<String, Any> = emptyMap()
    ): String = withContext(Dispatchers.IO) {
        try {
            val endpoint = when (device) {
                DeviceType.LIGHT -> "$localBridgeHost/api/services/light/$action"
                DeviceType.AIR_CONDITIONER -> "$localBridgeHost/api/services/climate/$action"
                DeviceType.FAN -> "$localBridgeHost/api/services/fan/$action"
                DeviceType.ROBOT_VACUUM -> "$localBridgeHost/api/services/vacuum/$action"
            }

            val payload = JSONObject().apply {
                params.forEach { (k, v) -> put(k, v) }
            }

            val requestBody = payload.toString().toRequestBody("application/json".toMediaTypeOrNull())
            val request = Request.Builder()
                .url(endpoint)
                .post(requestBody)
                .build()

            val response = client.newCall(request).execute()
            val success = response.isSuccessful

            Log.d(TAG, "Điều khiển thiết bị $device [$action]: Thành công=$success")

            return@withContext if (success) {
                "Đã thực thi lệnh $action cho ${device.name.lowercase()} thành công qua mạng Wi-Fi nội bộ."
            } else {
                "Gửi lệnh tới thiết bị thất bại (Mã lỗi: ${response.code}). Vui lòng kiểm tra IP Smart Home."
            }
        } catch (e: Exception) {
            Log.e(TAG, "Lỗi kết nối Smart Home: ${e.message}")
            return@withContext "Không thể kết nối tới Hub Nhà thông minh trong mạng LAN (${e.message})."
        }
    }
}

/**
 * LỚP ĐIỀU PHỐI TƯƠNG THÍCH CHO TOÀN BỘ HỆ THỐNG
 */
object SmartHomeManager {
    suspend fun sendCommand(device: String, state: String): String {
        val dev = when (device.uppercase()) {
            "AC", "AIR_CONDITIONER" -> SmartHomeLocalBridge.DeviceType.AIR_CONDITIONER
            "FAN" -> SmartHomeLocalBridge.DeviceType.FAN
            "VACUUM", "ROBOT_VACUUM" -> SmartHomeLocalBridge.DeviceType.ROBOT_VACUUM
            else -> SmartHomeLocalBridge.DeviceType.LIGHT
        }
        val action = if (state.lowercase().contains("off") || state.lowercase().contains("tắt")) "turn_off" else "turn_on"
        return SmartHomeLocalBridge.controlDevice(dev, action)
    }
}

