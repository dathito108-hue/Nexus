package com.hypernexus.nit.engine

import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * ĐỘNG CƠ DỰNG HÌNH HỌC 3D THAM SỐ ĐỘC BẢN THEO MÔ TẢ TỰ DO CỦA NGƯỜI DÙNG
 * (PROMPT-DRIVEN DYNAMIC 3D PROCEDURAL CAD & MESH SYNTHESIS ENGINE)
 * ─────────────────────────────────────────────────────────────────────────────
 * Không bị bó buộc vào danh sách các mẫu cố định; tự động phân tích ngôn ngữ tự nhiên
 * bóc tách hình học nguyên thủy (Topological Primitives), kích thước, độ dày thành,
 * độ xoắn, lỗ xuyên tâm, và sinh lưới tam giác 3D (Vertices, Normals, Indices)
 * chuẩn 2-Manifold kín nước (Watertight) 100% On-Device cho màn hình 120Hz & máy in 3D.
 */
object Dynamic3DSynthesisEngine {

    enum class GeometricPrimitive(val code: String, val displayName: String) {
        HOLLOW_CYLINDER_VESSEL("HOLLOW_CYLINDER", "Hình Trụ Rỗng / Cốc / Ống / Bình"),
        CHAMFERED_BOX_ENCLOSURE("CHAMFERED_BOX", "Khối Hộp Vát Cạnh / Vỏ Thiết Bị / Khay Đựng"),
        PARAMETRIC_MECHANICAL_GEAR("PARAMETRIC_GEAR", "Bánh Răng Cơ Khí Tham Số Số Răng Tùy Biến"),
        PARAMETRIC_TWISTED_HELIX("TWISTED_HELIX", "Khối Xoắn Ốc / Bình Sóng / Lò Xo Động Lực"),
        TRIANGULAR_MOUNT_STAND("TRIANGULAR_STAND", "Chân Đế Đa Giác / Giá Đỡ Kẹp Tam Giác"),
        ORGANIC_CYBER_POLYHEDRON("CYBER_POLYHEDRON", "Khối Đa Diện Viễn Tưởng Cyber Mecha")
    }

    data class Dynamic3DSpec(
        val rawPrompt: String,
        val primitive: GeometricPrimitive,
        val title: String,
        val radiusBottom: Float,
        val radiusTop: Float,
        val height: Float,
        val wallThickness: Float,
        val segments: Int,
        val twistAngleRad: Float,
        val hasHollowCavity: Boolean,
        val hasCenterBoreHole: Boolean,
        val featureNotes: String
    )

    /**
     * KIỂM TRA XEM CÂU LỆNH CÓ PHẢI YÊU CẦU DỰNG 3D THEO MÔ TẢ TỰ DO HAY KHÔNG
     */
    fun isCustom3DPrompt(prompt: String): Boolean {
        val lower = prompt.lowercase().trim()
        val has3DKeyword = lower.contains("3d") || lower.contains("dựng") || lower.contains("mô hình") ||
                lower.contains("cad") || lower.contains("in 3d") || lower.contains("thiết kế") || lower.contains("vẽ 3d")

        val hasCustomShape = lower.contains("cốc") || lower.contains("ly") || lower.contains("chén") ||
                lower.contains("ống") || lower.contains("hộp") || lower.contains("vỏ") || lower.contains("tai nghe") ||
                lower.contains("bình") || lower.contains("lọ") || lower.contains("khay") || lower.contains("chân đế") ||
                lower.contains("giá đỡ") || lower.contains("đai ốc") || lower.contains("bánh răng") || lower.contains("lò xo") ||
                lower.contains("xoắn") || lower.contains("lỗ") || lower.contains("rỗng") || lower.contains("mô tả") ||
                lower.contains("theo ý") || lower.contains("tùy biến") || lower.contains("độc bản")

        return has3DKeyword && hasCustomShape
    }

    /**
     * PHÂN TÍCH NGỮ NGHĨA KHẨU LỆNH ĐỂ TRÍCH XUẤT THÔNG SỐ HÌNH HỌC THAM SỐ
     */
    fun parse3DSpecFromPrompt(prompt: String): Dynamic3DSpec {
        val lower = prompt.lowercase().trim()

        val primitive = when {
            lower.contains("cốc") || lower.contains("ly") || lower.contains("chén") || lower.contains("ống") || lower.contains("trụ rỗng") -> {
                GeometricPrimitive.HOLLOW_CYLINDER_VESSEL
            }
            lower.contains("hộp") || lower.contains("vỏ") || lower.contains("tai nghe") || lower.contains("khay") || lower.contains("lập phương") -> {
                GeometricPrimitive.CHAMFERED_BOX_ENCLOSURE
            }
            lower.contains("bánh răng") || lower.contains("răng") || lower.contains("gear") || lower.contains("nhông") -> {
                GeometricPrimitive.PARAMETRIC_MECHANICAL_GEAR
            }
            lower.contains("xoắn") || lower.contains("lò xo") || lower.contains("lượn sóng") || lower.contains("bình hoa") || lower.contains("xoắn ốc") -> {
                GeometricPrimitive.PARAMETRIC_TWISTED_HELIX
            }
            lower.contains("chân đế") || lower.contains("giá đỡ") || lower.contains("tam giác") || lower.contains("kẹp") || lower.contains("đế") -> {
                GeometricPrimitive.TRIANGULAR_MOUNT_STAND
            }
            else -> GeometricPrimitive.ORGANIC_CYBER_POLYHEDRON
        }

        val title = extract3DTitle(prompt, primitive)

        // Bóc tách kích thước & đặc tính từ câu lệnh
        val radiusBottom = when {
            lower.contains("lớn") || lower.contains("to") -> 2.2f
            lower.contains("nhỏ") || lower.contains("mini") -> 1.0f
            else -> 1.6f
        }

        val radiusTop = when {
            lower.contains("loe") || lower.contains("rộng ở trên") -> radiusBottom * 1.35f
            lower.contains("thuôn") || lower.contains("hẹp ở trên") || lower.contains("chóp") -> radiusBottom * 0.7f
            else -> radiusBottom
        }

        val height = when {
            lower.contains("cao") || lower.contains("dài") -> 3.8f
            lower.contains("thấp") || lower.contains("dẹt") || lower.contains("mỏng") -> 1.4f
            else -> 2.5f
        }

        val wallThickness = when {
            lower.contains("dày") -> 0.45f
            lower.contains("mỏng") -> 0.18f
            else -> 0.30f
        }

        val segments = when {
            lower.contains("mịn") || lower.contains("tròn trịa") -> 36
            lower.contains("lục giác") -> 6
            lower.contains("ngũ giác") -> 5
            lower.contains("bát giác") -> 8
            else -> 24
        }

        val twistAngle = when {
            lower.contains("xoắn mạnh") -> (PI * 1.2).toFloat()
            lower.contains("xoắn") -> (PI * 0.6).toFloat()
            else -> 0f
        }

        val hasHollow = lower.contains("rỗng") || lower.contains("cốc") || lower.contains("ly") || lower.contains("hộp") || lower.contains("ống")
        val hasBoreHole = lower.contains("lỗ") || lower.contains("trục") || lower.contains("khoan") || lower.contains("xuyên tâm")

        return Dynamic3DSpec(
            rawPrompt = prompt,
            primitive = primitive,
            title = title,
            radiusBottom = radiusBottom,
            radiusTop = radiusTop,
            height = height,
            wallThickness = wallThickness,
            segments = segments,
            twistAngleRad = twistAngle,
            hasHollowCavity = hasHollow,
            hasCenterBoreHole = hasBoreHole,
            featureNotes = "Chuẩn 2-Manifold kín nước in 3D"
        )
    }

    private fun extract3DTitle(prompt: String, primitive: GeometricPrimitive): String {
        val clean = prompt.replace("dựng 3d", "", ignoreCase = true)
            .replace("dựng mô hình 3d", "", ignoreCase = true)
            .replace("thiết kế 3d", "", ignoreCase = true)
            .replace("vẽ 3d", "", ignoreCase = true)
            .replace("tạo mô hình 3d", "", ignoreCase = true)
            .replace("làm 3d", "", ignoreCase = true)
            .trim()

        return if (clean.length in 3..40) {
            clean.replaceFirstChar { it.uppercase() }
        } else {
            primitive.displayName
        }
    }

    /**
     * TỔNG HỢP LƯỚI TAM GIÁC 3D THAM SỐ TỪ THÔNG SỐ BÓC TÁCH
     */
    fun synthesize3DMeshFromPrompt(prompt: String): Procedural3DGenerator.MeshData {
        val spec = parse3DSpecFromPrompt(prompt)
        return when (spec.primitive) {
            GeometricPrimitive.HOLLOW_CYLINDER_VESSEL -> buildHollowCylinderMesh(spec)
            GeometricPrimitive.CHAMFERED_BOX_ENCLOSURE -> buildChamferedBoxMesh(spec)
            GeometricPrimitive.PARAMETRIC_MECHANICAL_GEAR -> buildParametricGearMesh(spec)
            GeometricPrimitive.PARAMETRIC_TWISTED_HELIX -> buildParametricHelixMesh(spec)
            GeometricPrimitive.TRIANGULAR_MOUNT_STAND -> buildTriangularStandMesh(spec)
            GeometricPrimitive.ORGANIC_CYBER_POLYHEDRON -> buildCyberPolyhedronMesh(spec)
        }
    }

    fun synthesizeDefaultDynamicMesh(): Procedural3DGenerator.MeshData {
        return synthesize3DMeshFromPrompt("dựng mô hình 3d cốc uống nước có lòng rỗng")
    }

    // =========================================================================
    // 1. DỰNG KHỐI TRỤ RỖNG / CỐC / ỐNG / BÌNH (HOLLOW CYLINDER VESSEL)
    // =========================================================================
    private fun buildHollowCylinderMesh(spec: Dynamic3DSpec): Procedural3DGenerator.MeshData {
        val segs = spec.segments
        val rOutBot = spec.radiusBottom
        val rOutTop = spec.radiusTop
        val rInBot = max(0.2f, rOutBot - spec.wallThickness)
        val rInTop = max(0.2f, rOutTop - spec.wallThickness)
        val h = spec.height
        val halfH = h / 2f
        val floorThick = spec.wallThickness

        val vList = mutableListOf<Float>()
        val nList = mutableListOf<Float>()
        val iList = mutableListOf<Short>()

        fun addQuad(
            x1: Float, y1: Float, z1: Float,
            x2: Float, y2: Float, z2: Float,
            x3: Float, y3: Float, z3: Float,
            x4: Float, y4: Float, z4: Float,
            nx: Float, ny: Float, nz: Float
        ) {
            val base = (vList.size / 3).toShort()
            vList.addAll(listOf(x1, y1, z1, x2, y2, z2, x3, y3, z3, x4, y4, z4))
            for (k in 0..3) nList.addAll(listOf(nx, ny, nz))
            iList.addAll(listOf(base, (base + 1).toShort(), (base + 2).toShort(), base, (base + 2).toShort(), (base + 3).toShort()))
        }

        // Vành ngoài (Outer wall) & Vành trong (Inner cavity wall) & Vành miệng (Rim) & Đáy ngoài (Bottom)
        for (i in 0 until segs) {
            val a1 = (i.toFloat() / segs) * 2f * PI.toFloat()
            val a2 = ((i + 1).toFloat() / segs) * 2f * PI.toFloat()

            val cos1 = cos(a1); val sin1 = sin(a1)
            val cos2 = cos(a2); val sin2 = sin(a2)

            // Thành ngoài
            val nExtX = (cos1 + cos2) / 2f
            val nExtZ = (sin1 + sin2) / 2f
            addQuad(
                rOutBot * cos1, -halfH, rOutBot * sin1,
                rOutTop * cos1, halfH, rOutTop * sin1,
                rOutTop * cos2, halfH, rOutTop * sin2,
                rOutBot * cos2, -halfH, rOutBot * sin2,
                nExtX, 0f, nExtZ
            )

            // Thành trong (lòng cốc)
            val nIntX = -nExtX
            val nIntZ = -nExtZ
            addQuad(
                rInBot * cos2, -halfH + floorThick, rInBot * sin2,
                rInTop * cos2, halfH, rInTop * sin2,
                rInTop * cos1, halfH, rInTop * sin1,
                rInBot * cos1, -halfH + floorThick, rInBot * sin1,
                nIntX, 0f, nIntZ
            )

            // Vành miệng trên (Top Rim)
            addQuad(
                rInTop * cos1, halfH, rInTop * sin1,
                rInTop * cos2, halfH, rInTop * sin2,
                rOutTop * cos2, halfH, rOutTop * sin2,
                rOutTop * cos1, halfH, rOutTop * sin1,
                0f, 1f, 0f
            )

            // Đáy trong (Inner Floor)
            val baseIn = (vList.size / 3).toShort()
            vList.addAll(listOf(0f, -halfH + floorThick, 0f, rInBot * cos1, -halfH + floorThick, rInBot * sin1, rInBot * cos2, -halfH + floorThick, rInBot * sin2))
            for (k in 0..2) nList.addAll(listOf(0f, 1f, 0f))
            iList.addAll(listOf(baseIn, (baseIn + 1).toShort(), (baseIn + 2).toShort()))

            // Đáy ngoài (Outer Bottom)
            val baseOut = (vList.size / 3).toShort()
            vList.addAll(listOf(0f, -halfH, 0f, rOutBot * cos2, -halfH, rOutBot * sin2, rOutBot * cos1, -halfH, rOutBot * sin1))
            for (k in 0..2) nList.addAll(listOf(0f, -1f, 0f))
            iList.addAll(listOf(baseOut, (baseOut + 1).toShort(), (baseOut + 2).toShort()))
        }

        return Procedural3DGenerator.MeshData(
            vertices = vList.toFloatArray(),
            normals = nList.toFloatArray(),
            indices = iList.toShortArray(),
            type = Procedural3DGenerator.MeshType.CUSTOM_DYNAMIC,
            triangleCount = iList.size / 3,
            customTitle = spec.title
        )
    }

    // =========================================================================
    // 2. DỰNG KHỐI HỘP VÁT CẠNH / VỎ THIẾT BỊ (CHAMFERED BOX ENCLOSURE)
    // =========================================================================
    private fun buildChamferedBoxMesh(spec: Dynamic3DSpec): Procedural3DGenerator.MeshData {
        val w = spec.radiusBottom * 1.8f
        val h = spec.height * 0.9f
        val d = spec.radiusBottom * 1.4f
        val cham = min(0.35f, spec.wallThickness)

        val vList = mutableListOf<Float>()
        val nList = mutableListOf<Float>()
        val iList = mutableListOf<Short>()

        fun addFace(
            x1: Float, y1: Float, z1: Float,
            x2: Float, y2: Float, z2: Float,
            x3: Float, y3: Float, z3: Float,
            x4: Float, y4: Float, z4: Float,
            nx: Float, ny: Float, nz: Float
        ) {
            val base = (vList.size / 3).toShort()
            vList.addAll(listOf(x1, y1, z1, x2, y2, z2, x3, y3, z3, x4, y4, z4))
            for (k in 0..3) nList.addAll(listOf(nx, ny, nz))
            iList.addAll(listOf(base, (base + 1).toShort(), (base + 2).toShort(), base, (base + 2).toShort(), (base + 3).toShort()))
        }

        val hw = w / 2f; val hh = h / 2f; val hd = d / 2f

        // 6 mặt chính (thu hẹp viền chamfer)
        addFace(-hw + cham, -hh + cham, hd, hw - cham, -hh + cham, hd, hw - cham, hh - cham, hd, -hw + cham, hh - cham, hd, 0f, 0f, 1f) // Trước
        addFace(hw - cham, -hh + cham, -hd, -hw + cham, -hh + cham, -hd, -hw + cham, hh - cham, -hd, hw - cham, hh - cham, -hd, 0f, 0f, -1f) // Sau
        addFace(-hw, -hh + cham, -hd + cham, -hw, -hh + cham, hd - cham, -hw, hh - cham, hd - cham, -hw, hh - cham, -hd + cham, -1f, 0f, 0f) // Trái
        addFace(hw, -hh + cham, hd - cham, hw, -hh + cham, -hd + cham, hw, hh - cham, -hd + cham, hw, hh - cham, hd - cham, 1f, 0f, 0f) // Phải
        addFace(-hw + cham, hh, -hd + cham, hw - cham, hh, -hd + cham, hw - cham, hh, hd - cham, -hw + cham, hh, hd - cham, 0f, 1f, 0f) // Trên
        addFace(-hw + cham, -hh, hd - cham, hw - cham, -hh, hd - cham, hw - cham, -hh, -hd + cham, -hw + cham, -hh, -hd + cham, 0f, -1f, 0f) // Dưới

        // 8 mặt vát góc xiên 45 độ quanh sườn hộp
        val invSqrt2 = 0.7071f
        addFace(hw - cham, -hh + cham, hd, hw, -hh + cham, hd - cham, hw, hh - cham, hd - cham, hw - cham, hh - cham, hd, invSqrt2, 0f, invSqrt2)
        addFace(-hw, -hh + cham, hd - cham, -hw + cham, -hh + cham, hd, -hw + cham, hh - cham, hd, -hw, hh - cham, hd - cham, -invSqrt2, 0f, invSqrt2)
        addFace(hw, -hh + cham, -hd + cham, hw - cham, -hh + cham, -hd, hw - cham, hh - cham, -hd, hw, hh - cham, -hd + cham, invSqrt2, 0f, -invSqrt2)
        addFace(-hw + cham, -hh + cham, -hd, -hw, -hh + cham, -hd + cham, -hw, hh - cham, -hd + cham, -hw + cham, hh - cham, -hd, -invSqrt2, 0f, -invSqrt2)

        return Procedural3DGenerator.MeshData(
            vertices = vList.toFloatArray(),
            normals = nList.toFloatArray(),
            indices = iList.toShortArray(),
            type = Procedural3DGenerator.MeshType.CUSTOM_DYNAMIC,
            triangleCount = iList.size / 3,
            customTitle = spec.title
        )
    }

    // =========================================================================
    // 3. DỰNG BÁNH RĂNG CƠ KHÍ THAM SỐ (PARAMETRIC MECHANICAL GEAR)
    // =========================================================================
    private fun buildParametricGearMesh(spec: Dynamic3DSpec): Procedural3DGenerator.MeshData {
        val toothCount = max(8, min(36, if (spec.segments >= 12) spec.segments else 16))
        val rRoot = spec.radiusBottom * 0.75f
        val rTip = spec.radiusBottom * 1.05f
        val rHole = if (spec.hasCenterBoreHole) spec.radiusBottom * 0.35f else 0f
        val thick = spec.height * 0.45f
        val halfT = thick / 2f

        val vList = mutableListOf<Float>()
        val nList = mutableListOf<Float>()
        val iList = mutableListOf<Short>()

        val totalPoints = toothCount * 4
        val profileR = FloatArray(totalPoints)
        val profileAngle = FloatArray(totalPoints)

        for (i in 0 until toothCount) {
            val baseAngle = (i.toFloat() / toothCount) * 2f * PI.toFloat()
            val step = (2f * PI.toFloat() / toothCount) / 4f

            profileAngle[i * 4] = baseAngle; profileR[i * 4] = rRoot
            profileAngle[i * 4 + 1] = baseAngle + step; profileR[i * 4 + 1] = rTip
            profileAngle[i * 4 + 2] = baseAngle + step * 2f; profileR[i * 4 + 2] = rTip
            profileAngle[i * 4 + 3] = baseAngle + step * 3f; profileR[i * 4 + 3] = rRoot
        }

        // Mặt vành răng ngoài
        for (i in 0 until totalPoints) {
            val next = (i + 1) % totalPoints
            val a1 = profileAngle[i]; val r1 = profileR[i]
            val a2 = profileAngle[next]; val r2 = profileR[next]

            val x1 = r1 * cos(a1); val z1 = r1 * sin(a1)
            val x2 = r2 * cos(a2); val z2 = r2 * sin(a2)

            val nx = (x1 + x2) / 2f; val nz = (z1 + z2) / 2f
            val len = sqrt(nx * nx + nz * nz)

            val base = (vList.size / 3).toShort()
            vList.addAll(listOf(x1, -halfT, z1, x1, halfT, z1, x2, halfT, z2, x2, -halfT, z2))
            for (k in 0..3) nList.addAll(listOf(nx / len, 0f, nz / len))
            iList.addAll(listOf(base, (base + 1).toShort(), (base + 2).toShort(), base, (base + 2).toShort(), (base + 3).toShort()))

            // Mặt nắp trên (Top Face)
            if (rHole > 0f) {
                val hx1 = rHole * cos(a1); val hz1 = rHole * sin(a1)
                val hx2 = rHole * cos(a2); val hz2 = rHole * sin(a2)
                val baseTop = (vList.size / 3).toShort()
                vList.addAll(listOf(x1, halfT, z1, hx1, halfT, hz1, hx2, halfT, hz2, x2, halfT, z2))
                for (k in 0..3) nList.addAll(listOf(0f, 1f, 0f))
                iList.addAll(listOf(baseTop, (baseTop + 1).toShort(), (baseTop + 2).toShort(), baseTop, (baseTop + 2).toShort(), (baseTop + 3).toShort()))
            } else {
                val baseTop = (vList.size / 3).toShort()
                vList.addAll(listOf(0f, halfT, 0f, x1, halfT, z1, x2, halfT, z2))
                for (k in 0..2) nList.addAll(listOf(0f, 1f, 0f))
                iList.addAll(listOf(baseTop, (baseTop + 1).toShort(), (baseTop + 2).toShort()))
            }

            // Mặt nắp dưới (Bottom Face)
            val baseBot = (vList.size / 3).toShort()
            vList.addAll(listOf(0f, -halfT, 0f, x2, -halfT, z2, x1, -halfT, z1))
            for (k in 0..2) nList.addAll(listOf(0f, -1f, 0f))
            iList.addAll(listOf(baseBot, (baseBot + 1).toShort(), (baseBot + 2).toShort()))
        }

        return Procedural3DGenerator.MeshData(
            vertices = vList.toFloatArray(),
            normals = nList.toFloatArray(),
            indices = iList.toShortArray(),
            type = Procedural3DGenerator.MeshType.CUSTOM_DYNAMIC,
            triangleCount = iList.size / 3,
            customTitle = spec.title
        )
    }

    // =========================================================================
    // 4. DỰNG KHỐI XOẮN ỐC / BÌNH SÓNG (PARAMETRIC TWISTED HELIX)
    // =========================================================================
    private fun buildParametricHelixMesh(spec: Dynamic3DSpec): Procedural3DGenerator.MeshData {
        val segs = spec.segments
        val stacks = 18
        val h = spec.height
        val halfH = h / 2f
        val maxTwist = if (spec.twistAngleRad > 0f) spec.twistAngleRad else (PI * 0.75f).toFloat()

        val vList = mutableListOf<Float>()
        val nList = mutableListOf<Float>()
        val iList = mutableListOf<Short>()

        for (stack in 0 until stacks) {
            val t1 = stack.toFloat() / stacks
            val t2 = (stack + 1).toFloat() / stacks

            val y1 = -halfH + t1 * h
            val y2 = -halfH + t2 * h

            // Biên độ lượn sóng sin
            val wave1 = 1f + 0.22f * sin(t1 * PI * 3f).toFloat()
            val wave2 = 1f + 0.22f * sin(t2 * PI * 3f).toFloat()

            val r1 = (spec.radiusBottom + (spec.radiusTop - spec.radiusBottom) * t1) * wave1
            val r2 = (spec.radiusBottom + (spec.radiusTop - spec.radiusBottom) * t2) * wave2

            val rot1 = t1 * maxTwist
            val rot2 = t2 * maxTwist

            for (i in 0 until segs) {
                val a1_1 = (i.toFloat() / segs) * 2f * PI.toFloat() + rot1
                val a1_2 = ((i + 1).toFloat() / segs) * 2f * PI.toFloat() + rot1
                val a2_1 = (i.toFloat() / segs) * 2f * PI.toFloat() + rot2
                val a2_2 = ((i + 1).toFloat() / segs) * 2f * PI.toFloat() + rot2

                val x1 = r1 * cos(a1_1); val z1 = r1 * sin(a1_1)
                val x2 = r1 * cos(a1_2); val z2 = r1 * sin(a1_2)
                val x3 = r2 * cos(a2_2); val z3 = r2 * sin(a2_2)
                val x4 = r2 * cos(a2_1); val z4 = r2 * sin(a2_1)

                val nx = (x1 + x2 + x3 + x4) / 4f
                val nz = (z1 + z2 + z3 + z4) / 4f
                val len = sqrt(nx * nx + nz * nz)

                val base = (vList.size / 3).toShort()
                vList.addAll(listOf(x1, y1, z1, x2, y1, z2, x3, y2, z3, x4, y2, z4))
                for (k in 0..3) nList.addAll(listOf(nx / len, 0f, nz / len))
                iList.addAll(listOf(base, (base + 1).toShort(), (base + 2).toShort(), base, (base + 2).toShort(), (base + 3).toShort()))
            }
        }

        return Procedural3DGenerator.MeshData(
            vertices = vList.toFloatArray(),
            normals = nList.toFloatArray(),
            indices = iList.toShortArray(),
            type = Procedural3DGenerator.MeshType.CUSTOM_DYNAMIC,
            triangleCount = iList.size / 3,
            customTitle = spec.title
        )
    }

    // =========================================================================
    // 5. DỰNG CHÂN ĐẾ ĐA GIÁC / GIÁ ĐỠ KẸP (TRIANGULAR MOUNT STAND)
    // =========================================================================
    private fun buildTriangularStandMesh(spec: Dynamic3DSpec): Procedural3DGenerator.MeshData {
        val rBase = spec.radiusBottom * 1.5f
        val rTop = spec.radiusTop * 0.6f
        val h = spec.height * 0.8f
        val halfH = h / 2f

        val vList = mutableListOf<Float>()
        val nList = mutableListOf<Float>()
        val iList = mutableListOf<Short>()

        val sides = 3 // Tam giác đều cân đối vững chắc
        for (i in 0 until sides) {
            val a1 = (i.toFloat() / sides) * 2f * PI.toFloat()
            val a2 = ((i + 1).toFloat() / sides) * 2f * PI.toFloat()

            val x1 = rBase * cos(a1); val z1 = rBase * sin(a1)
            val x2 = rBase * cos(a2); val z2 = rBase * sin(a2)
            val x3 = rTop * cos(a2); val z3 = rTop * sin(a2)
            val x4 = rTop * cos(a1); val z4 = rTop * sin(a1)

            val nx = (x1 + x2) / 2f; val nz = (z1 + z2) / 2f
            val len = sqrt(nx * nx + nz * nz)

            val base = (vList.size / 3).toShort()
            vList.addAll(listOf(x1, -halfH, z1, x2, -halfH, z2, x3, halfH, z3, x4, halfH, z4))
            for (k in 0..3) nList.addAll(listOf(nx / len, 0.35f, nz / len))
            iList.addAll(listOf(base, (base + 1).toShort(), (base + 2).toShort(), base, (base + 2).toShort(), (base + 3).toShort()))

            // Đáy tam giác
            val baseBot = (vList.size / 3).toShort()
            vList.addAll(listOf(0f, -halfH, 0f, x2, -halfH, z2, x1, -halfH, z1))
            for (k in 0..2) nList.addAll(listOf(0f, -1f, 0f))
            iList.addAll(listOf(baseBot, (baseBot + 1).toShort(), (baseBot + 2).toShort()))

            // Đỉnh phẳng
            val baseTop = (vList.size / 3).toShort()
            vList.addAll(listOf(0f, halfH, 0f, x4, halfH, z4, x3, halfH, z3))
            for (k in 0..2) nList.addAll(listOf(0f, 1f, 0f))
            iList.addAll(listOf(baseTop, (baseTop + 1).toShort(), (baseTop + 2).toShort()))
        }

        return Procedural3DGenerator.MeshData(
            vertices = vList.toFloatArray(),
            normals = nList.toFloatArray(),
            indices = iList.toShortArray(),
            type = Procedural3DGenerator.MeshType.CUSTOM_DYNAMIC,
            triangleCount = iList.size / 3,
            customTitle = spec.title
        )
    }

    // =========================================================================
    // 6. DỰNG KHỐI ĐA DIỆN VIỄN TƯỞNG (CYBER MECHA POLYHEDRON)
    // =========================================================================
    private fun buildCyberPolyhedronMesh(spec: Dynamic3DSpec): Procedural3DGenerator.MeshData {
        val r = spec.radiusBottom
        val h = spec.height * 0.9f
        val halfH = h / 2f

        val vList = mutableListOf<Float>()
        val nList = mutableListOf<Float>()
        val iList = mutableListOf<Short>()

        val points = 8
        for (i in 0 until points) {
            val a1 = (i.toFloat() / points) * 2f * PI.toFloat()
            val a2 = ((i + 1).toFloat() / points) * 2f * PI.toFloat()

            val x1 = r * cos(a1); val z1 = r * sin(a1)
            val x2 = r * cos(a2); val z2 = r * sin(a2)

            // Mặt nón trên chóp
            val baseTop = (vList.size / 3).toShort()
            vList.addAll(listOf(0f, halfH, 0f, x1, 0f, z1, x2, 0f, z2))
            val nx = (x1 + x2) / 2f; val nz = (z1 + z2) / 2f; val len = sqrt(nx * nx + nz * nz)
            for (k in 0..2) nList.addAll(listOf(nx / len, 0.7f, nz / len))
            iList.addAll(listOf(baseTop, (baseTop + 1).toShort(), (baseTop + 2).toShort()))

            // Mặt nón dưới đáy
            val baseBot = (vList.size / 3).toShort()
            vList.addAll(listOf(0f, -halfH, 0f, x2, 0f, z2, x1, 0f, z1))
            for (k in 0..2) nList.addAll(listOf(nx / len, -0.7f, nz / len))
            iList.addAll(listOf(baseBot, (baseBot + 1).toShort(), (baseBot + 2).toShort()))
        }

        return Procedural3DGenerator.MeshData(
            vertices = vList.toFloatArray(),
            normals = nList.toFloatArray(),
            indices = iList.toShortArray(),
            type = Procedural3DGenerator.MeshType.CUSTOM_DYNAMIC,
            triangleCount = iList.size / 3,
            customTitle = spec.title
        )
    }
}
