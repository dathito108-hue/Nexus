package com.hypernexus.nit.voice

import android.content.Context
import android.media.AudioManager
import android.speech.tts.TextToSpeech
import android.util.Log
import java.util.Calendar

object AdaptiveVoiceEngine {

    private const val TAG = "AdaptiveVoiceEngine"

    enum class VoiceEmotion {
        NORMAL,
        WHISPER_NIGHT,     // Chế độ ban đêm: Giọng nhỏ, thì thầm nhẹ nhàng
        URGENT_ALARM,      // Chế độ khẩn cấp: Giọng to, nhanh, dứt khoát
        BULLISH_EXCITED    // Chế độ phấn khởi: Khi giá coin tăng mạnh, chốt lời
    }

    /**
     * TỰ ĐỘNG THÍCH ỨNG CAO ĐỘ VÀ ÂM LƯỢNG GIỌNG NÓI THEO BỐI CẢNH & THỜI GIAN
     */
    fun applyAdaptiveVoiceSettings(
        context: Context,
        tts: TextToSpeech?,
        requestedEmotion: VoiceEmotion? = null
    ): VoiceEmotion {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val currentHour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)

        // 1. Nếu người dùng không chỉ định, tự động phát hiện theo thời gian
        val activeEmotion = requestedEmotion ?: when {
            currentHour >= 23 || currentHour < 6 -> VoiceEmotion.WHISPER_NIGHT
            else -> VoiceEmotion.NORMAL
        }

        // 2. Tinh chỉnh thông số Text-to-Speech
        when (activeEmotion) {
            VoiceEmotion.WHISPER_NIGHT -> {
                tts?.setPitch(0.85f)       // Hạ thấp cao độ tạo âm thì thầm
                tts?.setSpeechRate(0.95f)   // Đọc chậm rãi, êm dịu
                Log.d(TAG, "Đã kích hoạt chế độ giọng nói THÌ THẦM BAN ĐÊM (Whisper Mode).")
            }
            VoiceEmotion.URGENT_ALARM -> {
                tts?.setPitch(1.30f)       // Cao độ cao, nhấn mạnh
                tts?.setSpeechRate(1.30f)   // Nói nhanh dứt khoát
                Log.d(TAG, "Đã kích hoạt chế độ giọng nói KHẨN CẤP (Urgent Mode).")
            }
            VoiceEmotion.BULLISH_EXCITED -> {
                tts?.setPitch(1.25f)       // Giọng tươi vui, nhí nhảnh
                tts?.setSpeechRate(1.20f)
                Log.d(TAG, "Đã kích hoạt chế độ giọng nói PHẤN KHỞI (Bullish Mode).")
            }
            VoiceEmotion.NORMAL -> {
                tts?.setPitch(1.10f)
                tts?.setSpeechRate(1.15f)
            }
        }

        return activeEmotion
    }
}
