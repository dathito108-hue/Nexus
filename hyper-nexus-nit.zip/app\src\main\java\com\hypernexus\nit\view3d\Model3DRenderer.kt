package com.hypernexus.nit.view3d

import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import com.hypernexus.nit.engine.Procedural3DGenerator
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import java.nio.ShortBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

/**
 * TRÌNH KẾT XUẤT 3D CHUYÊN NGHIỆP TỐI ƯU HÓA 120 FPS TRÊN GPU MALI-G78
 * Hỗ trợ Shader Blinn-Phong Metallic, Rim Light Fresnel, Bản đồ pháp tuyến Normal Map,
 * Giả lập cắt lớp máy in 3D (Slicer Layer Inspection) và Lưới bàn in 3D (Print Bed Grid).
 */
class Model3DRenderer : GLSurfaceView.Renderer {

    enum class RenderMode(val id: Int, val displayName: String) {
        PBR_METALLIC(0, "PBR Kim Loại (Phong)"),
        NEON_WIREFRAME(1, "Lưới Neon Cyberpunk"),
        NORMAL_MAP(2, "Bản Đồ Pháp Tuyến (CAD)"),
        SLICER_LAYERS(3, "Mô Phỏng Cắt Lớp In 3D")
    }

    private val mvpMatrix = FloatArray(16)
    private val projectionMatrix = FloatArray(16)
    private val viewMatrix = FloatArray(16)
    private val modelMatrix = FloatArray(16)
    private val tempMatrix = FloatArray(16)

    // Trạng thái xoay & thu phóng từ cảm ứng ngón tay
    var angleX: Float = 15f
    var angleY: Float = 25f
    var scaleFactor: Float = 1.0f

    var activeRenderMode: RenderMode = RenderMode.PBR_METALLIC
    var showGridFloor: Boolean = true

    // Tương thích ngược với cờ wireframe cũ
    var isWireframeMode: Boolean
        get() = activeRenderMode == RenderMode.NEON_WIREFRAME
        set(value) {
            activeRenderMode = if (value) RenderMode.NEON_WIREFRAME else RenderMode.PBR_METALLIC
        }

    private var vertexBuffer: FloatBuffer? = null
    private var normalBuffer: FloatBuffer? = null
    private var indexBuffer: ShortBuffer? = null
    private var indexCount = 0

    // Bàn in 3D (Print Bed Grid)
    private var gridVertexBuffer: FloatBuffer? = null
    private var gridVertexCount = 0

    // Shader Program cho vật thể
    private var programId = 0
    private var posHandle = 0
    private var normalHandle = 0
    private var mvpHandle = 0
    private var modelHandle = 0
    private var colorHandle = 0
    private var renderModeHandle = 0

    // Shader Program cho lưới bàn in
    private var gridProgramId = 0
    private var gridPosHandle = 0
    private var gridMvpHandle = 0
    private var gridColorHandle = 0

    // Màu sắc vật liệu (Cyan Neon mặc định)
    var modelColor = floatArrayOf(0.0f, 0.9f, 1.0f)

    // Đo đạc FPS thực tế 120Hz
    private var frameCount = 0
    private var lastFpsTimestamp = System.currentTimeMillis()
    var currentFps = 120
    var onFpsUpdated: ((Int) -> Unit)? = null

    private val vertexShaderCode = """
        uniform mat4 uMVPMatrix;
        uniform mat4 uModelMatrix;
        attribute vec4 aPosition;
        attribute vec3 aNormal;
        varying vec3 vNormal;
        varying vec3 vPosition;
        void main() {
            gl_Position = uMVPMatrix * aPosition;
            vNormal = mat3(uModelMatrix) * aNormal;
            vPosition = vec3(uModelMatrix * aPosition);
        }
    """.trimIndent()

    private val fragmentShaderCode = """
        precision mediump float;
        uniform vec3 uColor;
        uniform int uRenderMode;
        varying vec3 vNormal;
        varying vec3 vPosition;
        void main() {
            vec3 norm = normalize(vNormal);
            vec3 lightDir = normalize(vec3(1.2, 2.5, 2.0));
            vec3 eyeDir = normalize(vec3(0.0, 0.8, 4.0) - vPosition);

            if (uRenderMode == 1) {
                // 1. Neon Wireframe Glow
                gl_FragColor = vec4(0.08, 0.95, 0.58, 1.0); // #14F195 Neon Emerald
            } else if (uRenderMode == 2) {
                // 2. Normal Map Vector (CAD Surface Inspection)
                vec3 normalRgb = norm * 0.5 + 0.5;
                gl_FragColor = vec4(normalRgb, 1.0);
            } else if (uRenderMode == 3) {
                // 3. Slicer Layer Inspection (Simulated 0.2mm Layer Height)
                float layerLine = sin(vPosition.y * 70.0);
                vec3 layerColor = (layerLine > 0.0) ? uColor * 1.15 : uColor * 0.65;
                gl_FragColor = vec4(layerColor, 1.0);
            } else {
                // 0. PBR Blinn-Phong Metallic Specular + Fresnel Rim Lighting
                float diff = max(dot(norm, lightDir), 0.0);
                vec3 halfDir = normalize(lightDir + eyeDir);
                float spec = pow(max(dot(norm, halfDir), 0.0), 32.0) * 0.75;

                // Fresnel Rim Lighting
                float rim = pow(1.0 - max(dot(norm, eyeDir), 0.0), 3.0);
                vec3 rimColor = vec3(0.0, 0.9, 1.0) * rim * 0.55;

                vec3 ambient = vec3(0.08, 0.12, 0.20) * uColor;
                vec3 finalColor = ambient + (uColor * diff * 0.85) + (vec3(1.0) * spec) + rimColor;
                gl_FragColor = vec4(finalColor, 1.0);
            }
        }
    """.trimIndent()

    // Grid Floor Shaders
    private val gridVertexShader = """
        uniform mat4 uMVPMatrix;
        attribute vec4 aPosition;
        void main() {
            gl_Position = uMVPMatrix * aPosition;
        }
    """.trimIndent()

    private val gridFragmentShader = """
        precision mediump float;
        uniform vec4 uColor;
        void main() {
            gl_FragColor = uColor;
        }
    """.trimIndent()

    override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
        // Nền tối Cyberpunk sang trọng
        GLES20.glClearColor(0.04f, 0.05f, 0.08f, 1.0f)
        GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        GLES20.glDepthFunc(GLES20.GL_LEQUAL)

        // 1. Khởi tạo Shader cho Model
        val vertexShader = loadShader(GLES20.GL_VERTEX_SHADER, vertexShaderCode)
        val fragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, fragmentShaderCode)
        programId = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, vertexShader)
            GLES20.glAttachShader(it, fragmentShader)
            GLES20.glLinkProgram(it)
        }

        posHandle = GLES20.glGetAttribLocation(programId, "aPosition")
        normalHandle = GLES20.glGetAttribLocation(programId, "aNormal")
        mvpHandle = GLES20.glGetUniformLocation(programId, "uMVPMatrix")
        modelHandle = GLES20.glGetUniformLocation(programId, "uModelMatrix")
        colorHandle = GLES20.glGetUniformLocation(programId, "uColor")
        renderModeHandle = GLES20.glGetUniformLocation(programId, "uRenderMode")

        // 2. Khởi tạo Shader cho Lưới Bàn In (Grid Floor)
        val gVertexShader = loadShader(GLES20.GL_VERTEX_SHADER, gridVertexShader)
        val gFragmentShader = loadShader(GLES20.GL_FRAGMENT_SHADER, gridFragmentShader)
        gridProgramId = GLES20.glCreateProgram().also {
            GLES20.glAttachShader(it, gVertexShader)
            GLES20.glAttachShader(it, gFragmentShader)
            GLES20.glLinkProgram(it)
        }
        gridPosHandle = GLES20.glGetAttribLocation(gridProgramId, "aPosition")
        gridMvpHandle = GLES20.glGetUniformLocation(gridProgramId, "uMVPMatrix")
        gridColorHandle = GLES20.glGetUniformLocation(gridProgramId, "uColor")

        // 3. Xây dựng Lưới Tọa Độ Bàn In 3D (Bed Floor) tại Y = -1.15
        buildGridFloor()
    }

    private fun buildGridFloor() {
        val lines = mutableListOf<Float>()
        val size = 1.8f
        val steps = 10
        val y = -1.15f

        for (i in -steps..steps) {
            val t = (i.toFloat() / steps) * size
            // Đường dọc song song Z
            lines.add(t); lines.add(y); lines.add(-size)
            lines.add(t); lines.add(y); lines.add(size)
            // Đường ngang song song X
            lines.add(-size); lines.add(y); lines.add(t)
            lines.add(size); lines.add(y); lines.add(t)
        }

        gridVertexCount = lines.size / 3
        val bb = ByteBuffer.allocateDirect(lines.size * 4).order(ByteOrder.nativeOrder())
        gridVertexBuffer = bb.asFloatBuffer().apply {
            put(lines.toFloatArray())
            position(0)
        }
    }

    override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
        GLES20.glViewport(0, 0, width, height)
        val ratio = width.toFloat() / height.toFloat()
        // Thiết lập góc nhìn phối cảnh 3D FOV 45 độ
        Matrix.perspectiveM(projectionMatrix, 0, 45.0f, ratio, 0.1f, 100.0f)
    }

    override fun onDrawFrame(gl: GL10?) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

        // Đo đạc FPS thực tế
        frameCount++
        val now = System.currentTimeMillis()
        if (now - lastFpsTimestamp >= 1000) {
            currentFps = frameCount
            frameCount = 0
            lastFpsTimestamp = now
            onFpsUpdated?.invoke(currentFps)
        }

        // Tự động xoay chậm nhẹ nhàng khi người dùng không chạm (Idle Animation)
        angleY += 0.35f

        // Camera đặt tại Z = 4.2 nhìn về (0, 0.2, 0)
        Matrix.setLookAtM(viewMatrix, 0, 0f, 1.0f, 4.2f, 0f, 0.2f, 0f, 0f, 1f, 0f)

        // 1. VẼ LƯỚI BÀN IN 3D NẾU BẬT
        if (showGridFloor && gridVertexBuffer != null) {
            GLES20.glUseProgram(gridProgramId)
            Matrix.multiplyMM(tempMatrix, 0, projectionMatrix, 0, viewMatrix, 0)
            GLES20.glUniformMatrix4fv(gridMvpHandle, 1, false, tempMatrix, 0)
            GLES20.glUniform4f(gridColorHandle, 0.12f, 0.20f, 0.32f, 0.6f) // Màu xanh Slate mờ

            gridVertexBuffer?.let { gBuf ->
                gBuf.position(0)
                GLES20.glEnableVertexAttribArray(gridPosHandle)
                GLES20.glVertexAttribPointer(gridPosHandle, 3, GLES20.GL_FLOAT, false, 0, gBuf)
                GLES20.glDrawArrays(GLES20.GL_LINES, 0, gridVertexCount)
                GLES20.glDisableVertexAttribArray(gridPosHandle)
            }
        }

        // 2. VẼ MÔ HÌNH 3D CHÍNH
        val vBuf = vertexBuffer ?: return
        val iBuf = indexBuffer ?: return

        GLES20.glUseProgram(programId)

        // Ma trận Model: Xoay & Co giãn theo tương tác
        Matrix.setIdentityM(modelMatrix, 0)
        Matrix.scaleM(modelMatrix, 0, scaleFactor, scaleFactor, scaleFactor)
        Matrix.rotateM(modelMatrix, 0, angleX, 1.0f, 0.0f, 0.0f)
        Matrix.rotateM(modelMatrix, 0, angleY, 0.0f, 1.0f, 0.0f)

        // MVP = Projection * View * Model
        Matrix.multiplyMM(tempMatrix, 0, viewMatrix, 0, modelMatrix, 0)
        Matrix.multiplyMM(mvpMatrix, 0, projectionMatrix, 0, tempMatrix, 0)

        GLES20.glUniformMatrix4fv(mvpHandle, 1, false, mvpMatrix, 0)
        GLES20.glUniformMatrix4fv(modelHandle, 1, false, modelMatrix, 0)
        GLES20.glUniform3fv(colorHandle, 1, modelColor, 0)
        GLES20.glUniform1i(renderModeHandle, activeRenderMode.id)

        // Nạp Vertices
        vBuf.position(0)
        GLES20.glEnableVertexAttribArray(posHandle)
        GLES20.glVertexAttribPointer(posHandle, 3, GLES20.GL_FLOAT, false, 0, vBuf)

        // Nạp Normals
        normalBuffer?.let { nBuf ->
            nBuf.position(0)
            GLES20.glEnableVertexAttribArray(normalHandle)
            GLES20.glVertexAttribPointer(normalHandle, 3, GLES20.GL_FLOAT, false, 0, nBuf)
        }

        // Vẽ tam giác hoặc lưới dây (Lines)
        iBuf.position(0)
        val glRenderMode = if (activeRenderMode == RenderMode.NEON_WIREFRAME) GLES20.GL_LINES else GLES20.GL_TRIANGLES
        GLES20.glDrawElements(glRenderMode, indexCount, GLES20.GL_UNSIGNED_SHORT, iBuf)

        GLES20.glDisableVertexAttribArray(posHandle)
        GLES20.glDisableVertexAttribArray(normalHandle)
    }

    /**
     * Nạp dữ liệu hình học MeshData vào GPU Mali-G78
     */
    fun updateMeshData(mesh: Procedural3DGenerator.MeshData) {
        val vBytes = ByteBuffer.allocateDirect(mesh.vertices.size * 4).order(ByteOrder.nativeOrder())
        vertexBuffer = vBytes.asFloatBuffer().apply {
            put(mesh.vertices)
            position(0)
        }

        val nBytes = ByteBuffer.allocateDirect(mesh.normals.size * 4).order(ByteOrder.nativeOrder())
        normalBuffer = nBytes.asFloatBuffer().apply {
            put(mesh.normals)
            position(0)
        }

        val iBytes = ByteBuffer.allocateDirect(mesh.indices.size * 2).order(ByteOrder.nativeOrder())
        indexBuffer = iBytes.asShortBuffer().apply {
            put(mesh.indices)
            position(0)
        }

        indexCount = mesh.indices.size

        // Đổi màu sắc tương ứng với 12 loại mô hình
        modelColor = when (mesh.type) {
            Procedural3DGenerator.MeshType.CYBER_ROBOT -> floatArrayOf(0.0f, 0.9f, 1.0f) // Cyan
            Procedural3DGenerator.MeshType.SPACESHIP -> floatArrayOf(0.08f, 0.95f, 0.58f) // Emerald
            Procedural3DGenerator.MeshType.NANO_DRONE -> floatArrayOf(0.98f, 0.75f, 0.15f) // Gold
            Procedural3DGenerator.MeshType.MECHA_SWORD -> floatArrayOf(0.95f, 0.28f, 0.60f) // Magenta
            Procedural3DGenerator.MeshType.QUANTUM_SATELLITE -> floatArrayOf(0.65f, 0.40f, 0.95f) // Purple
            Procedural3DGenerator.MeshType.CYBER_HELMET -> floatArrayOf(0.20f, 0.75f, 0.98f) // Sky blue
            Procedural3DGenerator.MeshType.SPUR_GEAR -> floatArrayOf(0.95f, 0.55f, 0.15f) // Amber Bronze
            Procedural3DGenerator.MeshType.PHONE_STAND -> floatArrayOf(0.35f, 0.85f, 0.98f) // High-tech Ice Blue
            Procedural3DGenerator.MeshType.MECHANICAL_WRENCH -> floatArrayOf(0.85f, 0.88f, 0.92f) // Chrome Steel
            Procedural3DGenerator.MeshType.PARAMETRIC_VASE -> floatArrayOf(0.92f, 0.38f, 0.72f) // Rose Quartz
            Procedural3DGenerator.MeshType.HEATSINK -> floatArrayOf(0.98f, 0.48f, 0.22f) // Copper Anodized
            else -> floatArrayOf(0.9f, 0.9f, 0.9f)
        }
    }

    private fun loadShader(type: Int, shaderCode: String): Int {
        return GLES20.glCreateShader(type).also { shader ->
            GLES20.glShaderSource(shader, shaderCode)
            GLES20.glCompileShader(shader)
        }
    }
}
